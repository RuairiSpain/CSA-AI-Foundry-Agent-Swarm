# SAFE Framework Phase 1.5 — Design Pattern Library

**Phase:** 1.5 (Weeks 4-5 of 12-week plan)  
**Status:** Specification Complete  
**Version:** 2.0  
**Date:** 2026-06-20

---

## Executive Summary

**Phase 1.5** introduces a **curated library of 12 composition patterns** that CSAs and users can leverage to rapidly build complex multi-agent routes without manual coding.

### Key Metrics
- **12 Patterns:** 6 built-in from Phase 1 + 6 critical new patterns
- **Effort:** 3-4 weeks (one senior engineer)
- **Impact:** 5-10x faster route creation for complex workflows
- **Foundation:** User-defined patterns (Phase 2+)

---

## Problem Statement

### Current State (After Phase 1)
- Users can pick ONE of 4 patterns (sequential, fan-out, fan-in, handoff)
- For complex workflows: users still manually code
- No reusable pattern library
- CSA onboarding: 30+ minutes per route

### Phase 1.5 Solution
- **12 prebuilt patterns** covering 80% of real-world use cases
- **Interactive customization** per pattern (no coding needed)
- **Foundation for user patterns** (extensibility)
- **CSA onboarding: 5-10 minutes per route**

---

## Pattern Taxonomy

### **GROUP A: PARALLEL PATTERNS (4 patterns)**

#### **Pattern 1: Fan-Out / Fan-In** ✅ (From Phase 1, enhanced)
```
[Input] → [Processor] → [Worker₁]┐
                        [Worker₂]├→ [Aggregator] → [Output]
                        [Worker₃]┘

Use Cases:
- Document review: Route to multiple reviewers in parallel
- Opinion aggregation: Get feedback from diverse experts
- Quality control: Multiple parallel inspections
- Batch processing: Parallel processing of items

User Questions:
1. How many parallel workers? (2-20)
2. Agent for Processor stage?
3. Agent(s) for Worker slots? (same agent or different?)
4. Agent for Aggregator stage?

Example Topology:
Input: Document
Processor: DocumentExtractor (1)
Workers: [ReviewerA, ReviewerB, ReviewerC] (3 parallel)
Aggregator: ReviewAggregator
Output: Final decision
```

#### **Pattern 2: Map-Reduce** ✅ (From Phase 1, enhanced)
```
[Input] → [Splitter] → [Map₁]┐
                       [Map₂]├→ [Shuffle] → [Reduce₁]┐
                       [Map₃]┘              [Reduce₂]├→ [Final] → [Output]
                                           [Reduce₃]┘

Use Cases:
- Large batch processing: 1000 items split across 10 mappers
- Distributed computation: Process, shuffle, reduce pattern
- Data aggregation: Merge results from multiple sources
- Hierarchical analysis: Map stage → reduce stage → final

User Questions:
1. How many Map workers? (2-20)
2. How many Reduce workers? (1-10)
3. Agent for Splitter?
4. Agent for Map slots?
5. Agent for Shuffle?
6. Agent for Reduce slots?
7. Agent for Final?

Example Topology:
Input: 1000 documents
Splitter: BatchSplitter
Mappers: [DocumentAnalyzer × 10] (10 parallel)
Shuffle: ShuffleAggregator
Reducers: [ResultReducer × 3] (3 parallel)
Final: FinalAggregator
Output: Consolidated results
```

#### **Pattern 3: Round-Robin** 🆕
```
[Input] → [Distributor] → [Worker₁]┐
                          [Worker₂]├→ [Collector] → [Output]
                          [Worker₃]┘

Distribution: Round-robin across workers
(Item 1 → Worker1, Item 2 → Worker2, Item 3 → Worker3, Item 4 → Worker1, ...)

Use Cases:
- Load balancing: Distribute work evenly across identical workers
- Work queue: Assign tasks to available workers in rotation
- Scalable processing: Add more workers as load increases
- Worker pool: Same agent type, multiple instances

User Questions:
1. How many workers? (2-10)
2. Agent for Distributor?
3. Agent for Worker slots? (typically same agent)
4. Agent for Collector?

Example Topology:
Input: 30 tasks to process
Distributor: TaskDistributor
Workers: [ProcessorAgent × 5] (5 identical workers)
Collector: ResultCollector
Output: All results collected
```

#### **Pattern 4: Mixture of Experts** 🆕
```
[Input] → [Router] → [ExpertA] (if condition_A)┐
                    [ExpertB] (if condition_B)├→ [Aggregator] → [Output]
                    [ExpertC] (if condition_C)┘

Use Cases:
- Specialist routing: Route to domain experts (legal, finance, medical)
- Content moderation: Route by content type (text, image, video)
- Skill-based assignment: Route to agent with required skills
- Conditional expertise: Different expert for each case

User Questions:
1. How many expert branches? (2-10)
2. Agent for Router?
3. For each branch:
   - Branch condition? (e.g., "content_type == 'legal'")
   - Expert agent name?
4. Agent for Aggregator?
5. Fallback agent if no condition matches?

Example Topology:
Input: Support ticket
Router: TicketRouter
Branches:
  - Condition: "type == 'billing'" → BillingExpert
  - Condition: "type == 'technical'" → TechExpert
  - Condition: "type == 'legal'" → LegalExpert
Aggregator: ResponseAggregator
Fallback: GeneralSupport
Output: Response
```

---

### **GROUP B: SEQUENTIAL PATTERNS (5 patterns)**

#### **Pattern 5: Sequential Pipeline** ✅ (From Phase 1, enhanced)
```
[Input] → [Stage₁] → [Stage₂] → [Stage₃] → [Output]

Use Cases:
- Multi-stage processing: Extract → Validate → Enrich → Store
- Data transformation: Each stage transforms the data
- Workflow progression: Each stage completes a task
- Assembly line: Data flows through sequential stations

User Questions:
1. How many stages? (2-10)
2. For each stage:
   - Agent name?
   - Error handling? (fail_hard, skip, retry)
   - Timeout?

Example Topology:
Input: Raw document
Stage 1: DocumentExtractor
Stage 2: DataValidator
Stage 3: DataEnricher
Stage 4: DocumentStore
Output: Stored document
```

#### **Pattern 6: Supervisor/Manager** 🆕 ⭐ CRITICAL
```
[Input] → [Supervisor] → Decides routing → [AgentA]┐
                                          [AgentB]├→ [Aggregator] → [Output]
                                          [AgentC]┘

Supervisor has full visibility and decides:
- Which agents to invoke
- In what order
- Based on input characteristics
- Can invoke 1, 2, 3, or all agents

Use Cases:
- Intelligent routing: Supervisor analyzes input, routes to best agent
- Conditional multi-agent: Route to different agents based on type
- Load-aware routing: Route to least-busy agent
- Specialized workflows: Different path for each category
- Most common real-world pattern!

User Questions:
1. Agent for Supervisor? (has full decision authority)
2. How many possible routing branches? (2-10)
3. For each branch:
   - Branch name/description?
   - Agents that can be invoked? (1 or more)
   - Context/condition?
4. Agent for Aggregator?

Example Topology:
Input: Loan application
Supervisor: LoanSupervisor
Analyzes: {loan_type, amount, credit_score, employment}
Routing Decision:
  - If mortgage → [MortgageAnalyst, ComplianceReviewer]
  - If auto → [AutoLoanAnalyst]
  - If personal (amount < $5k) → [QuickApproval]
  - If personal (amount ≥ $5k) → [PersonalAnalyst, ComplianceReviewer]
Aggregator: LoanDecisionAggregator
Output: Approval/Rejection
```

#### **Pattern 7: Hierarchical Teams** 🆕
```
[Input] → [CEO/Lead] → [Director₁ → [Team_A agents]]┐
                       [Director₂ → [Team_B agents]]├→ [Final] → [Output]
                       [Director₃ → [Team_C agents]]┘

Hierarchical delegation: Top agent delegates to middle layer, 
middle layer orchestrates their teams

Use Cases:
- Organizational structure: Mirror org hierarchy in workflow
- Multi-team collaboration: Different teams work on different aspects
- Escalation: Each level has decision authority
- Complex projects: CEO decides what each director team does

User Questions:
1. Agent for top level (CEO/Lead)?
2. How many middle-level directors? (2-5)
3. For each director:
   - Agent name?
   - How many agents in team? (2-5)
   - Team member agents?
4. Agent for Final aggregator?

Example Topology:
Input: Large project
CEO: ProjectManager
Directors:
  - DirectorA: DesignDirector
    Team: [ArchitectAgent, DesignSystemAgent, UIAgent]
  - DirectorB: EngineeringDirector
    Team: [BackendAgent, FrontendAgent, TestingAgent]
  - DirectorC: QADirector
    Team: [QAEngineerAgent, PerformanceAgent]
Final: ProjectAggregator
Output: Completed project
```

#### **Pattern 8: Fallback Chain** 🆕
```
[Input] → Try [Agent₁] → Success? ✓ → [Output]
                    ↓ (fails)
           Try [Agent₂] → Success? ✓ → [Output]
                    ↓ (fails)
           Try [Agent₃] → Success? ✓ → [Output]
                    ↓ (fails)
           Error or Manual Intervention

Use Cases:
- Degraded operation: Fast model → accurate model → expensive model
- Fallback agents: Try primary, if overloaded try secondary
- Progressive refinement: Simple → complex → human review
- Resilience: System keeps trying until success

User Questions:
1. How many agents in fallback chain? (2-5)
2. For each:
   - Agent name?
   - Timeout for this agent?
   - Success criteria?
   - What to do on failure? (try next / fail hard)

Example Topology:
Input: Document analysis request
Agent 1: FastModel (timeout: 5s)
  - Success: Return result
  - Timeout/Fail: Try Agent 2

Agent 2: AccurateModel (timeout: 30s)
  - Success: Return result
  - Timeout/Fail: Try Agent 3

Agent 3: ExpensiveModel (timeout: 120s)
  - Success: Return result
  - Fail: Escalate to human

Output: Analysis result
```

#### **Pattern 9: Retry Loop** 🆕
```
[Input] → [Agent] → Success? ✓ → [Output]
              ↓
         Fail? → Backoff → Retry
              ↓
         Max retries? → Fallback Agent

Use Cases:
- Transient failures: Network error, temporary unavailable
- Exponential backoff: 100ms → 200ms → 400ms → 800ms
- Circuit breaker: After N failures, stop retrying
- Graceful degradation: Fallback after exhausted retries

User Questions:
1. Primary agent?
2. Max retries? (1-10)
3. Initial backoff (ms)? (100, 500, 1000)
4. Backoff strategy? (linear, exponential, fixed)
5. Fallback agent if max retries exceeded?
6. Success criteria?

Example Topology:
Input: API request
Primary: ExternalAPIAgent
  - Success: Return data
  - Fail: Retry with backoff
    - Retry 1: Wait 100ms, try again
    - Retry 2: Wait 200ms, try again
    - Retry 3: Wait 400ms, try again
  - Max retries exceeded: Use CacheAgent
  - Success: Return cached data

Output: Data
```

---

### **GROUP C: CONDITIONAL PATTERNS (2 patterns)**

#### **Pattern 10: Diamond** ✅ (From Phase 1, enhanced)
```
[Input] → [PathA] ┐
          [PathB] ├→ [Convergence] → [Output]

Two independent paths process in parallel, then converge

Use Cases:
- Parallel analysis: Process via two different methods, validate convergence
- Risk assessment: Parallel evaluation and approval
- Quality check: Two independent reviewers, must agree
- Dual validation: Process via two algorithms, compare results

User Questions:
1. Agent for input preparation?
2. Agent for PathA?
3. Agent for PathB?
4. Agent for Convergence/Validation?
   - How to handle disagreement?
   - Require agreement? Merge results? Escalate?

Example Topology:
Input: Financial transaction
PathA: FraudDetectionModelA
PathB: FraudDetectionModelB
Convergence: FraudValidator
  - If both agree: Decision final
  - If disagree: Escalate to human
Output: Fraud/Not fraud decision
```

#### **Pattern 11: Conditional Branching** 🆕
```
[Input] → [Router] → 
  if condition₁ → [Path₁] ┐
  if condition₂ → [Path₂] ├→ [Merger] → [Output]
  if condition₃ → [Path₃] ┘
  else → [Default Path]

Complex conditional routing with multiple branches and conditions

Use Cases:
- Complex business logic: Multiple conditional paths
- Compliance routing: Different paths based on regulations
- Risk-based routing: Route based on risk score tiers
- Type-based handling: Different processing by content type

User Questions:
1. Agent for Router/Decision?
2. Number of conditional branches? (2-10)
3. For each branch:
   - Condition expression? (e.g., "risk_score > 0.8 AND country == 'US'")
   - Path agent/agents?
4. Default/fallback path if no condition matches?
5. Agent for Merger?

Example Topology:
Input: Loan application {amount, credit_score, country, risk_score}
Router: LoanRouter

Conditions:
  1. If amount > $1M AND country == 'EU'
     → [ComplianceReviewer, RegulatoryAgent, HighRiskAgent]
  
  2. If amount > $1M AND country == 'US'
     → [ComplianceReviewer, HighRiskAgent]
  
  3. If 100k < amount ≤ 1M AND risk_score < 0.5
     → [StandardAnalyst, QuickApprovalAgent]
  
  4. If 100k < amount ≤ 1M AND risk_score ≥ 0.5
     → [StandardAnalyst, RiskAnalyst]
  
  5. Else (amount ≤ 100k)
     → [AutoApprovalAgent]

Merger: DecisionMerger
Output: Loan decision
```

---

### **GROUP D: REDUCTION PATTERNS (1 pattern)**

#### **Pattern 12: Tree-Reduce** ✅ (From Phase 1, enhanced)
```
Layer 0: [Item₁, Item₂, Item₃, Item₄, Item₅, Item₆, Item₇, Item₈]
           ↓
Layer 1: [Reduce(1,2), Reduce(3,4), Reduce(5,6), Reduce(7,8)]
           ↓
Layer 2: [Reduce(1-2,3-4), Reduce(5-6,7-8)]
           ↓
Layer 3: [Final Reduce]

Use Cases:
- Hierarchical aggregation: Large batch reduced in stages
- Tree-structured merge: Pair-wise reduction
- Scalable summarization: Summarize summaries
- Distributed consensus: Multiple levels of voting

User Questions:
1. Input batch size? (4, 8, 16, 32)
2. Reduction factor per level? (2, 3, 4)
3. Agent for each reduction level?

Example Topology:
Input: 8 customer feedback items
Layer 1: [PairwiseAnalyzer × 4] → 4 summaries
Layer 2: [GroupAnalyzer × 2] → 2 group summaries
Layer 3: [FinalAnalyzer] → 1 final summary
Output: Customer satisfaction trend
```

---

## Architecture Design

### **Core Components**

```
safe_core/
├── pattern_library.py              (NEW) Pattern definitions & registry
├── pattern_customizer.py           (NEW) Interactive customization
├── pattern_templates/              (NEW) Jinja2 templates
│   ├── fan_out_fan_in.py.jinja2
│   ├── map_reduce.py.jinja2
│   ├── round_robin.py.jinja2
│   ├── mixture_of_experts.py.jinja2
│   ├── sequential_pipeline.py.jinja2
│   ├── supervisor_manager.py.jinja2
│   ├── hierarchical_teams.py.jinja2
│   ├── fallback_chain.py.jinja2
│   ├── retry_loop.py.jinja2
│   ├── diamond.py.jinja2
│   ├── conditional_branching.py.jinja2
│   └── tree_reduce.py.jinja2
├── pattern_authoring.py            (NEW) User pattern creation
├── route_definitions.py            (UPDATED) Pattern reference
├── code_generator.py               (UPDATED) Pattern-aware generation
├── route_writer.py                 (UPDATED) Pattern selection
└── example_agents.py               (unchanged)

safe_cli/
└── cli.py                          (UPDATED) Pattern selection flow
```

---

## Module Specifications

### **1. Pattern Library** (`pattern_library.py`)

```python
from pydantic import BaseModel
from enum import Enum
from typing import List, Dict, Optional

class PatternComplexity(str, Enum):
    SIMPLE = "simple"           # Sequential, fallback
    INTERMEDIATE = "intermediate"  # Fan-out, map-reduce
    ADVANCED = "advanced"       # Supervisor, hierarchical

class PatternCategory(str, Enum):
    PARALLEL = "parallel"
    SEQUENTIAL = "sequential"
    CONDITIONAL = "conditional"
    REDUCTION = "reduction"

class PlaceholderNode(BaseModel):
    """A slot in a pattern where an agent goes."""
    id: str                     # "processor", "worker", "aggregator"
    name: str                   # Display name
    description: str
    stage: str                  # "input", "processing", "aggregation", "output"
    is_array: bool = False      # Multiple agents? (fan-out workers)
    required: bool = True
    agent_type: Optional[str] = None  # Suggested agent type

class VariableParameter(BaseModel):
    """Variable aspect of pattern (e.g., number of workers)."""
    name: str                   # "worker_count"
    display_name: str           # "Number of Workers"
    description: str
    param_type: str             # "integer", "string", "boolean"
    default: int | str
    min_value: Optional[int] = None
    max_value: Optional[int] = None
    choices: Optional[List[str]] = None

class PatternTemplate(BaseModel):
    """A reusable composition pattern."""
    pattern_id: str             # "fan-out-fan-in"
    name: str                   # Display name
    version: str                # "1.0"
    category: PatternCategory
    complexity: PatternComplexity
    description: str
    use_cases: List[str]        # ["Document review", "Opinion aggregation"]
    
    # Structure
    diagram_ascii: str          # ASCII diagram of pattern
    placeholders: List[PlaceholderNode]
    variables: List[VariableParameter]  # e.g., number of workers
    
    # Implementation
    code_template: str          # "pattern_templates/fan_out_fan_in.py.jinja2"
    
    # Documentation
    example_workflow: Dict      # JSON example
    prerequisites: List[str]    # ["Understanding of fan-out patterns"]
    
    # Metadata
    created_date: str
    author: str                 # "SAFE Team"
    source: str                 # "builtin" or "user" or "community"
    rating: float               # 4.5/5.0 from usage
    usage_count: int            # How many routes use this?

class PatternRegistry:
    """Manages all patterns (built-in + user-defined)."""
    
    def __init__(self):
        self.builtin_patterns: Dict[str, PatternTemplate] = {}
        self.user_patterns: Dict[str, PatternTemplate] = {}
    
    def register_pattern(self, pattern: PatternTemplate) -> None:
        """Register a new pattern."""
        pass
    
    def get_pattern(self, pattern_id: str) -> PatternTemplate:
        """Get pattern by ID."""
        pass
    
    def list_patterns(self, 
                     category: Optional[PatternCategory] = None,
                     complexity: Optional[PatternComplexity] = None) -> List[PatternTemplate]:
        """List patterns with optional filters."""
        pass
    
    def search_patterns(self, query: str) -> List[PatternTemplate]:
        """Search patterns by keyword."""
        pass
    
    def get_pattern_statistics(self) -> Dict:
        """Usage statistics."""
        pass

# Initialize registry with built-in patterns
PATTERN_REGISTRY = PatternRegistry()

# Auto-register all 12 built-in patterns on import
BUILTIN_PATTERNS = [
    PatternTemplate(...),  # fan-out-fan-in
    PatternTemplate(...),  # map-reduce
    # ... etc
]

for pattern in BUILTIN_PATTERNS:
    PATTERN_REGISTRY.register_pattern(pattern)
```

---

### **2. Pattern Customizer** (`pattern_customizer.py`)

```python
from typing import Dict, List, Optional
from safe_core.pattern_library import PatternTemplate, PatternRegistry

class PatternCustomizer:
    """Interactive pattern customization session."""
    
    def __init__(self, registry: PatternRegistry):
        self.registry = registry
        self.selected_pattern: Optional[PatternTemplate] = None
        self.customization: Dict = {}
        self.conversation_history: List[Dict] = []
    
    async def show_patterns(self) -> None:
        """Display all available patterns with descriptions."""
        pass
    
    async def select_pattern(self, pattern_id: str) -> PatternTemplate:
        """User selects a pattern."""
        pass
    
    async def show_pattern_diagram(self, pattern: PatternTemplate) -> str:
        """Display ASCII diagram of pattern."""
        pass
    
    async def customize_variables(self, pattern: PatternTemplate) -> Dict:
        """
        Interview for variable parameters.
        E.g., "How many parallel workers? (2-10)"
        """
        for var in pattern.variables:
            if var.param_type == "integer":
                value = await ask_integer(
                    var.display_name,
                    min_value=var.min_value,
                    max_value=var.max_value,
                    default=var.default
                )
            # ... handle other types
            self.customization[var.name] = value
        
        return self.customization
    
    async def customize_placeholders(self, pattern: PatternTemplate) -> Dict:
        """
        Interview for agent assignments.
        For each placeholder: "Which agent?"
        """
        assignments = {}
        
        for placeholder in pattern.placeholders:
            if not placeholder.is_array:
                # Single agent
                agent = await ask_agent_selection(
                    f"Agent for {placeholder.name}?",
                    filter_by_type=placeholder.agent_type
                )
                assignments[placeholder.id] = agent
            else:
                # Multiple agents (fan-out case)
                num_workers = self.customization.get("worker_count", 2)
                agents = []
                for i in range(num_workers):
                    agent = await ask_agent_selection(
                        f"Agent for {placeholder.name} #{i+1}?",
                        filter_by_type=placeholder.agent_type
                    )
                    agents.append(agent)
                assignments[placeholder.id] = agents
        
        return assignments
    
    async def customize_conditions(self, pattern: PatternTemplate) -> Dict:
        """
        Interview for conditional patterns.
        E.g., supervisor/manager: define routing conditions
        """
        pass
    
    async def preview_route(self, pattern: PatternTemplate) -> str:
        """Show preview of generated route."""
        pass
    
    async def test_route(self, route_code: str, sample_input: Dict) -> Dict:
        """Test route with sample data."""
        pass
    
    def get_summary(self) -> Dict:
        """Get configuration summary."""
        return {
            "pattern": self.selected_pattern.name,
            "variables": self.customization,
            "assignments": self.assignments,
        }
```

---

### **3. Pattern Authoring** (`pattern_authoring.py`)

```python
from pydantic import BaseModel
from typing import Dict, List, Optional
from enum import Enum

class PatternSubmissionStatus(str, Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    REVIEWING = "reviewing"
    APPROVED = "approved"
    REJECTED = "rejected"
    PUBLISHED = "published"

class UserPatternDefinition(BaseModel):
    """User-created pattern definition."""
    name: str                   # "approval-hierarchy"
    version: str                # "1.0"
    author: str                 # "jane.doe@company.com"
    description: str
    
    # Pattern structure
    placeholders: List[Dict]    # Placeholder definitions
    variables: List[Dict]       # Variable parameters
    topology: Dict              # How pieces connect
    
    # Implementation
    template_code: str          # User-provided Jinja2 template
    
    # Governance
    status: PatternSubmissionStatus = PatternSubmissionStatus.DRAFT
    review_comments: Optional[str] = None
    approved_by: Optional[str] = None
    approved_date: Optional[str] = None
    
    # Sharing
    is_shared: bool = False
    shared_with_teams: List[str] = []
    organization: str           # Company name

class PatternAuthor:
    """Guides users through pattern creation."""
    
    async def start_authoring(self) -> UserPatternDefinition:
        """
        Interactive interview for pattern creation:
        1. Basic info (name, description)
        2. Topology design
        3. Placeholder definition
        4. Variable parameters
        5. Jinja2 template
        6. Test examples
        7. Save as draft
        """
        pass
    
    async def validate_pattern(self, pattern: UserPatternDefinition) -> Dict:
        """
        Validate pattern:
        - Template syntax
        - Placeholder references valid
        - Variables used correctly
        - Test cases pass
        """
        pass
    
    async def submit_for_review(self, pattern: UserPatternDefinition) -> None:
        """Submit pattern for organizational review."""
        pass
    
    async def publish_pattern(self, pattern: UserPatternDefinition) -> None:
        """Publish approved pattern to registry."""
        pass
    
    async def share_pattern(self, pattern: UserPatternDefinition, 
                           teams: List[str]) -> None:
        """Share pattern with specific teams."""
        pass

class PatternGovernance:
    """Governance workflow for user patterns."""
    
    async def review_submission(self, pattern: UserPatternDefinition) -> None:
        """Admin reviews submitted pattern."""
        pass
    
    async def approve_pattern(self, pattern: UserPatternDefinition,
                             comments: str) -> None:
        """Admin approves pattern."""
        pass
    
    async def reject_pattern(self, pattern: UserPatternDefinition,
                            reason: str) -> None:
        """Admin rejects pattern with feedback."""
        pass
    
    async def retire_pattern(self, pattern_id: str) -> None:
        """Gracefully retire a pattern."""
        pass
```

---

## CLI Integration

### **Updated CLI Commands**

```bash
# Pattern discovery
python -m safe_cli.cli list-patterns              # Show all patterns
python -m safe_cli.cli list-patterns --category parallel
python -m safe_cli.cli list-patterns --complexity advanced
python -m safe_cli.cli show-pattern fan-out-fan-in

# Route creation (enhanced)
python -m safe_cli.cli create-route --use-pattern
python -m safe_cli.cli create-route --pattern supervisor-manager

# User patterns (Phase 2+)
python -m safe_cli.cli create-pattern              # Author new pattern
python -m safe_cli.cli list-patterns --user       # Show user patterns
python -m safe_cli.cli submit-pattern my-pattern-v1.0
python -m safe_cli.cli share-pattern my-pattern-v1.0 --teams finance,hr
```

### **New Interactive Flows**

```
Flow 1: Pattern-Driven Route Creation
$ python -m safe_cli.cli create-route --use-pattern

"Choose a pattern category:
  1. Parallel Patterns
  2. Sequential Patterns
  3. Conditional Patterns
  4. Reduction Patterns"
→ User: 1

"Parallel Patterns:
  1. Fan-Out / Fan-In
  2. Map-Reduce
  3. Round-Robin
  4. Mixture of Experts"
→ User: 1

[Shows ASCII diagram of Fan-Out / Fan-In]

"How many parallel workers? (2-10)"
→ User: 4

"Agent for Processor stage?"
→ Available agents...

[Continue for each placeholder]

[Preview route]
[Test with sample input]
[Save to disk]


Flow 2: Pattern Discovery
$ python -m safe_cli.cli list-patterns

"All 12 Patterns:
┌─ PARALLEL (4)
│  ├─ Fan-Out / Fan-In          (Intermediate) ★★★★★ (156 routes)
│  ├─ Map-Reduce                (Intermediate) ★★★★☆ (89 routes)
│  ├─ Round-Robin               (Simple)       ★★★★☆ (42 routes)
│  └─ Mixture of Experts        (Advanced)     ★★★★★ (127 routes)
├─ SEQUENTIAL (5)
│  ├─ Sequential Pipeline       (Simple)       ★★★★★ (203 routes)
│  ├─ Supervisor/Manager        (Advanced)     ★★★★★ (178 routes)
│  ├─ Hierarchical Teams        (Advanced)     ★★★☆☆ (31 routes)
│  ├─ Fallback Chain            (Intermediate) ★★★★☆ (67 routes)
│  └─ Retry Loop                (Intermediate) ★★★★☆ (54 routes)
├─ CONDITIONAL (2)
│  ├─ Diamond                   (Intermediate) ★★★★☆ (43 routes)
│  └─ Conditional Branching     (Advanced)     ★★★★★ (112 routes)
└─ REDUCTION (1)
   └─ Tree-Reduce               (Advanced)     ★★★☆☆ (22 routes)"

"Select pattern name or number to learn more"
→ User: supervisor-manager

[Shows detailed info]
```

---

## Implementation Timeline

### **Phase 1.5: Weeks 4-5**

**Week 4 (Days 1-5)**
- Day 1-2: Pattern library + models (pattern_library.py)
- Day 3: Pattern customizer (pattern_customizer.py)
- Day 4-5: Jinja2 templates (all 12)

**Week 4 (Days 6-10)**
- Day 6-7: Pattern authoring foundation (pattern_authoring.py)
- Day 8-9: CLI integration
- Day 10: Documentation

**Week 5 (Days 11-20)**
- Day 11-15: Comprehensive tests (50+ new tests)
- Day 16-17: Example patterns (5+ worked examples)
- Day 18-19: Integration testing
- Day 20: Documentation + release prep

---

## File Structure

```
safe_phase1/
├── safe_core/
│   ├── pattern_library.py                (NEW, 400 lines)
│   ├── pattern_customizer.py             (NEW, 350 lines)
│   ├── pattern_authoring.py              (NEW, 300 lines)
│   ├── pattern_templates/                (NEW, directory)
│   │   ├── fan_out_fan_in.py.jinja2      (200 lines)
│   │   ├── map_reduce.py.jinja2          (220 lines)
│   │   ├── round_robin.py.jinja2         (180 lines)
│   │   ├── mixture_of_experts.py.jinja2  (200 lines)
│   │   ├── sequential_pipeline.py.jinja2 (180 lines)
│   │   ├── supervisor_manager.py.jinja2  (250 lines)
│   │   ├── hierarchical_teams.py.jinja2  (280 lines)
│   │   ├── fallback_chain.py.jinja2      (200 lines)
│   │   ├── retry_loop.py.jinja2          (220 lines)
│   │   ├── diamond.py.jinja2             (180 lines)
│   │   ├── conditional_branching.py.jinja2 (240 lines)
│   │   └── tree_reduce.py.jinja2         (200 lines)
│   ├── route_writer.py                   (UPDATED, +100 lines)
│   ├── code_generator.py                 (UPDATED, +50 lines)
│   └── example_agents.py                 (unchanged)
│
├── safe_cli/
│   └── cli.py                            (UPDATED, +200 lines)
│
├── tests/
│   ├── test_pattern_library.py           (NEW, 200 lines)
│   ├── test_pattern_customizer.py        (NEW, 250 lines)
│   ├── test_pattern_authoring.py         (NEW, 150 lines)
│   ├── test_patterns_integration.py      (NEW, 400 lines)
│   └── [existing test files]
│
├── examples/
│   ├── patterns/                         (NEW, directory)
│   │   ├── loan_approval_supervisor.py
│   │   ├── document_review_fan_out.py
│   │   ├── batch_processing_map_reduce.py
│   │   ├── customer_support_mixture_experts.py
│   │   └── data_pipeline_sequential.py
│   └── ...
│
├── PHASE_1.5_SPECIFICATION.md            (THIS FILE)
└── [other files unchanged]
```

---

## Test Strategy

### **New Test Coverage (60+ tests)**

#### **Test Categories**

1. **Pattern Library Tests** (20 tests)
   - Pattern registration
   - Pattern retrieval
   - Pattern filtering
   - Statistics
   - Search

2. **Pattern Customizer Tests** (25 tests)
   - Variable customization
   - Placeholder assignment
   - Condition definition
   - Route preview
   - Route testing

3. **Pattern Authoring Tests** (15 tests)
   - Pattern creation
   - Validation
   - Submission workflow
   - Governance flow

4. **Integration Tests** (40+ tests)
   - Each pattern with real agents
   - Edge cases
   - Error handling
   - Performance

### **Example Test**

```python
@pytest.mark.asyncio
async def test_supervisor_manager_pattern_customization():
    """Test customizing supervisor/manager pattern."""
    
    customizer = PatternCustomizer(PATTERN_REGISTRY)
    pattern = await customizer.select_pattern("supervisor-manager")
    
    # User specifies routing branches
    customization = {
        "supervisor_agent": "LoanSupervisor",
        "num_branches": 3,
        "branches": [
            {
                "condition": 'loan_type == "mortgage"',
                "agents": ["MortgageAnalyst", "ComplianceReviewer"]
            },
            {
                "condition": 'loan_type == "auto"',
                "agents": ["AutoLoanAnalyst"]
            },
            {
                "condition": "else",
                "agents": ["PersonalLoanAnalyst"]
            }
        ],
        "aggregator_agent": "LoanDecisionAggregator"
    }
    
    # Generate code
    generator = RouteCodeGenerator()
    code = generator.generate(customization)
    
    # Validate
    validation = SyntaxValidator.validate(code)
    assert validation["valid"]
    
    # Test with sample
    sample_input = {
        "loan_type": "mortgage",
        "amount": 500000,
        "applicant_credit_score": 750
    }
    
    result = await customizer.test_route(code, sample_input)
    assert result["success"]
```

---

## Example Workflows (5 Worked Examples)

### **Example 1: Loan Approval (Supervisor/Manager)**

**Requirement:** Route loan applications to different analysts based on type and amount

```yaml
Pattern: Supervisor/Manager
Name: loan-approval-workflow

Supervisor Agent: LoanSupervisor
Routes:
  - Condition: "loan_type == 'mortgage' AND amount > $500k"
    Agents: [MortgageSpecialist, ComplianceReviewer, ExecutiveApprover]
  
  - Condition: "loan_type == 'mortgage' AND amount ≤ $500k"
    Agents: [MortgageSpecialist, StandardApprover]
  
  - Condition: "loan_type == 'auto'"
    Agents: [AutoLoanSpecialist, StandardApprover]
  
  - Condition: "loan_type == 'personal' AND amount < $10k"
    Agents: [QuickApprovalAgent]
  
  - Condition: "else"
    Agents: [PersonalLoanSpecialist, StandardApprover]

Aggregator: LoanDecisionAggregator

Output: Loan approval/rejection decision
```

### **Example 2: Document Review (Fan-Out / Fan-In)**

**Requirement:** Route document to multiple reviewers, aggregate their reviews

```yaml
Pattern: Fan-Out / Fan-In
Name: document-review-5-reviewers

Processor: DocumentExtractor
Workers (5): [ReviewerA, ReviewerB, ReviewerC, ReviewerD, ReviewerE]
Aggregator: ReviewAggregator

Output: Final review decision
```

### **Example 3: Batch Processing (Map-Reduce)**

**Requirement:** Process 1000 documents in parallel, reduce results

```yaml
Pattern: Map-Reduce
Name: batch-document-processing

Splitter: DocumentSplitter
Mappers (10): DocumentAnalyzer (x10 parallel)
Shuffle: ResultShuffler
Reducers (3): ResultReducer (x3 parallel)
Final: FinalAggregator

Output: Consolidated analysis of 1000 documents
```

### **Example 4: Customer Support (Mixture of Experts)**

**Requirement:** Route support tickets to specialists by type

```yaml
Pattern: Mixture of Experts
Name: customer-support-routing

Router: SupportTicketRouter

Specialists:
  - Condition: "type == 'billing'"
    Expert: BillingSpecialist
  
  - Condition: "type == 'technical'"
    Expert: TechSupportSpecialist
  
  - Condition: "type == 'legal'"
    Expert: LegalSpecialist
  
  - Condition: "else"
    Expert: GeneralSupport

Aggregator: ResponseAggregator

Output: Customer response
```

### **Example 5: Data Pipeline (Sequential)**

**Requirement:** Process data through multi-stage pipeline

```yaml
Pattern: Sequential Pipeline
Name: customer-data-pipeline

Stage 1: DataExtractor
Stage 2: DataValidator
Stage 3: DataEnricher (calls external APIs)
Stage 4: DataAnalyzer
Stage 5: DataStorer (save to database)

Output: Stored, processed data
```

---

## Success Criteria

### **Phase 1.5 Definition of Done**

**Code Quality**
- ✅ All 12 patterns fully implemented
- ✅ 60+ new tests, 90%+ coverage
- ✅ All code type-hinted
- ✅ All code documented (Google-style docstrings)
- ✅ Passes linting (black, ruff, mypy)

**Functionality**
- ✅ Pattern selection via CLI works
- ✅ All 12 patterns generate valid code
- ✅ Code compilation tests pass
- ✅ User pattern authoring foundation complete
- ✅ CLI shows pattern diagrams and descriptions

**Documentation**
- ✅ Pattern library guide (this spec)
- ✅ CLI help for all new commands
- ✅ 5+ worked examples
- ✅ Developer guide updates
- ✅ User quick reference updates

**Performance**
- ✅ Pattern selection: <100ms
- ✅ Code generation: <200ms per pattern
- ✅ Customization interview: responsive
- ✅ Pattern registry load: <50ms

**User Experience**
- ✅ Pattern discovery clear and organized
- ✅ Interactive interviews intuitive
- ✅ ASCII diagrams helpful
- ✅ Error messages helpful
- ✅ CSA time-to-route: 5-10 minutes

---

## Effort Breakdown

| Task | Days | Notes |
|------|------|-------|
| Pattern models + library | 3 | 400 lines Python |
| Pattern customizer | 3 | 350 lines Python |
| 12 Jinja2 templates | 4 | ~150-280 lines each |
| Pattern authoring | 2 | Foundation for Phase 2+ |
| CLI integration | 2 | New commands |
| Tests | 4 | 60+ tests |
| Examples | 3 | 5 worked examples |
| Documentation | 2 | Spec + guides |
| Integration | 2 | End-to-end testing |
| **Total** | **25 days** | ~4 weeks, one engineer |

---

## Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| Complex templates | Start with simple patterns, iterate |
| User pattern governance | MVP: approval workflow only, full marketplace Phase 2+ |
| Pattern discovery UX | User testing with CSA team |
| Performance with many patterns | Index patterns, lazy-load templates |
| Backwards compatibility | Phase 1 routes still work unchanged |

---

## What Phase 1.5 Enables

✅ **5x faster route creation** — 5-10 minutes vs 30+ minutes  
✅ **User pattern foundation** — CSAs create org-specific patterns  
✅ **Community library** — Share patterns across teams  
✅ **Consistency** — All fan-out-fan-in routes follow same topology  
✅ **Non-trivial patterns** — Supervisor/Manager, conditional branching  
✅ **Real-world workflows** — 80% of use cases covered  

---

## Next Phase (Phase 2)

**Health Registry** will integrate with patterns:
- Monitor each pattern type separately
- Pattern-specific health checks
- Pattern-specific optimizations
- Auto-suggestion: "This pattern usually has issues X, Y, Z"

---

## Questions?

See Phase 1.5 implementation code and examples (next sections).

---

**Phase 1.5 Status:** ✅ Specification Complete, Ready for Implementation

**Timeline:** Weeks 4-5 of 12-week plan  
**Effort:** One senior engineer, 25 days  
**Impact:** 5x faster CSA onboarding
