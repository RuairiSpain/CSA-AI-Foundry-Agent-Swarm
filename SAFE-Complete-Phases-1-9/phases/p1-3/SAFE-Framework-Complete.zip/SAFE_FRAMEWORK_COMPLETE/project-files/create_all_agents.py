#!/usr/bin/env python3
"""
Generate all remaining agent templates for SAFE Phase 2.
Creates 21 agents with 4 files each (84 total files).
"""

from pathlib import Path
import yaml

# Base agent data from CATALOG.yaml
agents_data = {
    "standalone": {
        "rag-query": {
            "name": "RAG Query Agent",
            "category": "retrieval",
            "description": "Vector-based retrieval-augmented generation for Q&A",
            "inputs": ["query", "documents"],
            "outputs": ["answer", "sources"]
        },
        "reviewer": {
            "name": "Document Reviewer",
            "category": "processing",
            "description": "Reviews documents for quality, accuracy, compliance",
            "inputs": ["document"],
            "outputs": ["review_result"]
        },
        "summarizer": {
            "name": "Text Summarizer",
            "category": "processing",
            "description": "Generates concise summaries from long documents",
            "inputs": ["text"],
            "outputs": ["summary"]
        },
        "semantic-search": {
            "name": "Semantic Search Agent",
            "category": "retrieval",
            "description": "Semantic similarity search across documents",
            "inputs": ["query", "documents"],
            "outputs": ["matches"]
        },
        "web-query": {
            "name": "Web Query Agent",
            "category": "retrieval",
            "description": "Performs web searches and aggregates results",
            "inputs": ["query"],
            "outputs": ["results"]
        },
        "researcher": {
            "name": "Research Agent",
            "category": "processing",
            "description": "Multi-step research and synthesis",
            "inputs": ["topic", "sources"],
            "outputs": ["research_report"]
        },
        "presenter-word": {
            "name": "Word Document Presenter",
            "category": "generation",
            "description": "Formats analysis results into Word documents",
            "inputs": ["content"],
            "outputs": ["docx_file"]
        },
        "presenter-html": {
            "name": "HTML Presenter",
            "category": "generation",
            "description": "Generates HTML presentations and dashboards",
            "inputs": ["data"],
            "outputs": ["html_string"]
        },
        "presenter-markdown": {
            "name": "Markdown Presenter",
            "category": "generation",
            "description": "Formats output as readable Markdown",
            "inputs": ["data"],
            "outputs": ["markdown_string"]
        },
        "presenter-code": {
            "name": "Code Presenter",
            "category": "generation",
            "description": "Generates formatted code with explanations",
            "inputs": ["code_spec"],
            "outputs": ["code_with_comments"]
        },
    },
    "patterns": {
        "supervisor-manager": {
            "supervisor": {
                "name": "Supervisor Router",
                "description": "Routes applications to specialist agents"
            },
            "aggregator": {
                "name": "Decision Aggregator",
                "description": "Combines specialist decisions"
            }
        },
        "fan-out-fan-in": {
            "processor": {
                "name": "Fan-Out Processor",
                "description": "Preprocesses data for parallel workers"
            },
            "worker": {
                "name": "Parallel Worker",
                "description": "Processes data chunk in parallel"
            },
            "aggregator": {
                "name": "Fan-In Aggregator",
                "description": "Aggregates parallel results"
            }
        },
        "map-reduce": {
            "splitter": {
                "name": "Batch Splitter",
                "description": "Splits data for mappers"
            },
            "mapper": {
                "name": "Data Mapper",
                "description": "Maps/transforms data in parallel"
            },
            "shuffle": {
                "name": "Shuffle Aggregator",
                "description": "Reorganizes mapped data"
            },
            "reducer": {
                "name": "Data Reducer",
                "description": "Reduces shuffled data in parallel"
            },
            "final": {
                "name": "Final Aggregator",
                "description": "Final aggregation of results"
            }
        },
        "sequential-pipeline": {
            "stage1": {
                "name": "Pipeline Stage 1",
                "description": "First stage of pipeline"
            }
        }
    }
}

def create_agent_yaml(name, category, description, inputs, outputs):
    """Create agent.yaml content"""
    return f"""name: {name}
version: 1.0
category: {category}
description: |
  {description}

contract:
  inputs:
    - name: input_param
      type: object
      required: true
      description: Input data
      schema:
        type: object
        required_fields: [field1]
        field_definitions:
          field1:
            type: string
            description: Field description
  
  outputs:
    - name: output_param
      type: object
      required: true
      description: Output data
      schema:
        type: object
        required_fields: [result]

metadata:
  author: SAFE Team
  source:
    repository: internal
    license: MIT
  dependencies: []
  requirements:
    python: ">=3.11"
    packages: []
  timeout_seconds: 60

documentation:
  use_cases:
    - Use case 1
    - Use case 2
  example:
    input: {{field1: "example"}}
    output: {{result: "example"}}
  limitations:
    - Limitation 1

tags:
  - {category}

pattern_roles: []
"""

def create_agent_md(name, description):
    """Create agent.md content"""
    return f"""# {name}

## Overview
{description}

## Contract

### Inputs
- input_param (object): Input parameter

### Outputs
- output_param (object): Output parameter

## Usage

```python
from agents.{name.lower().replace(' ', '_')} import Agent

agent = Agent()
result = await agent.invoke({{"input": "..."}})
```

## Use Cases
- Use case 1
- Use case 2

## Dependencies
- (See requirements.txt)

## Limitations
- Limitation 1

## Related Agents
- Other agents

---

**Status:** Production Ready  
**Version:** 1.0  
**Framework:** SAFE 1.0
"""

def create_prompt(name, description):
    """Create prompt.txt content"""
    return f"""You are the {name} agent.

Your role: {description}

Your task: Process input and return structured output.

Instructions:
1. Validate input
2. Process data
3. Return output in JSON format

Output Format:
{{
  "status": "success|error",
  "data": {{}},
  "error_message": "[Optional]"
}}

---

Agent: {name}
Version: 1.0
Framework: SAFE 1.0
"""

def create_requirements():
    """Create requirements.txt content"""
    return """# Agent Dependencies
# Add required packages here
"""

def main():
    base_path = Path("/home/claude/PHASE_2_AGENTS")
    
    count = 0
    
    # Create standalone agents
    for agent_id, data in agents_data["standalone"].items():
        agent_dir = base_path / "standalone" / agent_id
        agent_dir.mkdir(parents=True, exist_ok=True)
        
        # Create files
        (agent_dir / "agent.yaml").write_text(
            create_agent_yaml(data["name"], data["category"], data["description"], 
                            data["inputs"], data["outputs"])
        )
        (agent_dir / "agent.md").write_text(create_agent_md(data["name"], data["description"]))
        (agent_dir / "prompt.txt").write_text(create_prompt(data["name"], data["description"]))
        (agent_dir / "requirements.txt").write_text(create_requirements())
        
        count += 1
        print(f"✓ {agent_id}")
    
    # Create pattern agents
    for pattern_name, agents_dict in agents_data["patterns"].items():
        for placeholder_name, placeholder_data in agents_dict.items():
            agent_dir = base_path / "patterns" / pattern_name / placeholder_name
            agent_dir.mkdir(parents=True, exist_ok=True)
            
            # Create files
            (agent_dir / "agent.yaml").write_text(
                create_agent_yaml(placeholder_data["name"], "processing", 
                                placeholder_data["description"], [], [])
            )
            (agent_dir / "agent.md").write_text(
                create_agent_md(placeholder_data["name"], placeholder_data["description"])
            )
            (agent_dir / "prompt.txt").write_text(
                create_prompt(placeholder_data["name"], placeholder_data["description"])
            )
            (agent_dir / "requirements.txt").write_text(create_requirements())
            
            count += 1
            print(f"✓ {pattern_name}/{placeholder_name}")
    
    print(f"\n✅ Created {count} agents with {count * 4} files")

if __name__ == "__main__":
    main()
