# safe_cli/agent_commands.py
"""
Agent-related CLI commands for SAFE Framework.
Handles agent discovery, selection, provisioning, and validation.
"""

import os
import json
import shutil
import subprocess
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

import typer
import yaml
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax

console = Console()
app = typer.Typer()


# ============================================================================
# Agent Commands
# ============================================================================

@app.command()
def list_agents(
    category: Optional[str] = typer.Option(None, "--category", help="Filter by category"),
    pattern: Optional[str] = typer.Option(None, "--pattern", help="Filter by pattern"),
    complexity: Optional[str] = typer.Option(None, "--complexity", help="Filter by complexity (simple/intermediate/advanced)"),
    min_rating: Optional[float] = typer.Option(None, "--min-rating", help="Minimum quality rating")
):
    """List all available agent templates."""
    from safe_core.agent_discovery import AgentDiscovery
    
    catalog = load_catalog()
    discovery = AgentDiscovery(catalog)
    
    agents = discovery.filter_agents(
        category=category,
        pattern=pattern,
        complexity=complexity,
        min_rating=min_rating
    )
    
    if not agents:
        console.print("[yellow]No agents found matching criteria.[/yellow]")
        return
    
    # Create table
    table = Table(title="Available Agent Templates")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Category")
    table.add_column("Complexity")
    table.add_column("Rating")
    table.add_column("Usage")
    
    for agent in agents:
        agent_id = agent.get("id", "")
        name = agent.get("name", "")
        cat = agent.get("category", "")
        complexity = agent.get("discovery", {}).get("complexity", "")
        rating = agent.get("discovery", {}).get("quality_rating", 0)
        usage = agent.get("discovery", {}).get("usage_count", 0)
        
        # Add star rating
        stars = "⭐" * int(rating)
        
        table.add_row(agent_id, name, cat, complexity, f"{stars} {rating:.1f}", str(usage))
    
    console.print(table)


@app.command()
def show_agent(agent_id: str):
    """Show detailed information about an agent."""
    from safe_core.agent_discovery import AgentDiscovery
    
    catalog = load_catalog()
    discovery = AgentDiscovery(catalog)
    
    agent = discovery.get_agent(agent_id)
    
    if not agent:
        console.print(f"[red]Agent '{agent_id}' not found.[/red]")
        return
    
    # Display agent details
    console.print(Panel.fit(f"[bold]{agent.get('name')}[/bold] v{agent.get('version')}", 
                           style="blue"))
    
    console.print(f"\n[bold]Description:[/bold]\n{agent.get('description', 'N/A')}")
    
    # Contract
    contract = agent.get("contract", {})
    console.print(f"\n[bold]Contract:[/bold]")
    console.print(f"  [cyan]Inputs:[/cyan] {len(contract.get('inputs', []))} input(s)")
    for inp in contract.get("inputs", []):
        console.print(f"    - {inp.get('name')} ({inp.get('type')})")
    
    console.print(f"  [cyan]Outputs:[/cyan] {len(contract.get('outputs', []))} output(s)")
    for out in contract.get("outputs", []):
        console.print(f"    - {out.get('name')} ({out.get('type')})")
    
    # Use cases
    use_cases = agent.get("use_cases", [])
    if use_cases:
        console.print(f"\n[bold]Use Cases:[/bold]")
        for uc in use_cases:
            console.print(f"  • {uc}")
    
    # Metadata
    metadata = agent.get("metadata", {})
    console.print(f"\n[bold]Metadata:[/bold]")
    console.print(f"  Author: {metadata.get('author', 'N/A')}")
    console.print(f"  License: {metadata.get('source', {}).get('license', 'N/A')}")
    console.print(f"  Timeout: {metadata.get('timeout_seconds', 60)}s")
    
    # Discovery
    discovery_info = agent.get("discovery", {})
    console.print(f"\n[bold]Discovery:[/bold]")
    console.print(f"  Rating: {'⭐' * int(discovery_info.get('quality_rating', 0))} {discovery_info.get('quality_rating', 0):.1f}")
    console.print(f"  Usage Count: {discovery_info.get('usage_count', 0)}")
    console.print(f"  Complexity: {discovery_info.get('complexity', 'N/A')}")
    
    # Keywords
    keywords = discovery_info.get("keywords", [])
    if keywords:
        console.print(f"  Keywords: {', '.join(keywords)}")


@app.command()
def search_agents(query: str):
    """Search agents by keyword."""
    from safe_core.agent_discovery import AgentDiscovery
    
    catalog = load_catalog()
    discovery = AgentDiscovery(catalog)
    
    results = discovery.search_agents(query)
    
    if not results:
        console.print(f"[yellow]No agents found matching '{query}'[/yellow]")
        return
    
    console.print(f"\n[green]Found {len(results)} agent(s) matching '{query}':[/green]\n")
    
    for i, agent in enumerate(results, 1):
        rating = agent.get("discovery", {}).get("quality_rating", 0)
        stars = "⭐" * int(rating)
        console.print(f"{i}. [cyan]{agent.get('name')}[/cyan] ({agent.get('id')})")
        console.print(f"   {agent.get('description', '')}")
        console.print(f"   {stars} {rating:.1f} | Usage: {agent.get('discovery', {}).get('usage_count', 0)}")
        console.print()


@app.command()
def create_agent(from_template: Optional[str] = typer.Option(None, "--from-template", 
                                                             help="Copy from template agent ID")):
    """Create a new agent from template."""
    from safe_core.agent_discovery import AgentDiscovery
    
    catalog = load_catalog()
    discovery = AgentDiscovery(catalog)
    
    # If from_template not specified, show interactive selection
    if not from_template:
        console.print("\n[bold]Select agent template to copy:[/bold]\n")
        
        # Show categories
        console.print("Categories:")
        console.print("  1. Standalone agents")
        console.print("  2. Pattern-specific agents")
        
        choice = Prompt.ask("Choose", choices=["1", "2"])
        
        if choice == "1":
            agents = discovery.filter_agents()
            # Filter to standalone only
            agents = [a for a in agents if a.get("id") and "_" not in a.get("id")]
        else:
            agents = discovery.filter_agents()
            # Filter to pattern only
            agents = [a for a in agents if a.get("id") and "_" in a.get("id")]
        
        # Show selection
        for i, agent in enumerate(agents, 1):
            console.print(f"{i}. {agent.get('name')} ({agent.get('id')})")
        
        idx = int(Prompt.ask("Select agent", choices=[str(i) for i in range(1, len(agents) + 1)])) - 1
        from_template = agents[idx].get("id")
    
    # Load template agent
    agent = discovery.get_agent(from_template)
    if not agent:
        console.print(f"[red]Template agent '{from_template}' not found.[/red]")
        return
    
    # Get project root
    project_root = Path.cwd()
    agents_dir = project_root / "agents"
    
    # Get agent name from user
    agent_name = Prompt.ask("Agent directory name", default=agent.get("id"))
    agent_path = agents_dir / agent_name
    
    # Check if already exists
    if agent_path.exists():
        if not Confirm.ask(f"Directory {agent_path} exists. Overwrite?"):
            console.print("[yellow]Cancelled.[/yellow]")
            return
        shutil.rmtree(agent_path)
    
    # Create agent directory
    agent_path.mkdir(parents=True, exist_ok=True)
    
    # Create agent.yaml
    agent_yaml = agent_path / "agent.yaml"
    with open(agent_yaml, "w") as f:
        yaml.dump(agent, f, default_flow_style=False, sort_keys=False)
    
    # Create .agent-metadata.yml
    metadata_file = agent_path / ".agent-metadata.yml"
    metadata = {
        "source_template": f"templates/agents/{agent.get('id')}",
        "source_version": agent.get("version", "1.0"),
        "copied_date": "2026-06-20",
        "customized": False,
        "pattern_assignment": agent.get("pattern_assignment")
    }
    with open(metadata_file, "w") as f:
        yaml.dump(metadata, f, default_flow_style=False)
    
    # Create agent.md (documentation)
    doc_file = agent_path / "agent.md"
    with open(doc_file, "w") as f:
        f.write(f"# {agent.get('name')}\n\n")
        f.write(f"{agent.get('description')}\n\n")
        f.write("## Contract\n\n")
        f.write("### Inputs\n")
        for inp in agent.get("contract", {}).get("inputs", []):
            f.write(f"- **{inp.get('name')}** ({inp.get('type')})\n")
        f.write("\n### Outputs\n")
        for out in agent.get("contract", {}).get("outputs", []):
            f.write(f"- **{out.get('name')}** ({out.get('type')})\n")
    
    # Create requirements.txt
    req_file = agent_path / "requirements.txt"
    packages = agent.get("metadata", {}).get("requirements", {}).get("packages", [])
    with open(req_file, "w") as f:
        for pkg in packages:
            f.write(f"{pkg}\n")
    
    console.print(f"\n[green]✅ Agent created at:[/green] {agent_path}")
    console.print(f"\n[bold]Files created:[/bold]")
    console.print(f"  • agent.yaml (contract + metadata)")
    console.print(f"  • agent.md (documentation)")
    console.print(f"  • requirements.txt (dependencies)")
    console.print(f"  • .agent-metadata.yml (tracking)")
    
    # Install requirements
    if Confirm.ask("\nInstall requirements?"):
        console.print("[cyan]Installing dependencies...[/cyan]")
        subprocess.run([
            "pip", "install", "-r", str(req_file)
        ], cwd=str(project_root))
        console.print("[green]✅ Dependencies installed[/green]")


@app.command()
def validate_agent(
    agent_path: str = typer.Argument(..., help="Path to agent directory"),
    pattern: str = typer.Option(..., "--pattern", help="Pattern ID"),
    placeholder: str = typer.Option(..., "--placeholder", help="Placeholder ID")
):
    """Validate agent compatibility with pattern placeholder."""
    from safe_core.agent_validation import ContractValidator
    
    # Load agent YAML
    agent_yaml_path = Path(agent_path) / "agent.yaml"
    if not agent_yaml_path.exists():
        console.print(f"[red]agent.yaml not found at {agent_yaml_path}[/red]")
        return
    
    with open(agent_yaml_path) as f:
        agent_contract = yaml.safe_load(f)
    
    # Validate
    validator = ContractValidator()
    result = validator.validate_agent_for_pattern(
        agent_contract=agent_contract,
        pattern_id=pattern,
        placeholder_id=placeholder
    )
    
    # Display results
    if result.valid:
        console.print(f"\n[green]✅ Agent is compatible[/green]")
        console.print(f"  Pattern: {pattern}")
        console.print(f"  Placeholder: {placeholder}")
        
        if result.required_outputs:
            console.print(f"\n  Required outputs: {', '.join(result.required_outputs)}")
        
        if result.agent_outputs:
            console.print(f"  Agent outputs: {', '.join(result.agent_outputs.keys())}")
    else:
        console.print(f"\n[red]❌ Agent is not compatible[/red]")
        console.print(f"  Pattern: {pattern}")
        console.print(f"  Placeholder: {placeholder}")
        
        console.print(f"\n[red]Errors:[/red]")
        for error in result.errors:
            console.print(f"  • {error}")
    
    if result.warnings:
        console.print(f"\n[yellow]Warnings:[/yellow]")
        for warning in result.warnings:
            console.print(f"  ⚠️  {warning}")


@app.command()
def agent_stats():
    """Show agent catalog statistics."""
    from safe_core.agent_discovery import AgentDiscovery
    
    catalog = load_catalog()
    discovery = AgentDiscovery(catalog)
    
    stats = discovery.get_agent_stats()
    
    console.print(Panel.fit("[bold]Agent Catalog Statistics[/bold]", style="blue"))
    
    console.print(f"\n[bold]Overview:[/bold]")
    console.print(f"  Total agents: {stats['total_agents']}")
    console.print(f"  Standalone: {stats['standalone_agents']}")
    console.print(f"  Pattern-specific: {stats['pattern_agents']}")
    console.print(f"  Average rating: {stats['average_rating']:.2f}⭐")
    
    console.print(f"\n[bold]By Category:[/bold]")
    for cat, count in sorted(stats['by_category'].items()):
        console.print(f"  {cat}: {count}")
    
    console.print(f"\n[bold]Most Used:[/bold]")
    for agent in stats['most_used']:
        usage = agent.get('discovery', {}).get('usage_count', 0)
        console.print(f"  • {agent.get('name')} ({usage} uses)")


# ============================================================================
# Route Creation Integration
# ============================================================================

@app.command()
def create_route_interactive(pattern: Optional[str] = typer.Option(None, "--pattern", help="Pattern ID")):
    """Create a route interactively, selecting agents for pattern placeholders."""
    from safe_core.agent_discovery import AgentDiscovery
    from safe_core.pattern_library import PATTERN_REGISTRY
    
    # Load pattern
    if not pattern:
        console.print("\n[bold]Available patterns:[/bold]")
        console.print("  1. supervisor-manager")
        console.print("  2. fan-out-fan-in")
        console.print("  3. map-reduce")
        console.print("  4. sequential-pipeline")
        pattern = Prompt.ask("Select pattern", choices=["1", "2", "3", "4"])
        
        pattern_map = {
            "1": "supervisor-manager",
            "2": "fan-out-fan-in",
            "3": "map-reduce",
            "4": "sequential-pipeline"
        }
        pattern = pattern_map[pattern]
    
    # Load pattern
    pat_obj = PATTERN_REGISTRY.get_pattern(pattern)
    if not pat_obj:
        console.print(f"[red]Pattern '{pattern}' not found.[/red]")
        return
    
    catalog = load_catalog()
    discovery = AgentDiscovery(catalog)
    
    # For each placeholder, select agent
    selected_agents = {}
    
    for placeholder in pat_obj.placeholders:
        console.print(f"\n[bold]Select agent for placeholder: {placeholder.id}[/bold]")
        
        # Get suggestions
        suggestions = discovery.suggest_agents(pattern, placeholder.id)
        
        console.print("[green]Recommended agents:[/green]")
        for i, agent in enumerate(suggestions[:5], 1):
            console.print(f"  {i}. {agent.get('name')} ({agent.get('id')})")
        
        idx = int(Prompt.ask("Select", choices=[str(i) for i in range(1, 6)])) - 1
        selected_agents[placeholder.id] = suggestions[idx]
    
    # Create route
    route_name = Prompt.ask("Route name")
    
    console.print(f"\n[green]✅ Route created: {route_name}[/green]")
    console.print(f"  Pattern: {pattern}")
    for placeholder_id, agent in selected_agents.items():
        console.print(f"  {placeholder_id}: {agent.get('name')}")


# ============================================================================
# Helper Functions
# ============================================================================

def load_catalog() -> Dict[str, Any]:
    """Load CATALOG.yaml."""
    catalog_path = Path(__file__).parent.parent / "templates" / "agents" / "CATALOG.yaml"
    
    if not catalog_path.exists():
        # Try relative path
        catalog_path = Path("templates/agents/CATALOG.yaml")
    
    if not catalog_path.exists():
        console.print(f"[red]CATALOG.yaml not found at {catalog_path}[/red]")
        return {}
    
    with open(catalog_path) as f:
        return yaml.safe_load(f)


# ============================================================================
# Register commands with main CLI app
# ============================================================================

def register_agent_commands(main_app: typer.Typer):
    """Register all agent commands with main CLI."""
    main_app.command()(list_agents)
    main_app.command()(show_agent)
    main_app.command()(search_agents)
    main_app.command()(create_agent)
    main_app.command()(validate_agent)
    main_app.command()(agent_stats)
    main_app.command()(create_route_interactive)


if __name__ == "__main__":
    app()
