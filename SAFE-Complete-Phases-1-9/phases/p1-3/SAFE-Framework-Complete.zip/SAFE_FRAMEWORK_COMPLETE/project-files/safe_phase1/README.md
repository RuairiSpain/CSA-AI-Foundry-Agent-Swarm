# SAFE Framework Phase 1: Route Writer Agent

**Status:** Production-Ready (Phase 1 MVP)  
**Version:** 0.1.0  
**Last Updated:** 2026-06-20

## Overview

SAFE (Simplified Agent Flow Engineering) is a framework for building governed, composable multi-agent workflows. **Phase 1** delivers the **Route Writer Agent** — an interactive tool that generates production-ready Python route code from simple interviews.

### What is a Route?

A **route** is a governance layer that orchestrates multiple agents:
- **Static routes**: Fixed topologies (sequential, fan-out, etc.)
- **Dynamic routes**: Decision-driven routing based on runtime data

Routes are generated as Python code, validated for syntax, and stored in a catalog for reuse.

---

## Quick Start (5 minutes)

### 1. Setup

```bash
# Clone or navigate to the project
cd safe_phase1

# Create virtual environment with uv
uv venv .venv

# Activate
source .venv/bin/activate  # or .venv\Scripts\activate on Windows

# Install dependencies
uv pip install -e ".[dev]"

# Verify installation
python -c "import safe_core; print(f'SAFE {safe_core.__version__} installed')"
```

### 2. Run Tests

```bash
# Run all tests with coverage
pytest

# Run specific test file
pytest tests/test_route_writer.py -v

# Run with coverage report
pytest --cov=safe_core --cov-report=html
```

### 3. Create Your First Route (Interactive)

```bash
# Start the CLI
python -m safe_cli.cli create-route

# Follow the interactive prompts:
#   1. Enter route name (e.g., "my-first-route")
#   2. Add description
#   3. Choose static or dynamic
#   4. Select agents
#   5. Configure pattern/conditions
#   6. Review generated code
#   7. Test with sample input
#   8. Save to disk
```

### 4. List Available Agents

```bash
python -m safe_cli.cli list-agents
```

---

## Project Structure

```
safe_phase1/
├── pyproject.toml              # uv/pip configuration
├── README.md                   # This file
├── safe_core/                  # Core framework
│   ├── __init__.py
│   ├── route_definitions.py    # Pydantic models (static/dynamic routes)
│   ├── code_generator.py       # Jinja2 code generation + syntax validation
│   ├── route_writer.py         # Route Writer Agent (interview logic)
│   ├── example_agents.py       # Example micro-agents for testing
│   └── templates/
│       ├── static_route.py.jinja2   # Template for static routes
│       └── dynamic_route.py.jinja2  # Template for dynamic routes
├── safe_cli/                   # CLI commands
│   ├── __init__.py
│   └── cli.py                  # Typer CLI interface
├── tests/                      # Comprehensive test suite
│   ├── __init__.py
│   ├── test_route_definitions.py
│   ├── test_code_generator.py
│   ├── test_route_writer.py
│   └── test_integration.py
└── routes/                     # Generated routes (created at runtime)
```

---

## Usage Examples

### Example 1: Create a Static Sequential Route (Python)

```python
from safe_core.route_writer import RouteWriterSession

# Create session
session = RouteWriterSession()

# Configure route
session.set_basics("document-review", "Reviews documents", "static")
session.set_agents(["DocumentExtractor", "DocumentReviewer", "DocumentAggregator"])
session.set_pattern("sequential")

# Generate code
code = session.generate_code()
print(code)

# Test with sample data
result = session.test_route({"document": "test.pdf"})
print(result)

# Get summary
summary = session.get_summary()
print(summary)
```

### Example 2: Create a Dynamic Route (Python)

```python
from safe_core.route_writer import RouteWriterSession

session = RouteWriterSession()

session.set_basics("document-routing", "Routes by type", "dynamic")
session.set_dynamic_routing(
    decision_inputs=["doc_type", "sensitivity"],
    routes=[
        {"condition": 'doc_type == "contract"', "agents": ["LegalReviewer"]},
        {"condition": 'doc_type == "policy"', "agents": ["PolicyReviewer"]},
        {"condition": 'sensitivity == "high"', "agents": ["SecurityReviewer"]},
    ],
    fallback_agents=["GeneralReviewer"],
)

code = session.generate_code()
print(code)
```

### Example 3: Use CLI to Create Route

```bash
# Non-interactive (for CI/CD)
# (Future: will support --name, --type, --agents flags)

# Interactive (current)
python -m safe_cli.cli create-route
```

---

## Core Components

### 1. Route Definitions (`route_definitions.py`)

Pydantic models that define routes:

```python
from safe_core.route_definitions import StaticRouteDefinition, AgentConfig

agents = [
    AgentConfig(name="Agent1"),
    AgentConfig(name="Agent2"),
]

route = StaticRouteDefinition(
    name="my-route",
    description="My route",
    pattern="sequential",
    agents=agents,
)
```

**Models:**
- `ErrorPolicy`: How agents handle failures (fail_hard, skip_if_error, retry)
- `AgentConfig`: Agent configuration (name, version, error_policy, timeout)
- `StaticRouteDefinition`: Fixed-topology routes
- `DynamicRouteDefinition`: Decision-driven routes
- `ConditionalRoute`: A conditional branch

### 2. Code Generator (`code_generator.py`)

Generates Python code from definitions:

```python
from safe_core.code_generator import RouteCodeGenerator

generator = RouteCodeGenerator()
code = generator.generate_static_route(definition)
```

**Features:**
- Jinja2-based code templates
- Syntax validation (compile check)
- Support for static and dynamic routes
- Async/await compatible

### 3. Route Writer (`route_writer.py`)

Interactive session for building routes:

```python
from safe_core.route_writer import RouteWriterSession

session = RouteWriterSession()
session.set_basics("name", "description", "static")
session.set_agents(["Agent1", "Agent2"])
session.set_pattern("sequential")
code = session.generate_code()
```

**Session Methods:**
- `set_basics(name, description, type)`: Set basic info
- `set_agents(names)`: Add agents
- `set_pattern(pattern)`: Set orchestration pattern (static)
- `set_dynamic_routing(inputs, routes, fallback)`: Configure dynamic routing
- `generate_code()`: Generate Python code
- `test_route(sample_input)`: Test code compilation
- `get_summary()`: Get configuration summary

### 4. Example Agents (`example_agents.py`)

Mock agents for testing and demonstration:

- `DocumentExtractorAgent`: Extracts metadata
- `DocumentReviewerAgent`: Reviews documents
- `DocumentAggregatorAgent`: Aggregates results
- `CourseManagerAgent`: Manages course creation
- `ChapterWriterAgent`: Writes chapters
- `CriticAgent`: Critiques content
- `DesignerAgent`: Designs presentations
- `BrandValidatorAgent`: Validates branding
- `PublisherAgent`: Publishes to OneDrive

All agents implement `async invoke(input_data)` interface.

### 5. CLI (`safe_cli/cli.py`)

Command-line interface using Typer:

```bash
# Create route interactively
python -m safe_cli.cli create-route

# List agents
python -m safe_cli.cli list-agents

# Validate code
python -m safe_cli.cli validate-code routes/my-route/v1.0.py

# Show template
python -m safe_cli.cli show-template static
python -m safe_cli.cli show-template dynamic

# Show version
python -m safe_cli.cli version
```

---

## Testing

### Run All Tests

```bash
pytest
# or with verbose output
pytest -v

# or with coverage
pytest --cov=safe_core --cov-report=html
```

### Test Coverage

Phase 1 includes comprehensive tests:

| Module | Test File | Coverage |
|--------|-----------|----------|
| `route_definitions.py` | `test_route_definitions.py` | 95%+ |
| `code_generator.py` | `test_code_generator.py` | 90%+ |
| `route_writer.py` | `test_route_writer.py` | 92%+ |
| Integration | `test_integration.py` | End-to-end scenarios |

### Example Tests

```python
# Test route definition
def test_static_route_creation():
    route = StaticRouteDefinition(
        name="test-route",
        pattern="sequential",
        agents=[AgentConfig(name="Agent")],
    )
    assert route.name == "test-route"

# Test code generation
def test_generate_static_route():
    generator = RouteCodeGenerator()
    code = generator.generate_static_route(definition)
    assert "route_test_route" in code
    assert SyntaxValidator.validate(code)["valid"]

# Test Route Writer
def test_route_writer_workflow():
    session = RouteWriterSession()
    session.set_basics("test", "test", "static")
    session.set_agents(["Agent"])
    session.set_pattern("sequential")
    code = session.generate_code()
    assert code is not None
```

---

## Generated Route Structure

When you generate a route, you get Python code with this structure:

```python
# File: routes/{route_name}/v{version}.py
# Generated by: DynamicRouteWriterAgent

import asyncio
from semantic_kernel import Kernel
from safe.workflow import TraceContext, WorkflowInput, WorkflowOutput

async def route_{route_name}(
    kernel: Kernel,
    input: WorkflowInput,
    trace_context: TraceContext,
) -> WorkflowOutput:
    """Route: {description}"""
    
    with trace_context.span("route_{name}") as root_span:
        # Setup
        # Agent invocations
        # Error handling
        # Results aggregation
        # Return final output
        
    return final_result
```

**Generated Routes Include:**
- Full type hints (type-safe)
- Async/await (non-blocking)
- OpenTelemetry tracing (observability)
- Error handling per agent
- Timeout support
- Result aggregation

---

## Configuration

### Environment Variables

```bash
# Logging level
SAFE_LOG_LEVEL=DEBUG

# Foundry settings (Phase 2+)
FOUNDRY_CATALOG_URL=https://foundry.example.com
FOUNDRY_API_KEY=xxx

# Agent settings
AGENT_TIMEOUT=3600
AGENT_RETRY_COUNT=3
```

### pyproject.toml

Configure uv and pytest:

```toml
[tool.uv]
python-version = "3.11"

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "--cov=safe_core --cov-report=html"
```

---

## Development

### Code Quality

All code follows Python best practices:

- **Type Hints**: Full type annotations
- **Docstrings**: Google-style docstrings
- **Linting**: `ruff` configured
- **Formatting**: `black` (100 char line length)
- **Testing**: 90%+ coverage

### Run Linting

```bash
# Format code
black safe_core safe_cli tests

# Lint
ruff check safe_core safe_cli tests

# Type checking
mypy safe_core safe_cli
```

### Add New Features

1. **Add to route definitions** (`route_definitions.py`)
2. **Update Jinja2 templates** (`templates/`)
3. **Update Route Writer** (`route_writer.py`)
4. **Add tests** (`tests/`)
5. **Test end-to-end** (`pytest`)

---

## Architecture Decisions

### Why Pydantic?
- Runtime validation of route definitions
- Type safety
- JSON schema generation (future)
- Easy serialization

### Why Jinja2?
- Industry-standard templating
- Clean, readable generated code
- Easy to customize templates
- No runtime overhead

### Why Async/Await?
- Multi-agent orchestration is I/O bound
- Parallel agent execution (fan-out)
- Non-blocking operations
- Native Python (3.7+)

### Why Typer?
- Simple, intuitive CLI
- Auto-generated help
- Type-safe arguments
- Rich output support

---

## Roadmap

### Phase 1 ✅ (Week 2–4)
- Route definitions (Pydantic)
- Code generator (Jinja2)
- Route Writer Agent (interviews)
- Example agents
- CLI (Typer)
- Tests (pytest)

### Phase 2 (Week 4–5)
- Health Registry (metrics + flags)
- MAF middleware hooks
- Foundry integration

### Phase 3 (Week 5–6)
- Agent 365 lifecycle management
- RBAC + governance

### Phase 4+ (Week 6–12)
- Workflow executor
- CLI polish
- Reference recipes
- Production deployment

---

## Troubleshooting

### ImportError: Cannot import 'safe_core'

```bash
# Make sure you're in the right directory
cd safe_phase1

# Reinstall in editable mode
uv pip install -e .
```

### Tests fail with "No module named 'semantic_kernel'"

```bash
# Install dev dependencies
uv pip install -e ".[dev]"
```

### Generated code has syntax errors

```bash
# Validate the code
python -m safe_cli.cli validate-code routes/my-route/v1.0.py

# Check the templates
cat safe_core/templates/static_route.py.jinja2
```

### CLI not found

```bash
# Make sure package is installed
pip show safe-framework

# Try running directly
python -m safe_cli.cli --help
```

---

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass (`pytest`)
5. Submit a pull request

---

## License

MIT License (example)

---

## Support

For issues or questions:
1. Check this README
2. Review test examples
3. File an issue with reproduction steps

---

## Summary

**Phase 1 delivers:**
- ✅ Route definitions (Pydantic models)
- ✅ Code generator (Jinja2 + validation)
- ✅ Route Writer Agent (interviews)
- ✅ Example agents (mock implementations)
- ✅ CLI interface (Typer)
- ✅ Comprehensive tests (pytest)
- ✅ Production-ready code (types, docs, logging)

**What's next:**
- Phase 2: Health Registry + monitoring
- Phase 3: Foundry + Agent 365 integration
- Phase 4+: Workflow execution + reference recipes

**To get started:** See "Quick Start" section above.
