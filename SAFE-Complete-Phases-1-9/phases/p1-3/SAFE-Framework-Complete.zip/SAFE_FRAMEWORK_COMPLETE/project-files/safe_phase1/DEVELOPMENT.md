# SAFE Framework - Development Guide

## For Phase 1 Developers

This guide explains the architecture and how to extend Phase 1.

---

## Project Architecture

### Directory Structure

```
safe_phase1/
├── safe_core/                          # Core framework
│   ├── route_definitions.py            # Pydantic models
│   ├── code_generator.py               # Jinja2 code generation
│   ├── route_writer.py                 # Route Writer Agent
│   ├── example_agents.py               # Mock agents
│   ├── templates/                      # Jinja2 templates
│   │   ├── static_route.py.jinja2
│   │   └── dynamic_route.py.jinja2
│   └── __init__.py
│
├── safe_cli/                           # CLI interface
│   ├── cli.py                          # Typer commands
│   └── __init__.py
│
├── tests/                              # Test suite
│   ├── test_route_definitions.py
│   ├── test_code_generator.py
│   ├── test_route_writer.py
│   ├── test_integration.py
│   └── __init__.py
│
├── pyproject.toml                      # uv/pip configuration
├── README.md                           # User guide
├── DEVELOPMENT.md                      # This file
├── Makefile                            # Common tasks
└── quickstart.sh                       # Setup script
```

---

## Module Responsibilities

### 1. `route_definitions.py`

**Purpose:** Define the data model for routes

**Key Classes:**
- `ErrorPolicy`: Enum for error handling strategies
- `AgentConfig`: Configuration for a single agent
- `StaticRouteDefinition`: Fixed-topology routes
- `DynamicRouteDefinition`: Decision-driven routes
- `ConditionalRoute`: A conditional branch in dynamic routes
- `RouteMetadata`: Metadata for routes (future)

**Validation:**
- Uses Pydantic validators for field validation
- Route names must be alphanumeric with hyphens/underscores
- Static routes require a pattern
- Dynamic routes require at least one route

**To Add New Features:**
1. Add fields to the relevant class
2. Add Pydantic validators if needed
3. Update tests in `test_route_definitions.py`

**Example:**
```python
from safe_core.route_definitions import StaticRouteDefinition, AgentConfig

agents = [AgentConfig(name="Agent1")]
route = StaticRouteDefinition(
    name="my-route",
    pattern="sequential",
    agents=agents,
)
```

---

### 2. `code_generator.py`

**Purpose:** Generate Python code from route definitions

**Key Classes:**
- `RouteCodeGenerator`: Main code generation engine
- `SyntaxValidator`: Validates generated Python syntax

**Implementation Details:**
- Uses Jinja2 for templating
- Templates in `safe_core/templates/`
- Validates syntax using Python's `compile()`
- Generates async/await compatible code

**To Customize Generated Code:**

1. **Modify templates:** Edit `.jinja2` files in `safe_core/templates/`
   - `static_route.py.jinja2`: Template for static routes
   - `dynamic_route.py.jinja2`: Template for dynamic routes

2. **Add new code generation method:**
   ```python
   def generate_fan_in_route(self, definition):
       template = self.env.get_template("fan_in_route.py.jinja2")
       return template.render(...)
   ```

3. **Test the new code:**
   ```python
   def test_fan_in_generation(self):
       generator = RouteCodeGenerator()
       code = generator.generate_fan_in_route(definition)
       assert SyntaxValidator.validate(code)["valid"]
   ```

**Template Variables:**
```jinja2
{{ route_name }}          # Route name (hyphenated)
{{ route_name_func }}     # Route name (underscored, for function)
{{ route_version }}       # Version (e.g., 1.0)
{{ route_description }}   # Description
{{ agents }}              # List of agent configs
{{ pattern }}             # Pattern (sequential, fan_out, etc.)
```

---

### 3. `route_writer.py`

**Purpose:** Interactive session for building routes

**Key Class:**
- `RouteWriterSession`: Manages a single route creation session

**Session Workflow:**
1. `set_basics()`: Set name, description, type
2. `set_agents()`: Add agents
3. `set_pattern()` (static) or `set_dynamic_routing()` (dynamic)
4. `generate_code()`: Generate Python code
5. `test_route()`: Test code compilation
6. `get_summary()`: Get configuration summary

**To Add New Route Types:**

1. Add new method to `RouteWriterSession`:
   ```python
   def set_special_routing(self, config):
       self.route_definition["special_config"] = config
   ```

2. Update `generate_code()` to handle the new type:
   ```python
   elif self.route_definition["route_type"] == "special":
       definition = SpecialRouteDefinition(...)
       self.generated_code = self.code_generator.generate_special_route(definition)
   ```

3. Add tests in `test_route_writer.py`

**State Management:**
- `conversation_history`: Chat history (for future AI integration)
- `route_definition`: Dict storing route config
- `generated_code`: Generated Python code
- `code_generator`: Code generation engine

---

### 4. `example_agents.py`

**Purpose:** Mock agents for testing and demonstration

**Key Classes:**
- `DocumentExtractorAgent`: Extracts metadata
- `DocumentReviewerAgent`: Reviews documents
- And 7 more example agents

**Agent Interface:**
```python
class MyAgent:
    def __init__(self):
        self.name = "MyAgent"
        self.version = "1.0"
    
    async def invoke(self, input_data: Dict) -> Dict:
        # Process input
        result = {"success": True, ...}
        return result
```

**To Add New Agent:**

1. Create new class:
   ```python
   class MyNewAgent:
       def __init__(self):
           self.name = "MyNewAgent"
           self.version = "1.0"
       
       async def invoke(self, input_data):
           return {"success": True, "result": ...}
   ```

2. Add to registry:
   ```python
   AGENT_REGISTRY = {
       ...
       "MyNewAgent": MyNewAgent,
   }
   ```

3. Test in `test_integration.py`

---

### 5. `safe_cli/cli.py`

**Purpose:** Command-line interface using Typer

**Key Commands:**
- `create-route`: Interactive route creation
- `list-agents`: Show available agents
- `validate-code`: Validate Python file syntax
- `show-template`: Show example route definitions

**To Add New Command:**

```python
@app.command()
def my_command(
    arg1: str = typer.Argument(..., help="Description"),
    opt1: str = typer.Option("default", help="Description"),
) -> None:
    """Command description."""
    console.print("Output here")
```

**Output Formatting:**
- Use `console` from `rich` for pretty output
- Use `Table` for structured data
- Use `Panel` for highlights
- Use `Syntax` for code highlighting

---

## Testing Strategy

### Test Organization

- `test_route_definitions.py`: Unit tests for models
- `test_code_generator.py`: Unit tests for code generation
- `test_route_writer.py`: Unit tests for Route Writer
- `test_integration.py`: Integration tests (workflows)

### Test Coverage Goals

- Aim for 90%+ coverage
- Test both happy paths and error cases
- Include integration tests for complete workflows

### Running Tests

```bash
# All tests
pytest

# Specific test file
pytest tests/test_route_writer.py

# Specific test
pytest tests/test_route_writer.py::TestRouteWriterSession::test_set_basics_valid

# With coverage
pytest --cov=safe_core --cov-report=html

# Verbose
pytest -v

# Watch mode (requires pytest-watch)
ptw
```

### Test Patterns

**Unit Test Pattern:**
```python
def test_feature_does_something():
    # Arrange
    input_data = {"key": "value"}
    
    # Act
    result = function(input_data)
    
    # Assert
    assert result["success"] is True
```

**Integration Test Pattern:**
```python
@pytest.mark.asyncio
async def test_workflow():
    # Arrange: Create components
    session = RouteWriterSession()
    
    # Act: Execute workflow
    session.set_basics("name", "desc", "static")
    session.set_agents(["Agent1"])
    session.set_pattern("sequential")
    code = session.generate_code()
    
    # Assert: Verify results
    assert code is not None
    assert SyntaxValidator.validate(code)["valid"]
```

---

## Code Quality Standards

### Type Hints

All functions must have type hints:

```python
def function(arg1: str, arg2: int) -> Dict[str, Any]:
    """Function description."""
    pass
```

### Docstrings

Use Google-style docstrings:

```python
def function(arg1: str, arg2: int) -> Dict[str, Any]:
    """
    Brief description.
    
    Longer description if needed.
    
    Args:
        arg1: Description of arg1
        arg2: Description of arg2
    
    Returns:
        Description of return value
    
    Raises:
        ValueError: When something is invalid
    """
    pass
```

### Logging

Use Python's standard logging:

```python
import logging

logger = logging.getLogger(__name__)

logger.debug("Debug message")
logger.info("Info message")
logger.warning("Warning message")
logger.error("Error message")
```

### Formatting

```bash
# Format code
black safe_core safe_cli tests

# Check formatting
black --check safe_core safe_cli

# Lint
ruff check safe_core safe_cli

# Type check
mypy safe_core safe_cli
```

---

## Common Tasks

### Add a New Pattern

1. Update `route_definitions.py` to validate the pattern
2. Create template `safe_core/templates/pattern_route.py.jinja2`
3. Add method to `RouteCodeGenerator`
4. Update `RouteWriterSession.set_pattern()`
5. Add tests

### Add a New Error Policy

1. Add to `ErrorPolicy` enum in `route_definitions.py`
2. Update agent config templates to handle the policy
3. Add tests

### Extend Route Writer

1. Add method to `RouteWriterSession`
2. Update `generate_code()` to handle new config
3. Add tests in `test_route_writer.py`
4. Update CLI if needed

### Add a New CLI Command

1. Create function in `safe_cli/cli.py` with `@app.command()` decorator
2. Use `typer.prompt()`, `typer.confirm()`, `typer.Option()`, etc.
3. Use `console` from `rich` for output
4. Document in README.md

---

## Debugging

### Enable Debug Logging

```bash
export SAFE_LOG_LEVEL=DEBUG
python -m safe_cli.cli create-route
```

Or in code:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Inspect Generated Code

```python
session = RouteWriterSession()
# ... configure route ...
code = session.generate_code()
print(code)  # Print raw code
print(session.get_code_preview())  # Print preview
```

### Validate Code Syntax

```python
from safe_core.code_generator import SyntaxValidator

result = SyntaxValidator.validate(code)
if not result["valid"]:
    for error in result["errors"]:
        print(f"Line {error['line']}: {error['message']}")
```

### Test Individual Components

```python
# Test route definitions
from safe_core.route_definitions import StaticRouteDefinition
route = StaticRouteDefinition(...)

# Test code generation
from safe_core.code_generator import RouteCodeGenerator
generator = RouteCodeGenerator()
code = generator.generate(route)

# Test Route Writer
from safe_core.route_writer import RouteWriterSession
session = RouteWriterSession()
session.set_basics(...)
```

---

## Performance Considerations

### Code Generation

- Jinja2 rendering is fast (~1ms for typical routes)
- Python `compile()` is fast (~10ms for 200-line code)
- Total generation time: <100ms for most routes

### Memory Usage

- Typical route definition: <1KB
- Generated code: 2-5KB
- Generated code in memory: <1MB even for complex routes

### Optimization Tips

- Lazy-load templates if needed (currently loaded once)
- Cache compiled code if routes are reused
- Use async for multi-route generation

---

## Future Enhancements (Phase 2+)

### Planned for Phase 2
- Health Registry (metrics + flags)
- MAF middleware hooks
- Auto-flagging (cost, latency, failures)
- Monitoring agents

### Planned for Phase 3
- Foundry integration (catalog, versioning)
- Agent 365 lifecycle management
- RBAC and governance

### Planned for Phase 4+
- Workflow executor (MAF execution)
- CLI polish (non-interactive mode)
- Reference recipes (document review, course generation)
- Production deployment

---

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make changes with tests
4. Ensure tests pass: `pytest`
5. Ensure code quality: `black`, `ruff`, `mypy`
6. Commit with clear messages
7. Push and create a pull request

---

## References

- [Pydantic Documentation](https://docs.pydantic.dev/)
- [Jinja2 Documentation](https://jinja.palletsprojects.com/)
- [Typer Documentation](https://typer.tiangolo.com/)
- [pytest Documentation](https://docs.pytest.org/)
- [OpenTelemetry Python](https://opentelemetry.io/docs/instrumentation/python/)

---

## Support

For questions or issues:
1. Check the README.md
2. Search existing tests for examples
3. Review module docstrings
4. File an issue with reproduction steps
