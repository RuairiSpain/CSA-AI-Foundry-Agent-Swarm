"""
Example micro-agents for SAFE framework.

These are demonstration agents that show the structure and patterns
for building agents in the SAFE ecosystem.
"""

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


@dataclass
class AgentContext:
    """Context for agent execution."""

    agent_name: str
    agent_version: str
    input_data: Dict[str, Any]
    timeout: int = 3600


class DocumentExtractorAgent:
    """
    Example agent: Extracts metadata and content from documents.

    This is a mock agent used for testing and demonstration.
    In production, this would use MAF and real document processing.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "DocumentExtractor"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract document information.

        Args:
            input_data: Input containing document path or content

        Returns:
            Extracted metadata and content
        """
        logger.info(f"{self.name}: Processing document")

        # Simulate processing
        await asyncio.sleep(0.1)

        return {
            "success": True,
            "metadata": {
                "doc_type": input_data.get("doc_type", "unknown"),
                "pages": input_data.get("pages", 1),
                "language": "en",
            },
            "content": "Extracted document content here",
            "timestamp": "2026-06-20T10:00:00Z",
        }


class DocumentReviewerAgent:
    """
    Example agent: Reviews extracted documents.

    Simulates a review process with approval/rejection.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "DocumentReviewer"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Review document.

        Args:
            input_data: Input from previous agent

        Returns:
            Review result with approval status
        """
        logger.info(f"{self.name}: Reviewing document")

        await asyncio.sleep(0.15)

        # Mock review logic
        is_valid = input_data.get("metadata", {}).get("pages", 0) > 0

        return {
            "success": True,
            "approved": is_valid,
            "confidence": 0.95,
            "feedback": "Document quality is acceptable" if is_valid else "Missing pages",
            "reviewer": self.name,
            "timestamp": "2026-06-20T10:00:01Z",
        }


class DocumentAggregatorAgent:
    """
    Example agent: Aggregates results from multiple reviewers.

    Combines individual review results into final decision.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "DocumentAggregator"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Aggregate review results.

        Args:
            input_data: Input containing extraction and review data

        Returns:
            Final aggregated decision
        """
        logger.info(f"{self.name}: Aggregating results")

        await asyncio.sleep(0.1)

        reviews = input_data.get("reviews", [])
        approved_count = sum(1 for r in reviews if r.get("approved", False))
        total_reviews = len(reviews)

        # Simple majority vote
        approved = approved_count > (total_reviews / 2) if total_reviews > 0 else True

        return {
            "success": True,
            "final_approval": approved,
            "reviews_analyzed": total_reviews,
            "approved_count": approved_count,
            "decision": "APPROVED" if approved else "REJECTED",
            "confidence": min(0.95, 0.7 + (approved_count / max(total_reviews, 1)) * 0.25),
            "timestamp": "2026-06-20T10:00:02Z",
        }


class CourseManagerAgent:
    """
    Example agent: Manages course creation workflow.

    Coordinates the course generation process.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "CourseManager"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create course outline and assign chapters.

        Args:
            input_data: Course requirements

        Returns:
            Course outline and chapter assignments
        """
        logger.info(f"{self.name}: Creating course outline")

        await asyncio.sleep(0.2)

        course_title = input_data.get("course_title", "Untitled Course")
        chapter_count = input_data.get("chapter_count", 5)
        prerequisites = input_data.get("prerequisites", [])

        chapters = [
            {
                "chapter_number": i + 1,
                "title": f"Chapter {i + 1}: {course_title} Fundamentals"
                if i == 0
                else f"Chapter {i + 1}: Advanced Topics",
                "outline": f"Outline for chapter {i + 1}",
                "estimated_hours": 2,
            }
            for i in range(chapter_count)
        ]

        return {
            "success": True,
            "course_title": course_title,
            "outline": {
                "title": course_title,
                "prerequisites": prerequisites,
                "total_chapters": chapter_count,
                "estimated_hours": chapter_count * 2,
            },
            "chapter_assignments": chapters,
            "timestamp": "2026-06-20T10:00:00Z",
        }


class ChapterWriterAgent:
    """
    Example agent: Writes course chapters.

    Generates chapter content based on outline.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "ChapterWriter"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Write chapter content.

        Args:
            input_data: Chapter outline and context

        Returns:
            Written chapter content
        """
        chapter_num = input_data.get("chapter_number", 1)
        logger.info(f"{self.name}: Writing chapter {chapter_num}")

        await asyncio.sleep(0.3)  # Simulate writing time

        return {
            "success": True,
            "chapter_number": chapter_num,
            "content": f"Chapter {chapter_num} content goes here...\n" * 10,
            "word_count": 2500,
            "quality_score": 0.88,
            "metadata": {
                "format": "markdown",
                "include_examples": True,
            },
            "timestamp": "2026-06-20T10:00:00Z",
        }


class CriticAgent:
    """
    Example agent: Reviews and critiques course chapters.

    Provides feedback on chapter quality.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "CriticAgent"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Review chapters and provide feedback.

        Args:
            input_data: Chapters to review

        Returns:
            Approval status and feedback
        """
        chapters = input_data.get("chapters", [])
        logger.info(f"{self.name}: Reviewing {len(chapters)} chapters")

        await asyncio.sleep(0.25)

        # Mock criticism: approve if sufficient chapters
        approved = len(chapters) >= 3

        feedback = {}
        if not approved:
            feedback["general"] = "Need more chapters for comprehensive coverage"

        return {
            "success": True,
            "approved": approved,
            "feedback": feedback,
            "quality_rating": 0.82 if approved else 0.65,
            "timestamp": "2026-06-20T10:00:00Z",
        }


class DesignerAgent:
    """
    Example agent: Designs course materials (PowerPoint).

    Converts chapter content into presentation format.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "DesignerAgent"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Design course presentation.

        Args:
            input_data: Chapter content and templates

        Returns:
            Designed presentation file
        """
        logger.info(f"{self.name}: Designing presentation")

        await asyncio.sleep(0.4)  # Longer design time

        return {
            "success": True,
            "designed_deck": "/designs/course-deck-v1.pptx",
            "slides_count": 75,
            "design_quality": 0.91,
            "includes_branding": True,
            "timestamp": "2026-06-20T10:00:00Z",
        }


class BrandValidatorAgent:
    """
    Example agent: Validates brand compliance.

    Checks formatting and branding guidelines.
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "BrandValidator"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate brand compliance.

        Args:
            input_data: Materials to validate

        Returns:
            Compliance status
        """
        logger.info(f"{self.name}: Validating brand compliance")

        await asyncio.sleep(0.15)

        return {
            "success": True,
            "compliant": True,
            "issues": [],
            "compliance_score": 0.97,
            "checks": {
                "logo_usage": "pass",
                "color_palette": "pass",
                "typography": "pass",
                "spacing": "pass",
            },
            "timestamp": "2026-06-20T10:00:00Z",
        }


class PublisherAgent:
    """
    Example agent: Publishes final course materials.

    Saves to shared storage (OneDrive).
    """

    def __init__(self):
        """Initialize agent."""
        self.name = "PublisherAgent"
        self.version = "1.0"

    async def invoke(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Publish course to OneDrive.

        Args:
            input_data: Final course materials

        Returns:
            Publishing confirmation and link
        """
        course_title = input_data.get("course_metadata", {}).get("title", "Course")
        logger.info(f"{self.name}: Publishing {course_title}")

        await asyncio.sleep(0.2)

        return {
            "success": True,
            "published": True,
            "onedrive_link": (
                f"https://company.sharepoint.com/sites/Training/Courses/{course_title}-v1"
            ),
            "folder": f"/shared/Training/Courses/{course_title}",
            "files_published": 5,
            "timestamp": "2026-06-20T10:00:00Z",
        }


# Agent registry for quick access
AGENT_REGISTRY = {
    "DocumentExtractor": DocumentExtractorAgent,
    "DocumentReviewer": DocumentReviewerAgent,
    "DocumentAggregator": DocumentAggregatorAgent,
    "CourseManager": CourseManagerAgent,
    "ChapterWriter": ChapterWriterAgent,
    "CriticAgent": CriticAgent,
    "DesignerAgent": DesignerAgent,
    "BrandValidator": BrandValidatorAgent,
    "PublisherAgent": PublisherAgent,
}


async def create_agent(name: str) -> Optional[Any]:
    """
    Factory function to create an agent by name.

    Args:
        name: Agent name

    Returns:
        Agent instance or None if not found
    """
    agent_class = AGENT_REGISTRY.get(name)
    if agent_class:
        return agent_class()
    logger.warning(f"Agent {name} not found in registry")
    return None


def get_available_agents() -> list[str]:
    """
    Get list of available agents.

    Returns:
        List of agent names
    """
    return list(AGENT_REGISTRY.keys())
