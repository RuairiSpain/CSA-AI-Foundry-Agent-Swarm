"""
Route code generation.

Generates production-ready Python code from route definitions.
"""

import logging
from typing import Dict, Optional

from jinja2 import Environment, PackageLoader, select_autoescape

from safe_core.route_definitions import DynamicRouteDefinition, StaticRouteDefinition

logger = logging.getLogger(__name__)


class RouteCodeGenerator:
    """Generate Python route code from definitions."""

    def __init__(self) -> None:
        """Initialize code generator with Jinja2 templates."""
        self.env = Environment(
            loader=PackageLoader("safe_core", "templates"),
            autoescape=select_autoescape(["html", "xml"]),
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def generate_static_route(self, definition: StaticRouteDefinition) -> str:
        """
        Generate code for a static route.

        Args:
            definition: Static route definition

        Returns:
            Generated Python code as string
        """
        template = self.env.get_template("static_route.py.jinja2")

        agents_config = [
            {
                "name": agent.name,
                "version": agent.version,
                "error_policy": agent.error_policy.value,
                "timeout": agent.timeout_seconds,
            }
            for agent in definition.agents
        ]

        context = {
            "route_name": definition.name,
            "route_name_func": definition.name.replace("-", "_"),
            "route_description": definition.description,
            "route_version": definition.version,
            "pattern": definition.pattern,
            "agents": agents_config,
            "parallel_groups": definition.parallel_groups or [],
        }

        code = template.render(**context)
        logger.info(f"Generated static route code: {definition.name} v{definition.version}")
        return code

    def generate_dynamic_route(self, definition: DynamicRouteDefinition) -> str:
        """
        Generate code for a dynamic route.

        Args:
            definition: Dynamic route definition

        Returns:
            Generated Python code as string
        """
        template = self.env.get_template("dynamic_route.py.jinja2")

        # Convert conditional routes to template format
        routes = [
            {
                "condition": route.condition,
                "agents": route.agents,
            }
            for route in definition.routes
        ]

        context = {
            "route_name": definition.name,
            "route_name_func": definition.name.replace("-", "_"),
            "route_description": definition.description,
            "route_version": definition.version,
            "decision_inputs": definition.decision_inputs,
            "routes": routes,
            "fallback_agents": definition.fallback_agents,
            "orchestrator": definition.orchestrator_agent,
        }

        code = template.render(**context)
        logger.info(f"Generated dynamic route code: {definition.name} v{definition.version}")
        return code

    def generate(self, definition: StaticRouteDefinition | DynamicRouteDefinition) -> str:
        """
        Generate code for any route definition.

        Args:
            definition: Route definition (static or dynamic)

        Returns:
            Generated Python code as string

        Raises:
            ValueError: If route type is unknown
        """
        if isinstance(definition, StaticRouteDefinition):
            return self.generate_static_route(definition)
        elif isinstance(definition, DynamicRouteDefinition):
            return self.generate_dynamic_route(definition)
        else:
            raise ValueError(f"Unknown route definition type: {type(definition)}")


class SyntaxValidator:
    """Validate Python code syntax."""

    @staticmethod
    def validate(code: str) -> Dict[str, any]:
        """
        Validate Python code syntax.

        Args:
            code: Python code as string

        Returns:
            Dict with 'valid' bool and 'errors' list
        """
        try:
            compile(code, "<string>", "exec")
            logger.debug("Code syntax validation passed")
            return {"valid": True, "errors": []}
        except SyntaxError as e:
            error = {
                "line": e.lineno,
                "column": e.offset,
                "message": e.msg,
                "text": e.text,
            }
            logger.error(f"Syntax error at line {e.lineno}: {e.msg}")
            return {"valid": False, "errors": [error]}
        except Exception as e:
            logger.error(f"Unexpected error during validation: {e}")
            return {"valid": False, "errors": [{"message": str(e)}]}
