"""
Route Writer Agent.

Interactive agent that guides engineers through route creation via conversation.
"""

import logging
from typing import Any, Dict, List, Optional

from safe_core.code_generator import RouteCodeGenerator, SyntaxValidator
from safe_core.route_definitions import (
    AgentConfig,
    ConditionalRoute,
    DynamicRouteDefinition,
    ErrorPolicy,
    StaticRouteDefinition,
)

logger = logging.getLogger(__name__)


class RouteWriterSession:
    """Manages a single route creation session."""

    def __init__(self, code_generator: Optional[RouteCodeGenerator] = None):
        """
        Initialize a route writer session.

        Args:
            code_generator: Code generator instance (will be created if not provided)
        """
        self.code_generator = code_generator or RouteCodeGenerator()
        self.validator = SyntaxValidator()
        self.conversation_history: List[Dict[str, str]] = []
        self.route_definition: Dict[str, Any] = {}
        self.generated_code: Optional[str] = None

    def add_message(self, role: str, content: str) -> None:
        """
        Add a message to conversation history.

        Args:
            role: "user" or "assistant"
            content: Message content
        """
        self.conversation_history.append({"role": role, "content": content})
        logger.debug(f"[{role}] {content[:100]}...")

    async def ask_basics(self) -> Dict[str, str]:
        """
        Collect basic route information.

        Returns:
            Dict with name, description, and type
        """
        logger.info("Starting route basics interview")

        self.add_message(
            "assistant",
            "Let's create a route! First, what's the route name?",
        )

        # In a real implementation, this would be interactive
        # For now, we return a template structure
        return {
            "name": None,  # Will be filled by user
            "description": None,
            "type": None,  # "static" or "dynamic"
        }

    def set_basics(self, name: str, description: str, route_type: str) -> None:
        """
        Set basic route information.

        Args:
            name: Route name
            description: Route description
            route_type: "static" or "dynamic"

        Raises:
            ValueError: If inputs are invalid
        """
        if not name or not name.replace("-", "").replace("_", "").isalnum():
            raise ValueError("Route name must be alphanumeric")

        if route_type not in ["static", "dynamic"]:
            raise ValueError("Route type must be 'static' or 'dynamic'")

        self.route_definition["name"] = name.lower()
        self.route_definition["description"] = description
        self.route_definition["route_type"] = route_type

        logger.info(
            f"Set route basics: name={name}, type={route_type}",
        )

    async def ask_agents(self, available_agents: List[str]) -> None:
        """
        Ask which agents are involved.

        Args:
            available_agents: List of available agent names
        """
        self.add_message(
            "assistant",
            f"Available agents: {', '.join(available_agents)}. "
            "Which agents should be in this route?",
        )

    def set_agents(self, agent_names: List[str]) -> None:
        """
        Set the agents for this route.

        Args:
            agent_names: List of agent names

        Raises:
            ValueError: If agent list is empty
        """
        if not agent_names:
            raise ValueError("At least one agent is required")

        # Create agent configs
        agents = [
            AgentConfig(
                name=name,
                version="latest",
                error_policy=ErrorPolicy.FAIL_HARD,
            )
            for name in agent_names
        ]

        self.route_definition["agents"] = agents
        logger.info(f"Set agents: {agent_names}")

    async def ask_pattern(self) -> None:
        """Ask for orchestration pattern (static routes only)."""
        patterns = ["sequential", "fan_out", "fan_in", "handoff"]
        self.add_message(
            "assistant",
            f"Which pattern? [{', '.join(patterns)}]",
        )

    def set_pattern(self, pattern: str) -> None:
        """
        Set orchestration pattern.

        Args:
            pattern: One of sequential, fan_out, fan_in, handoff

        Raises:
            ValueError: If pattern is invalid
        """
        valid_patterns = ["sequential", "fan_out", "fan_in", "handoff"]
        if pattern not in valid_patterns:
            raise ValueError(f"Pattern must be one of {valid_patterns}")

        self.route_definition["pattern"] = pattern
        logger.info(f"Set pattern: {pattern}")

    async def ask_dynamic_routing(self) -> None:
        """Ask for dynamic routing configuration."""
        self.add_message(
            "assistant",
            "What decision inputs will drive routing? (e.g., doc_type, amount)",
        )

    def set_dynamic_routing(
        self,
        decision_inputs: List[str],
        routes: List[Dict[str, Any]],
        fallback_agents: Optional[List[str]] = None,
    ) -> None:
        """
        Set dynamic routing configuration.

        Args:
            decision_inputs: Variables used for routing decisions
            routes: List of {'condition': str, 'agents': List[str]}
            fallback_agents: Agents to use if no condition matches

        Raises:
            ValueError: If configuration is invalid
        """
        if not decision_inputs:
            raise ValueError("At least one decision input required")

        if not routes:
            raise ValueError("At least one conditional route required")

        # Create conditional routes
        conditional_routes = [
            ConditionalRoute(condition=r["condition"], agents=r["agents"])
            for r in routes
        ]

        self.route_definition["decision_inputs"] = decision_inputs
        self.route_definition["routes"] = conditional_routes
        self.route_definition["fallback_agents"] = fallback_agents or []

        logger.info(
            f"Set dynamic routing: {len(routes)} conditions, "
            f"{len(fallback_agents or [])} fallback agents",
        )

    async def generate_code(self) -> str:
        """
        Generate Python code from route definition.

        Returns:
            Generated Python code

        Raises:
            ValueError: If route definition is incomplete
        """
        if not self.route_definition.get("name"):
            raise ValueError("Route name not set")

        # Build appropriate definition object
        if self.route_definition["route_type"] == "static":
            definition = StaticRouteDefinition(
                name=self.route_definition["name"],
                version=self.route_definition.get("version", "1.0"),
                description=self.route_definition.get("description", ""),
                agents=self.route_definition.get("agents", []),
                pattern=self.route_definition.get("pattern", "sequential"),
            )
            self.generated_code = self.code_generator.generate_static_route(definition)

        elif self.route_definition["route_type"] == "dynamic":
            definition = DynamicRouteDefinition(
                name=self.route_definition["name"],
                version=self.route_definition.get("version", "1.0"),
                description=self.route_definition.get("description", ""),
                decision_inputs=self.route_definition.get("decision_inputs", []),
                routes=self.route_definition.get("routes", []),
                fallback_agents=self.route_definition.get("fallback_agents", []),
            )
            self.generated_code = self.code_generator.generate_dynamic_route(definition)

        else:
            raise ValueError(f"Unknown route type: {self.route_definition['route_type']}")

        # Validate syntax
        validation = self.validator.validate(self.generated_code)
        if not validation["valid"]:
            errors = "\n".join([e["message"] for e in validation["errors"]])
            raise ValueError(f"Generated code has syntax errors:\n{errors}")

        logger.info(f"Generated and validated code for {self.route_definition['name']}")
        return self.generated_code

    def get_code_preview(self, max_lines: int = 20) -> str:
        """
        Get a preview of generated code.

        Args:
            max_lines: Maximum lines to show

        Returns:
            Code preview as string
        """
        if not self.generated_code:
            return "No code generated yet"

        lines = self.generated_code.split("\n")
        if len(lines) > max_lines:
            preview = "\n".join(lines[:max_lines])
            preview += f"\n... ({len(lines) - max_lines} more lines)"
            return preview

        return self.generated_code

    async def test_route(self, sample_input: Dict[str, Any]) -> Dict[str, Any]:
        """
        Test generated route with sample input.

        Args:
            sample_input: Sample input data for testing

        Returns:
            Test result dict with success/error info
        """
        if not self.generated_code:
            return {"success": False, "error": "No code generated yet"}

        try:
            # Compile and execute (in a sandbox in production)
            namespace: Dict[str, Any] = {}
            exec(self.generated_code, namespace)

            # Get the route function
            route_func_name = f"route_{self.route_definition['name'].replace('-', '_')}"
            route_func = namespace.get(route_func_name)

            if not route_func:
                return {
                    "success": False,
                    "error": f"Route function {route_func_name} not found",
                }

            # Return success (actual execution would require kernel/trace context)
            logger.info("Route code compiled successfully")
            return {
                "success": True,
                "message": "Route code compiled successfully",
                "route_function": route_func_name,
            }

        except SyntaxError as e:
            return {"success": False, "error": f"Syntax error: {e.msg} at line {e.lineno}"}

        except Exception as e:
            return {"success": False, "error": f"Test failed: {str(e)}"}

    def get_summary(self) -> Dict[str, Any]:
        """
        Get a summary of the route definition.

        Returns:
            Summary dict
        """
        agents = [a.name for a in self.route_definition.get("agents", [])]

        summary = {
            "name": self.route_definition.get("name"),
            "version": self.route_definition.get("version", "1.0"),
            "type": self.route_definition.get("route_type"),
            "agents": agents,
        }

        if self.route_definition.get("route_type") == "static":
            summary["pattern"] = self.route_definition.get("pattern")

        elif self.route_definition.get("route_type") == "dynamic":
            summary["decision_inputs"] = self.route_definition.get("decision_inputs", [])
            summary["routes_count"] = len(self.route_definition.get("routes", []))
            summary["fallback_agents"] = self.route_definition.get("fallback_agents", [])

        return summary
