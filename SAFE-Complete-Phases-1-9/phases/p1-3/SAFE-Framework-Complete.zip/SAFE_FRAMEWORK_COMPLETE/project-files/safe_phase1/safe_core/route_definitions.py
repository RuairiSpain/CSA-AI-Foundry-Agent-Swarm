"""
Route definition models.

These Pydantic models represent static and dynamic routes that can be
generated into executable Python code.
"""

from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator


class ErrorPolicy(str, Enum):
    """How to handle agent failures."""

    FAIL_HARD = "fail_hard"
    SKIP_IF_ERROR = "skip_if_error"
    RETRY = "retry"


class AgentConfig(BaseModel):
    """Configuration for an agent in a route."""

    name: str = Field(..., description="Agent name from catalog")
    version: str = Field(default="latest", description="Agent version")
    error_policy: ErrorPolicy = Field(
        default=ErrorPolicy.FAIL_HARD,
        description="How to handle failures",
    )
    timeout_seconds: int = Field(default=3600, description="Timeout in seconds")


class ConditionalRoute(BaseModel):
    """A conditional branch in a dynamic route."""

    condition: str = Field(..., description="Condition expression (e.g., 'doc_type == contract')")
    agents: List[str] = Field(..., description="Agents to invoke if condition is true")


class RouteDefinition(BaseModel):
    """Base class for all route definitions."""

    name: str = Field(..., min_length=1, description="Route name")
    version: str = Field(default="1.0", description="Route version")
    description: str = Field(default="", description="Route description")
    route_type: Literal["static", "dynamic"] = Field(..., description="Route type")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate route name format."""
        if not v.replace("-", "").replace("_", "").isalnum():
            raise ValueError("Route name must be alphanumeric with hyphens/underscores")
        return v.lower()


class StaticRouteDefinition(RouteDefinition):
    """Definition for a static route with fixed topology."""

    route_type: Literal["static"] = "static"
    pattern: Literal["sequential", "fan_out", "fan_in", "handoff"] = Field(
        ..., description="Orchestration pattern"
    )
    agents: List[AgentConfig] = Field(..., min_length=1, description="Agents in order")
    parallel_groups: Optional[List[List[str]]] = Field(
        default=None, description="Groups of agents to run in parallel"
    )


class DynamicRouteDefinition(RouteDefinition):
    """Definition for a dynamic route with decision-driven routing."""

    route_type: Literal["dynamic"] = "dynamic"
    decision_inputs: List[str] = Field(..., description="Input variables for decisions")
    routes: List[ConditionalRoute] = Field(..., min_length=1, description="Conditional routes")
    orchestrator_agent: Optional[str] = Field(
        default=None, description="Agent that coordinates the flow"
    )
    fallback_agents: List[str] = Field(
        default_factory=list, description="Fallback agents if no condition matches"
    )


class RouteMetadata(BaseModel):
    """Metadata for a route."""

    author: str = Field(..., description="Author/team name")
    tags: List[str] = Field(default_factory=list, description="Tags for categorization")
    sla_latency_p95_seconds: float = Field(default=60.0, description="SLA target")
    max_cost_per_run: float = Field(default=1.50, description="Cost budget")
    error_recovery: Dict[str, str] = Field(
        default_factory=dict, description="Error recovery policies by agent"
    )
