"""
SAFE Framework: Simplified Agent Flow Engineering

Core platform for building governed multi-agent workflows.
"""

from safe_core.route_definitions import (
    ConditionalRoute,
    DynamicRouteDefinition,
    ErrorPolicy,
    RouteDefinition,
    StaticRouteDefinition,
)

__version__ = "0.1.0"
__all__ = [
    "RouteDefinition",
    "StaticRouteDefinition",
    "DynamicRouteDefinition",
    "ConditionalRoute",
    "ErrorPolicy",
]
