"""
SAFE CLI: Command-line interface for route management.
"""
