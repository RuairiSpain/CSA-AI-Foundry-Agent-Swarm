"""
SAFE CLI: Command-line interface for route management.

Provides interactive commands for creating, testing, and managing routes.
"""

import asyncio
import json
import logging
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from safe_core.code_generator import RouteCodeGenerator, SyntaxValidator
from safe_core.example_agents import get_available_agents
from safe_core.route_writer import RouteWriterSession

logger = logging.getLogger(__name__)
console = Console()

app = typer.Typer(
    name="safe",
    help="SAFE Framework: Simplified Agent Flow Engineering",
)


@app.command()
def create_route(
    route_type: Optional[str] = typer.Option(
        None,
        "--type",
        help="Route type: static or dynamic",
    ),
    interactive: bool = typer.Option(
        True,
        "--interactive/--non-interactive",
        help="Interactive interview mode",
    ),
) -> None:
    """
    Create a new route interactively.

    This command guides you through creating a static or dynamic route.
    """
    console.print(
        Panel(
            "[bold cyan]SAFE Route Writer[/bold cyan]\n"
            "[dim]Create governed routes interactively[/dim]",
            expand=False,
        )
    )

    session = RouteWriterSession()

    try:
        # Step 1: Get basics
        console.print("\n[bold]Step 1: Route Basics[/bold]")
        name = typer.prompt("Route name")
        description = typer.prompt("Description", default="")

        if not route_type:
            route_type = typer.prompt(
                "Type",
                type=typer.Choice(["static", "dynamic"]),
            )

        session.set_basics(name, description, route_type)
        console.print("[green]✓ Basics set[/green]")

        # Step 2: Select agents
        console.print("\n[bold]Step 2: Select Agents[/bold]")
        available = get_available_agents()
        console.print(f"Available agents: {', '.join(available)}")

        agents_input = typer.prompt("Agent names (comma-separated)")
        agents = [a.strip() for a in agents_input.split(",")]
        session.set_agents(agents)
        console.print(f"[green]✓ Added {len(agents)} agents[/green]")

        # Step 3: Configure based on type
        if route_type == "static":
            console.print("\n[bold]Step 3: Orchestration Pattern[/bold]")
            pattern = typer.prompt(
                "Pattern",
                type=typer.Choice(["sequential", "fan_out", "fan_in", "handoff"]),
            )
            session.set_pattern(pattern)
            console.print("[green]✓ Pattern set[/green]")

        else:  # dynamic
            console.print("\n[bold]Step 3: Dynamic Routing[/bold]")
            inputs = typer.prompt("Decision inputs (comma-separated)")
            decision_inputs = [i.strip() for i in inputs.split(",")]

            routes = []
            console.print("[dim]Add conditional routes (type 'done' when finished)[/dim]")

            while True:
                condition = typer.prompt(
                    "Condition (or 'done')",
                    default="done",
                )
                if condition.lower() == "done":
                    break

                agents_str = typer.prompt("Agents for this condition (comma-separated)")
                route_agents = [a.strip() for a in agents_str.split(",")]
                routes.append({"condition": condition, "agents": route_agents})

            if not routes:
                console.print("[red]✗ At least one route required[/red]")
                return

            fallback_str = typer.prompt(
                "Fallback agents (optional, comma-separated)",
                default="",
            )
            fallback = (
                [a.strip() for a in fallback_str.split(",")]
                if fallback_str
                else []
            )

            session.set_dynamic_routing(decision_inputs, routes, fallback)
            console.print("[green]✓ Dynamic routing configured[/green]")

        # Step 4: Generate code
        console.print("\n[bold]Step 4: Code Generation[/bold]")
        code = session.generate_code()
        console.print("[green]✓ Code generated[/green]")

        # Step 5: Show preview
        console.print("\n[bold]Step 5: Code Preview[/bold]")
        preview = session.get_code_preview(max_lines=15)
        syntax = Syntax(preview, "python", theme="monokai", line_numbers=True)
        console.print(syntax)

        # Step 6: Test
        console.print("\n[bold]Step 6: Test Route[/bold]")
        test_input = typer.prompt("Sample input JSON", default="{}")

        try:
            sample_data = json.loads(test_input)
        except json.JSONDecodeError:
            sample_data = {}

        result = session.test_route(sample_data)

        if result["success"]:
            console.print("[green]✓ Code compilation successful[/green]")
        else:
            console.print(f"[red]✗ Test failed: {result['error']}[/red]")

        # Step 7: Summary
        console.print("\n[bold]Step 7: Summary[/bold]")
        summary = session.get_summary()

        table = Table(title="Route Configuration")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")

        for key, value in summary.items():
            if isinstance(value, list):
                value_str = ", ".join(str(v) for v in value)
            else:
                value_str = str(value)
            table.add_row(key, value_str)

        console.print(table)

        # Step 8: Save
        console.print("\n[bold]Step 8: Save Route[/bold]")
        save = typer.confirm("Save route to file?")

        if save:
            output_dir = Path("routes") / session.route_definition["name"]
            output_dir.mkdir(parents=True, exist_ok=True)

            code_file = output_dir / f"v1.0.py"
            code_file.write_text(code)

            config_file = output_dir / "config.json"
            config_file.write_text(
                json.dumps(
                    {
                        "name": session.route_definition["name"],
                        "version": "1.0",
                        "type": session.route_definition["route_type"],
                        "agents": [a.name for a in session.route_definition.get("agents", [])],
                    },
                    indent=2,
                )
            )

            console.print(f"[green]✓ Route saved to {output_dir}[/green]")

        console.print("\n[bold green]✓ Route creation complete![/bold green]")

    except ValueError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        sys.exit(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Cancelled[/yellow]")
        sys.exit(0)


@app.command()
def list_agents() -> None:
    """List available agents."""
    console.print("[bold]Available Agents:[/bold]\n")

    agents = get_available_agents()

    table = Table(title="Agent Registry")
    table.add_column("Agent Name", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Version", style="yellow")

    for agent in agents:
        # Default values for demo
        agent_type = "executor"
        version = "1.0"
        table.add_row(agent, agent_type, version)

    console.print(table)
    console.print(f"\n[dim]Total: {len(agents)} agents[/dim]")


@app.command()
def validate_code(
    code_file: Path = typer.Argument(
        ...,
        help="Python code file to validate",
    ),
) -> None:
    """
    Validate Python code syntax.

    Args:
        code_file: Path to Python file
    """
    if not code_file.exists():
        console.print(f"[red]✗ File not found: {code_file}[/red]")
        sys.exit(1)

    code = code_file.read_text()
    result = SyntaxValidator.validate(code)

    if result["valid"]:
        console.print("[green]✓ Code syntax is valid[/green]")
    else:
        console.print("[red]✗ Code has syntax errors:[/red]")
        for error in result["errors"]:
            line = error.get("line", "?")
            msg = error.get("message", "Unknown error")
            console.print(f"  Line {line}: {msg}")
        sys.exit(1)


@app.command()
def show_template(
    route_type: str = typer.Argument(
        ...,
        help="Route type: static or dynamic",
    ),
) -> None:
    """
    Show example route definition template.

    Args:
        route_type: Type of route template to show
    """
    if route_type == "static":
        template = {
            "name": "my-route",
            "version": "1.0",
            "description": "Route description",
            "route_type": "static",
            "pattern": "sequential",
            "agents": [
                {"name": "Agent1", "version": "latest"},
                {"name": "Agent2", "version": "latest"},
            ],
        }
    elif route_type == "dynamic":
        template = {
            "name": "my-route",
            "version": "1.0",
            "description": "Route description",
            "route_type": "dynamic",
            "decision_inputs": ["var1", "var2"],
            "routes": [
                {"condition": 'var1 == "value"', "agents": ["Agent1"]},
                {"condition": 'var2 > 100', "agents": ["Agent2", "Agent3"]},
            ],
            "fallback_agents": ["DefaultAgent"],
        }
    else:
        console.print("[red]Unknown route type. Use 'static' or 'dynamic'[/red]")
        sys.exit(1)

    json_str = json.dumps(template, indent=2)
    syntax = Syntax(json_str, "json", theme="monokai")
    console.print(syntax)


@app.command()
def version() -> None:
    """Show SAFE version."""
    console.print("[bold cyan]SAFE Framework[/bold cyan] v0.1.0")


def main() -> None:
    """Entry point for CLI."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    app()


if __name__ == "__main__":
    main()
