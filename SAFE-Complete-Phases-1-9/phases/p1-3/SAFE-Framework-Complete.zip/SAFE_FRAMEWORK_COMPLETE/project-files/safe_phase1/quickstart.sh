#!/bin/bash

# SAFE Framework Phase 1 Quick Start Script
# This script sets up the environment and runs tests

set -e  # Exit on error

echo "=========================================="
echo "SAFE Framework Phase 1 - Quick Start"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python version
echo -e "${BLUE}Checking Python version...${NC}"
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $python_version"

if ! python3 -c 'import sys; exit(0 if sys.version_info >= (3, 11) else 1)' 2>/dev/null; then
    echo -e "${YELLOW}Warning: Python 3.11+ recommended${NC}"
fi
echo ""

# Check if uv is installed
echo -e "${BLUE}Checking uv installation...${NC}"
if ! command -v uv &> /dev/null; then
    echo "uv not found. Installing..."
    pip install uv
fi
echo -e "${GREEN}✓ uv is available${NC}"
echo ""

# Create virtual environment
echo -e "${BLUE}Creating virtual environment...${NC}"
if [ -d ".venv" ]; then
    echo ".venv already exists, skipping..."
else
    python3 -m venv .venv
    echo -e "${GREEN}✓ Virtual environment created${NC}"
fi
echo ""

# Activate virtual environment
echo -e "${BLUE}Activating virtual environment...${NC}"
source .venv/bin/activate
echo -e "${GREEN}✓ Virtual environment activated${NC}"
echo ""

# Install dependencies
echo -e "${BLUE}Installing dependencies...${NC}"
uv pip install -e ".[dev]"
echo -e "${GREEN}✓ Dependencies installed${NC}"
echo ""

# Run tests
echo -e "${BLUE}Running tests...${NC}"
pytest -v
echo ""

# Show summary
echo -e "${GREEN}=========================================="
echo "Setup Complete!"
echo "==========================================${NC}"
echo ""
echo "Next steps:"
echo "  1. Source the virtual environment:"
echo "     source .venv/bin/activate"
echo ""
echo "  2. Create your first route:"
echo "     python -m safe_cli.cli create-route"
echo ""
echo "  3. List available agents:"
echo "     python -m safe_cli.cli list-agents"
echo ""
echo "  4. Validate generated code:"
echo "     python -m safe_cli.cli validate-code routes/my-route/v1.0.py"
echo ""
echo "  5. Run tests:"
echo "     pytest"
echo ""
echo "  6. View coverage report:"
echo "     pytest --cov=safe_core --cov-report=html"
echo "     open htmlcov/index.html"
echo ""
echo "Documentation:"
echo "  Read README.md for detailed information"
echo ""
