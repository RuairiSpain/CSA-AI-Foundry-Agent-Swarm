"""
Integration tests for SAFE framework.

These tests verify complete workflows from route creation to execution.
"""

import asyncio
import json

import pytest

from safe_core.code_generator import RouteCodeGenerator, SyntaxValidator
from safe_core.example_agents import (
    ChapterWriterAgent,
    CourseManagerAgent,
    CriticAgent,
    DocumentAggregatorAgent,
    DocumentExtractorAgent,
    DocumentReviewerAgent,
)
from safe_core.route_definitions import (
    AgentConfig,
    ConditionalRoute,
    DynamicRouteDefinition,
    StaticRouteDefinition,
)
from safe_core.route_writer import RouteWriterSession


class TestStaticRouteIntegration:
    """Integration tests for static routes."""

    @pytest.mark.asyncio
    async def test_document_review_workflow(self):
        """Test complete document review workflow."""
        # Create route definition
        agents = [
            AgentConfig(name="DocumentExtractor"),
            AgentConfig(name="DocumentReviewer"),
            AgentConfig(name="DocumentAggregator"),
        ]

        definition = StaticRouteDefinition(
            name="document-review",
            description="Reviews documents sequentially",
            pattern="sequential",
            agents=agents,
        )

        # Generate code
        generator = RouteCodeGenerator()
        code = generator.generate_static_route(definition)

        # Validate
        assert code is not None
        assert "route_document_review" in code

        validation = SyntaxValidator.validate(code)
        assert validation["valid"], f"Syntax errors: {validation['errors']}"

        # Test with mock agents
        extractor = DocumentExtractorAgent()
        reviewer = DocumentReviewerAgent()

        input_data = {"document": "test.pdf", "doc_type": "contract", "pages": 5}

        # Run agents in sequence
        extracted = await extractor.invoke(input_data)
        assert extracted["success"] is True

        review_input = {**input_data, "extracted": extracted}
        reviewed = await reviewer.invoke(review_input)
        assert reviewed["success"] is True
        assert "approved" in reviewed

    def test_static_route_code_generation(self):
        """Test static route code generation end-to-end."""
        agents = [
            AgentConfig(name="Agent1"),
            AgentConfig(name="Agent2"),
            AgentConfig(name="Agent3"),
        ]

        for pattern in ["sequential", "fan_out"]:
            definition = StaticRouteDefinition(
                name=f"test-{pattern}",
                pattern=pattern,
                agents=agents,
            )

            generator = RouteCodeGenerator()
            code = generator.generate_static_route(definition)

            # Verify structure
            assert f"route_test_{pattern}" in code
            assert "async def" in code
            assert "kernel.get_agent" in code
            assert "trace_context" in code

            # Verify syntax
            validation = SyntaxValidator.validate(code)
            assert validation["valid"]


class TestDynamicRouteIntegration:
    """Integration tests for dynamic routes."""

    def test_document_routing_workflow(self):
        """Test complete document routing workflow."""
        # Create route definition
        routes = [
            ConditionalRoute(
                condition='doc_type == "contract"',
                agents=["LegalReviewer"],
            ),
            ConditionalRoute(
                condition='doc_type == "policy"',
                agents=["PolicyReviewer"],
            ),
        ]

        definition = DynamicRouteDefinition(
            name="document-routing",
            description="Routes documents by type",
            decision_inputs=["doc_type"],
            routes=routes,
            fallback_agents=["GeneralReviewer"],
        )

        # Generate code
        generator = RouteCodeGenerator()
        code = generator.generate_dynamic_route(definition)

        # Validate
        assert code is not None
        assert "route_document_routing" in code
        assert 'doc_type == "contract"' in code

        validation = SyntaxValidator.validate(code)
        assert validation["valid"]

    def test_multi_condition_dynamic_route(self):
        """Test dynamic route with multiple conditions."""
        routes = [
            ConditionalRoute(
                condition='amount > 100000 and type == "loan"',
                agents=["HighValueAnalyst"],
            ),
            ConditionalRoute(
                condition='amount <= 100000',
                agents=["StandardAnalyst"],
            ),
            ConditionalRoute(
                condition='type == "investment"',
                agents=["InvestmentAnalyst"],
            ),
        ]

        definition = DynamicRouteDefinition(
            name="financial-routing",
            decision_inputs=["amount", "type"],
            routes=routes,
            fallback_agents=["DefaultAnalyst"],
        )

        generator = RouteCodeGenerator()
        code = generator.generate_dynamic_route(definition)

        # Verify all conditions are in code
        assert 'amount > 100000' in code
        assert 'type == "loan"' in code
        assert 'DefaultAnalyst' in code

        # Verify syntax
        validation = SyntaxValidator.validate(code)
        assert validation["valid"]


class TestRouteWriterIntegration:
    """Integration tests for Route Writer Agent."""

    def test_complete_static_route_creation(self):
        """Test complete workflow from interview to deployment."""
        session = RouteWriterSession()

        # Step 1: Basics
        session.set_basics("order-processing", "Process and validate orders", "static")
        assert session.route_definition["name"] == "order-processing"

        # Step 2: Agents
        session.set_agents(["OrderValidator", "PaymentProcessor", "OrderAggregator"])
        assert len(session.route_definition["agents"]) == 3

        # Step 3: Pattern
        session.set_pattern("sequential")
        assert session.route_definition["pattern"] == "sequential"

        # Step 4: Generate
        code = session.generate_code()
        assert code is not None
        assert len(code) > 200

        # Step 5: Validate
        validation = SyntaxValidator.validate(code)
        assert validation["valid"]

        # Step 6: Test
        result = session.test_route(
            {
                "order_id": "12345",
                "amount": 99.99,
                "customer": "Alice",
            }
        )
        assert result["success"] is True

        # Step 7: Summary
        summary = session.get_summary()
        assert summary["name"] == "order-processing"
        assert summary["type"] == "static"
        assert summary["pattern"] == "sequential"
        assert len(summary["agents"]) == 3

    def test_complete_dynamic_route_creation(self):
        """Test complete workflow for dynamic route."""
        session = RouteWriterSession()

        # Step 1: Basics
        session.set_basics("claim-routing", "Route insurance claims", "dynamic")

        # Step 2: Dynamic routing
        session.set_dynamic_routing(
            decision_inputs=["claim_type", "amount", "urgency"],
            routes=[
                {"condition": 'claim_type == "auto"', "agents": ["AutoAnalyst"]},
                {"condition": 'claim_type == "health"', "agents": ["HealthAnalyst"]},
                {"condition": 'amount > 50000', "agents": ["HighValueReviewer"]},
                {"condition": 'urgency == "critical"', "agents": ["CrisisTeam"]},
            ],
            fallback_agents=["GeneralAnalyst"],
        )

        # Step 3: Generate
        code = session.generate_code()
        assert code is not None

        # Step 4: Validate
        validation = SyntaxValidator.validate(code)
        assert validation["valid"]

        # Step 5: Test
        result = session.test_route(
            {
                "claim_type": "auto",
                "amount": 75000,
                "urgency": "normal",
            }
        )
        assert result["success"] is True

        # Step 6: Summary
        summary = session.get_summary()
        assert summary["name"] == "claim-routing"
        assert summary["type"] == "dynamic"
        assert summary["routes_count"] == 4


class TestAgentIntegration:
    """Integration tests with example agents."""

    @pytest.mark.asyncio
    async def test_course_creation_workflow(self):
        """Test course creation with multiple agents."""
        # Agents
        manager = CourseManagerAgent()
        writer = ChapterWriterAgent()
        critic = CriticAgent()

        # Step 1: Manager creates outline
        course_input = {
            "course_title": "Python for Beginners",
            "prerequisites": ["Basic Computer Skills"],
            "chapter_count": 3,
        }

        outline = await manager.invoke(course_input)
        assert outline["success"] is True
        assert len(outline["chapter_assignments"]) == 3

        # Step 2: Writers write chapters
        chapters = []
        for i, chapter in enumerate(outline["chapter_assignments"]):
            chapter_data = {
                "chapter_number": chapter["chapter_number"],
                "chapter_outline": chapter,
                "course_context": outline["outline"],
            }
            chapter_content = await writer.invoke(chapter_data)
            assert chapter_content["success"] is True
            chapters.append(chapter_content)

        # Step 3: Critic reviews
        critic_input = {"chapters": chapters, "outline": outline["outline"]}
        review = await critic.invoke(critic_input)
        assert review["success"] is True

    @pytest.mark.asyncio
    async def test_document_processing_workflow(self):
        """Test document processing workflow."""
        extractor = DocumentExtractorAgent()
        reviewer = DocumentReviewerAgent()
        aggregator = DocumentAggregatorAgent()

        # Step 1: Extract
        doc_input = {
            "document": "contract.pdf",
            "doc_type": "contract",
            "pages": 5,
        }

        extracted = await extractor.invoke(doc_input)
        assert extracted["success"] is True

        # Step 2: Review (simulated multiple reviewers)
        reviews = []
        for i in range(3):
            review = await reviewer.invoke(extracted)
            assert review["success"] is True
            reviews.append(review)

        # Step 3: Aggregate
        aggregate_input = {
            "extracted": extracted,
            "reviews": reviews,
        }

        final = await aggregator.invoke(aggregate_input)
        assert final["success"] is True
        assert "final_approval" in final


class TestCodeGenerationEdgeCases:
    """Test edge cases in code generation."""

    def test_single_agent_route(self):
        """Test route with single agent."""
        agents = [AgentConfig(name="SingleAgent")]

        definition = StaticRouteDefinition(
            name="single-agent",
            pattern="sequential",
            agents=agents,
        )

        generator = RouteCodeGenerator()
        code = generator.generate_static_route(definition)

        assert code is not None
        validation = SyntaxValidator.validate(code)
        assert validation["valid"]

    def test_many_agents_route(self):
        """Test route with many agents."""
        agents = [AgentConfig(name=f"Agent{i}") for i in range(10)]

        definition = StaticRouteDefinition(
            name="many-agents",
            pattern="fan_out",
            agents=agents,
        )

        generator = RouteCodeGenerator()
        code = generator.generate_static_route(definition)

        assert code is not None
        for agent in agents:
            assert agent.name not in code or "asyncio" in code

        validation = SyntaxValidator.validate(code)
        assert validation["valid"]

    def test_complex_condition_expression(self):
        """Test dynamic route with complex conditions."""
        routes = [
            ConditionalRoute(
                condition=(
                    '(amount > 100000 and type == "mortgage") or '
                    '(amount > 50000 and type == "auto")'
                ),
                agents=["ComplianceReviewer"],
            ),
        ]

        definition = DynamicRouteDefinition(
            name="complex-conditions",
            decision_inputs=["amount", "type"],
            routes=routes,
        )

        generator = RouteCodeGenerator()
        code = generator.generate_dynamic_route(definition)

        validation = SyntaxValidator.validate(code)
        assert validation["valid"]


class TestRouteWriterErrorHandling:
    """Test error handling in Route Writer."""

    def test_invalid_agent_name_rejected(self):
        """Test that invalid agent names are handled."""
        session = RouteWriterSession()
        session.set_basics("test", "test", "static")

        # Names should work as provided (no validation at set time)
        session.set_agents(["Agent-Name_123"])
        assert len(session.route_definition["agents"]) == 1

    def test_incomplete_definition_detection(self):
        """Test that incomplete definitions are caught."""
        session = RouteWriterSession()

        # Trying to generate without setting basics
        with pytest.raises(ValueError, match="name not set"):
            session.generate_code()

    def test_dynamic_route_validation(self):
        """Test validation of dynamic routes."""
        session = RouteWriterSession()
        session.set_basics("test", "test", "dynamic")

        # Missing decision inputs should fail
        with pytest.raises(ValueError):
            session.set_dynamic_routing([], [{"condition": "true", "agents": ["A"]}])

        # Missing routes should fail
        with pytest.raises(ValueError):
            session.set_dynamic_routing(["var"], [])


class TestPerformance:
    """Performance tests for code generation."""

    def test_code_generation_performance(self):
        """Test that code generation completes in reasonable time."""
        generator = RouteCodeGenerator()

        # Create a complex route
        agents = [AgentConfig(name=f"Agent{i}") for i in range(20)]

        definition = StaticRouteDefinition(
            name="perf-test",
            pattern="sequential",
            agents=agents,
        )

        # Should complete in < 1 second
        import time

        start = time.time()
        code = generator.generate_static_route(definition)
        duration = time.time() - start

        assert duration < 1.0, f"Code generation took {duration}s"
        assert code is not None

    def test_validation_performance(self):
        """Test that validation is fast."""
        generator = RouteCodeGenerator()

        agents = [AgentConfig(name=f"Agent{i}") for i in range(20)]
        definition = StaticRouteDefinition(
            name="perf-test",
            pattern="sequential",
            agents=agents,
        )

        code = generator.generate_static_route(definition)

        # Should validate in < 100ms
        import time

        start = time.time()
        result = SyntaxValidator.validate(code)
        duration = time.time() - start

        assert duration < 0.1, f"Validation took {duration}s"
        assert result["valid"]
