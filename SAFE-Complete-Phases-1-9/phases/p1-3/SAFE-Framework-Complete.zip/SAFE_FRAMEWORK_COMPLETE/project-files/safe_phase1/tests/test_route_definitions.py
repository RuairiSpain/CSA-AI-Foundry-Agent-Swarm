"""
Tests for route definition models.
"""

import pytest

from safe_core.route_definitions import (
    AgentConfig,
    ConditionalRoute,
    DynamicRouteDefinition,
    ErrorPolicy,
    StaticRouteDefinition,
)


class TestErrorPolicy:
    """Tests for ErrorPolicy enum."""

    def test_error_policies_exist(self):
        """Test that all error policies are defined."""
        assert ErrorPolicy.FAIL_HARD.value == "fail_hard"
        assert ErrorPolicy.SKIP_IF_ERROR.value == "skip_if_error"
        assert ErrorPolicy.RETRY.value == "retry"


class TestAgentConfig:
    """Tests for AgentConfig model."""

    def test_agent_config_minimal(self):
        """Test creating agent config with minimal parameters."""
        agent = AgentConfig(name="DocumentExtractor")
        assert agent.name == "DocumentExtractor"
        assert agent.version == "latest"
        assert agent.error_policy == ErrorPolicy.FAIL_HARD
        assert agent.timeout_seconds == 3600

    def test_agent_config_full(self):
        """Test creating agent config with all parameters."""
        agent = AgentConfig(
            name="DocumentExtractor",
            version="1.0",
            error_policy=ErrorPolicy.SKIP_IF_ERROR,
            timeout_seconds=1800,
        )
        assert agent.name == "DocumentExtractor"
        assert agent.version == "1.0"
        assert agent.error_policy == ErrorPolicy.SKIP_IF_ERROR
        assert agent.timeout_seconds == 1800


class TestStaticRouteDefinition:
    """Tests for StaticRouteDefinition model."""

    def test_static_route_creation(self):
        """Test creating a static route."""
        agents = [
            AgentConfig(name="Extractor"),
            AgentConfig(name="Reviewer"),
        ]

        route = StaticRouteDefinition(
            name="document-review",
            description="Reviews documents",
            pattern="sequential",
            agents=agents,
        )

        assert route.name == "document-review"
        assert route.route_type == "static"
        assert route.pattern == "sequential"
        assert len(route.agents) == 2

    def test_route_name_validation(self):
        """Test route name validation."""
        with pytest.raises(ValueError, match="alphanumeric"):
            StaticRouteDefinition(
                name="invalid@route",
                pattern="sequential",
                agents=[AgentConfig(name="Agent")],
            )

    def test_route_name_lowercase(self):
        """Test that route names are lowercased."""
        route = StaticRouteDefinition(
            name="DocumentReview",
            pattern="sequential",
            agents=[AgentConfig(name="Agent")],
        )
        assert route.name == "documentreview"


class TestDynamicRouteDefinition:
    """Tests for DynamicRouteDefinition model."""

    def test_dynamic_route_creation(self):
        """Test creating a dynamic route."""
        routes = [
            ConditionalRoute(
                condition='doc_type == "contract"',
                agents=["LegalReviewer"],
            ),
            ConditionalRoute(
                condition='doc_type == "policy"',
                agents=["PolicyReviewer", "ComplianceReviewer"],
            ),
        ]

        route = DynamicRouteDefinition(
            name="document-routing",
            description="Routes documents by type",
            decision_inputs=["doc_type", "sensitivity"],
            routes=routes,
            fallback_agents=["GeneralReviewer"],
        )

        assert route.name == "document-routing"
        assert route.route_type == "dynamic"
        assert len(route.routes) == 2
        assert len(route.decision_inputs) == 2
        assert len(route.fallback_agents) == 1

    def test_dynamic_route_requires_routes(self):
        """Test that dynamic route requires at least one conditional route."""
        with pytest.raises(ValueError):
            DynamicRouteDefinition(
                name="test-route",
                decision_inputs=["var"],
                routes=[],  # Empty routes not allowed
            )

    def test_dynamic_route_requires_decision_inputs(self):
        """Test that dynamic route requires decision inputs."""
        with pytest.raises(ValueError):
            DynamicRouteDefinition(
                name="test-route",
                decision_inputs=[],  # Empty not allowed
                routes=[ConditionalRoute(condition="true", agents=["Agent"])],
            )


class TestConditionalRoute:
    """Tests for ConditionalRoute model."""

    def test_conditional_route_creation(self):
        """Test creating a conditional route."""
        route = ConditionalRoute(
            condition='amount > 500000',
            agents=["ComplianceReviewer", "RiskAssessment"],
        )

        assert route.condition == 'amount > 500000'
        assert len(route.agents) == 2

    def test_conditional_route_single_agent(self):
        """Test conditional route with single agent."""
        route = ConditionalRoute(
            condition='status == "active"',
            agents=["Processor"],
        )

        assert len(route.agents) == 1
