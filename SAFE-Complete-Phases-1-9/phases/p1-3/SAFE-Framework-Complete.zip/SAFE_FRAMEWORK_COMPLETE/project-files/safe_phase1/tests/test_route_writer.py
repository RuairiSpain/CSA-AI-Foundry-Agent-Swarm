"""
Tests for Route Writer Agent.
"""

import pytest

from safe_core.route_writer import RouteWriterSession


class TestRouteWriterSession:
    """Tests for RouteWriterSession."""

    @pytest.fixture
    def session(self):
        """Provide route writer session."""
        return RouteWriterSession()

    def test_session_initialization(self, session):
        """Test route writer session initialization."""
        assert session.conversation_history == []
        assert session.route_definition == {}
        assert session.generated_code is None

    def test_add_message(self, session):
        """Test adding messages to conversation."""
        session.add_message("user", "Hello")
        session.add_message("assistant", "Hi there!")

        assert len(session.conversation_history) == 2
        assert session.conversation_history[0]["role"] == "user"
        assert session.conversation_history[1]["role"] == "assistant"

    def test_set_basics_valid(self, session):
        """Test setting basic route information."""
        session.set_basics("document-review", "Reviews documents", "static")

        assert session.route_definition["name"] == "document-review"
        assert session.route_definition["description"] == "Reviews documents"
        assert session.route_definition["route_type"] == "static"

    def test_set_basics_name_validation(self, session):
        """Test that invalid names are rejected."""
        with pytest.raises(ValueError, match="alphanumeric"):
            session.set_basics("invalid@route", "desc", "static")

    def test_set_basics_type_validation(self, session):
        """Test that invalid types are rejected."""
        with pytest.raises(ValueError, match="static or dynamic"):
            session.set_basics("test-route", "desc", "invalid")  # type: ignore

    def test_set_agents_single(self, session):
        """Test setting single agent."""
        session.set_agents(["DocumentExtractor"])

        assert len(session.route_definition["agents"]) == 1
        assert session.route_definition["agents"][0].name == "DocumentExtractor"

    def test_set_agents_multiple(self, session):
        """Test setting multiple agents."""
        agents = ["Extractor", "Reviewer", "Aggregator"]
        session.set_agents(agents)

        assert len(session.route_definition["agents"]) == 3
        names = [a.name for a in session.route_definition["agents"]]
        assert names == agents

    def test_set_agents_empty_rejected(self, session):
        """Test that empty agent list is rejected."""
        with pytest.raises(ValueError, match="At least one agent"):
            session.set_agents([])

    def test_set_pattern_valid(self, session):
        """Test setting valid pattern."""
        session.set_pattern("sequential")
        assert session.route_definition["pattern"] == "sequential"

        session.set_pattern("fan_out")
        assert session.route_definition["pattern"] == "fan_out"

    def test_set_pattern_invalid(self, session):
        """Test that invalid pattern is rejected."""
        with pytest.raises(ValueError, match="sequential, fan_out"):
            session.set_pattern("invalid_pattern")  # type: ignore

    def test_set_dynamic_routing_valid(self, session):
        """Test setting dynamic routing configuration."""
        routes = [
            {"condition": 'type == "A"', "agents": ["AgentA"]},
            {"condition": 'type == "B"', "agents": ["AgentB"]},
        ]

        session.set_dynamic_routing(
            decision_inputs=["type"],
            routes=routes,
            fallback_agents=["DefaultAgent"],
        )

        assert session.route_definition["decision_inputs"] == ["type"]
        assert len(session.route_definition["routes"]) == 2
        assert len(session.route_definition["fallback_agents"]) == 1

    def test_set_dynamic_routing_no_inputs(self, session):
        """Test that dynamic routing requires decision inputs."""
        with pytest.raises(ValueError, match="decision input"):
            session.set_dynamic_routing(
                decision_inputs=[],
                routes=[{"condition": "true", "agents": ["Agent"]}],
            )

    def test_set_dynamic_routing_no_routes(self, session):
        """Test that dynamic routing requires routes."""
        with pytest.raises(ValueError, match="conditional route"):
            session.set_dynamic_routing(
                decision_inputs=["var"],
                routes=[],
            )

    def test_generate_code_static_route(self, session):
        """Test generating code for static route."""
        session.set_basics("test-route", "Test description", "static")
        session.set_agents(["Agent1", "Agent2"])
        session.set_pattern("sequential")

        code = session.generate_code()

        assert code is not None
        assert len(code) > 100
        assert "route_test_route" in code
        assert "async def" in code

    def test_generate_code_dynamic_route(self, session):
        """Test generating code for dynamic route."""
        session.set_basics("routing-test", "Dynamic routing", "dynamic")
        session.set_dynamic_routing(
            decision_inputs=["type"],
            routes=[
                {"condition": 'type == "A"', "agents": ["AgentA"]},
            ],
        )

        code = session.generate_code()

        assert code is not None
        assert "route_routing_test" in code
        assert 'type == "A"' in code

    def test_generate_code_incomplete_route(self, session):
        """Test that incomplete route cannot be generated."""
        with pytest.raises(ValueError, match="name not set"):
            session.generate_code()

    def test_get_code_preview_no_code(self, session):
        """Test preview when no code generated."""
        preview = session.get_code_preview()
        assert "No code generated" in preview

    def test_get_code_preview_short_code(self, session):
        """Test preview of short code."""
        session.set_basics("test", "test", "static")
        session.set_agents(["Agent"])
        session.set_pattern("sequential")
        session.generate_code()

        preview = session.get_code_preview(max_lines=100)
        assert preview == session.generated_code

    def test_get_code_preview_long_code(self, session):
        """Test preview truncates long code."""
        session.set_basics("test", "test", "static")
        session.set_agents(["Agent"])
        session.set_pattern("sequential")
        session.generate_code()

        preview = session.get_code_preview(max_lines=5)
        assert "..." in preview or len(preview.split("\n")) <= 6

    def test_test_route_no_code(self, session):
        """Test route testing without generated code."""
        result = session.test_route({})
        assert result["success"] is False
        assert "No code generated" in result["error"]

    def test_test_route_with_code(self, session):
        """Test route with generated code."""
        session.set_basics("test", "test", "static")
        session.set_agents(["Agent"])
        session.set_pattern("sequential")
        session.generate_code()

        result = session.test_route({})
        assert result["success"] is True
        assert "route_test" in result.get("route_function", "")

    def test_get_summary_static_route(self, session):
        """Test getting summary of static route."""
        session.set_basics("doc-review", "Reviews docs", "static")
        session.set_agents(["Extractor", "Reviewer"])
        session.set_pattern("sequential")

        summary = session.get_summary()

        assert summary["name"] == "doc-review"
        assert summary["type"] == "static"
        assert summary["pattern"] == "sequential"
        assert len(summary["agents"]) == 2

    def test_get_summary_dynamic_route(self, session):
        """Test getting summary of dynamic route."""
        session.set_basics("routing", "Routes data", "dynamic")
        session.set_dynamic_routing(
            decision_inputs=["type", "amount"],
            routes=[
                {"condition": "type == A", "agents": ["A"]},
                {"condition": "type == B", "agents": ["B"]},
            ],
            fallback_agents=["Default"],
        )

        summary = session.get_summary()

        assert summary["name"] == "routing"
        assert summary["type"] == "dynamic"
        assert len(summary["decision_inputs"]) == 2
        assert summary["routes_count"] == 2
        assert len(summary["fallback_agents"]) == 1


class TestRouteWriterWorkflow:
    """Integration tests for route writer workflow."""

    def test_complete_static_route_workflow(self):
        """Test complete workflow for creating static route."""
        session = RouteWriterSession()

        # Step 1: Basics
        session.set_basics("document-review", "Review and approve documents", "static")

        # Step 2: Agents
        session.set_agents(["DocumentExtractor", "Reviewer", "Aggregator"])

        # Step 3: Pattern
        session.set_pattern("sequential")

        # Step 4: Generate
        code = session.generate_code()

        assert code is not None
        assert "route_document_review" in code

        # Step 5: Test
        result = session.test_route({"document": "test.pdf"})
        assert result["success"] is True

        # Step 6: Summary
        summary = session.get_summary()
        assert summary["name"] == "document-review"
        assert len(summary["agents"]) == 3

    def test_complete_dynamic_route_workflow(self):
        """Test complete workflow for creating dynamic route."""
        session = RouteWriterSession()

        # Step 1: Basics
        session.set_basics(
            "document-routing",
            "Route documents based on type",
            "dynamic",
        )

        # Step 2: Decision inputs
        session.set_dynamic_routing(
            decision_inputs=["doc_type", "sensitivity"],
            routes=[
                {"condition": 'doc_type == "contract"', "agents": ["LegalReviewer"]},
                {
                    "condition": 'doc_type == "policy"',
                    "agents": ["PolicyReviewer", "ComplianceReviewer"],
                },
                {
                    "condition": 'sensitivity == "high"',
                    "agents": ["SecurityReviewer", "ComplianceReviewer"],
                },
            ],
            fallback_agents=["GeneralReviewer"],
        )

        # Step 3: Generate
        code = session.generate_code()
        assert code is not None

        # Step 4: Test
        result = session.test_route(
            {
                "doc_type": "contract",
                "sensitivity": "high",
            }
        )
        assert result["success"] is True

        # Step 5: Summary
        summary = session.get_summary()
        assert summary["type"] == "dynamic"
        assert summary["routes_count"] == 3
