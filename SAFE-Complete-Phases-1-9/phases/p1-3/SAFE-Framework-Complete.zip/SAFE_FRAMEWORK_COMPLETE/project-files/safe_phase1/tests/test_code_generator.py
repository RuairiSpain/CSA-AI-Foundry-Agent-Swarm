"""
Tests for code generation.
"""

import pytest

from safe_core.code_generator import RouteCodeGenerator, SyntaxValidator
from safe_core.route_definitions import (
    AgentConfig,
    ConditionalRoute,
    DynamicRouteDefinition,
    StaticRouteDefinition,
)


class TestSyntaxValidator:
    """Tests for SyntaxValidator."""

    def test_valid_python_code(self):
        """Test validation of valid Python code."""
        code = """
def hello():
    print("Hello, World!")
"""
        result = SyntaxValidator.validate(code)
        assert result["valid"] is True
        assert len(result["errors"]) == 0

    def test_invalid_python_syntax(self):
        """Test validation of invalid Python syntax."""
        code = """
def hello(
    print("Missing closing paren")
"""
        result = SyntaxValidator.validate(code)
        assert result["valid"] is False
        assert len(result["errors"]) > 0
        assert "line" in result["errors"][0]

    def test_empty_code(self):
        """Test validation of empty code."""
        result = SyntaxValidator.validate("")
        assert result["valid"] is True

    def test_complex_valid_code(self):
        """Test validation of complex valid code."""
        code = """
import asyncio
from typing import Dict

async def process_data(data: Dict) -> str:
    await asyncio.sleep(1)
    return str(data)

class Processor:
    def __init__(self):
        self.data = {}
"""
        result = SyntaxValidator.validate(code)
        assert result["valid"] is True


class TestRouteCodeGenerator:
    """Tests for RouteCodeGenerator."""

    @pytest.fixture
    def generator(self):
        """Provide code generator instance."""
        return RouteCodeGenerator()

    def test_static_route_sequential(self, generator):
        """Test generating code for static sequential route."""
        agents = [
            AgentConfig(name="Extractor"),
            AgentConfig(name="Reviewer"),
            AgentConfig(name="Aggregator"),
        ]

        definition = StaticRouteDefinition(
            name="document-review",
            description="Reviews documents",
            pattern="sequential",
            agents=agents,
        )

        code = generator.generate_static_route(definition)

        assert code is not None
        assert "def route_document_review" in code
        assert "DocumentExtractor" not in code  # Agent names not hardcoded incorrectly
        assert "sequential" in code.lower() or "invoke" in code.lower()
        assert "asyncio" in code or "async" in code

        # Validate syntax
        validation = SyntaxValidator.validate(code)
        assert validation["valid"], f"Generated code has errors: {validation['errors']}"

    def test_static_route_fan_out(self, generator):
        """Test generating code for static fan-out route."""
        agents = [
            AgentConfig(name="Extractor"),
            AgentConfig(name="ReviewerA"),
            AgentConfig(name="ReviewerB"),
            AgentConfig(name="Aggregator"),
        ]

        definition = StaticRouteDefinition(
            name="parallel-review",
            pattern="fan_out",
            agents=agents,
        )

        code = generator.generate_static_route(definition)

        assert code is not None
        assert "async" in code
        assert "asyncio" in code
        # Syntax should be valid
        validation = SyntaxValidator.validate(code)
        assert validation["valid"]

    def test_dynamic_route_generation(self, generator):
        """Test generating code for dynamic route."""
        routes = [
            ConditionalRoute(
                condition='doc_type == "contract"',
                agents=["LegalReviewer"],
            ),
            ConditionalRoute(
                condition='doc_type == "policy"',
                agents=["PolicyReviewer"],
            ),
        ]

        definition = DynamicRouteDefinition(
            name="document-routing",
            description="Routes documents by type",
            decision_inputs=["doc_type"],
            routes=routes,
            fallback_agents=["GeneralReviewer"],
        )

        code = generator.generate_dynamic_route(definition)

        assert code is not None
        assert "def route_document_routing" in code
        assert 'doc_type == "contract"' in code
        assert "asyncio" in code

        # Validate syntax
        validation = SyntaxValidator.validate(code)
        assert validation["valid"], f"Generated code has errors: {validation['errors']}"

    def test_generate_any_definition_static(self, generator):
        """Test generic generate method with static definition."""
        agents = [AgentConfig(name="Agent1")]
        definition = StaticRouteDefinition(
            name="test-route",
            pattern="sequential",
            agents=agents,
        )

        code = generator.generate(definition)

        assert code is not None
        assert "route_test_route" in code
        assert SyntaxValidator.validate(code)["valid"]

    def test_generate_any_definition_dynamic(self, generator):
        """Test generic generate method with dynamic definition."""
        routes = [ConditionalRoute(condition="true", agents=["Agent1"])]
        definition = DynamicRouteDefinition(
            name="test-route",
            decision_inputs=["var"],
            routes=routes,
        )

        code = generator.generate(definition)

        assert code is not None
        assert "route_test_route" in code
        assert SyntaxValidator.validate(code)["valid"]

    def test_generate_invalid_definition(self, generator):
        """Test generate with invalid definition type."""
        with pytest.raises(ValueError, match="Unknown route definition type"):
            generator.generate("not a valid definition")  # type: ignore

    def test_generated_code_has_function(self, generator):
        """Test that generated code contains executable function."""
        agents = [AgentConfig(name="TestAgent")]
        definition = StaticRouteDefinition(
            name="test-route",
            pattern="sequential",
            agents=agents,
        )

        code = generator.generate_static_route(definition)

        # Try to compile and extract function
        namespace = {}
        exec(code, namespace)

        assert "route_test_route" in namespace
        assert callable(namespace["route_test_route"])


class TestCodeGenerationIntegration:
    """Integration tests for code generation pipeline."""

    def test_full_static_route_pipeline(self):
        """Test full pipeline: definition -> code -> validation."""
        # Create definition
        agents = [
            AgentConfig(name="Input"),
            AgentConfig(name="Process"),
            AgentConfig(name="Output"),
        ]

        definition = StaticRouteDefinition(
            name="data-pipeline",
            description="Simple data processing pipeline",
            pattern="sequential",
            agents=agents,
        )

        # Generate code
        generator = RouteCodeGenerator()
        code = generator.generate(definition)

        # Validate
        validation = SyntaxValidator.validate(code)
        assert validation["valid"], f"Errors: {validation['errors']}"

        # Check structure
        assert "async def route_data_pipeline" in code
        assert "kernel" in code
        assert "trace_context" in code

    def test_full_dynamic_route_pipeline(self):
        """Test full pipeline for dynamic route."""
        routes = [
            ConditionalRoute(condition="amount > 1000", agents=["ExpensiveAgent"]),
            ConditionalRoute(condition="amount <= 1000", agents=["CheapAgent"]),
        ]

        definition = DynamicRouteDefinition(
            name="cost-based-routing",
            decision_inputs=["amount"],
            routes=routes,
            fallback_agents=["DefaultAgent"],
        )

        generator = RouteCodeGenerator()
        code = generator.generate(definition)

        validation = SyntaxValidator.validate(code)
        assert validation["valid"]

        # Check logic
        assert "amount > 1000" in code
        assert "amount <= 1000" in code
        assert "DefaultAgent" in code
