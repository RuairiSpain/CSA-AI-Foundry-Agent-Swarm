# safe_core/agent_provisioning.py
"""
Agent provisioning system - handles copying, installing, and configuring agents.
"""

import shutil
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any
import yaml
from datetime import datetime

from safe_core.agent_validation import ContractValidator


class AgentProvisioner:
    """Provisions agents from templates into projects."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.agents_dir = project_root / "agents"
        self.templates_dir = project_root / "templates" / "agents"
        self.validator = ContractValidator()
    
    def provision_agent(
        self,
        template_id: str,
        agent_name: Optional[str] = None,
        pattern_id: Optional[str] = None,
        placeholder_id: Optional[str] = None,
        install_deps: bool = True
    ) -> Dict[str, Any]:
        """
        Provision an agent from template.
        
        Args:
            template_id: Template agent ID
            agent_name: Directory name (defaults to template_id)
            pattern_id: Pattern this is for (for validation)
            placeholder_id: Placeholder in pattern (for validation)
            install_deps: Whether to install dependencies
        
        Returns:
            {success: bool, agent_path: Path, errors: [str], warnings: [str]}
        """
        errors = []
        warnings = []
        
        if not agent_name:
            agent_name = template_id
        
        agent_path = self.agents_dir / agent_name
        
        # Validate template exists
        template_path = self._find_template(template_id)
        if not template_path:
            return {
                "success": False,
                "agent_path": None,
                "errors": [f"Template '{template_id}' not found"],
                "warnings": []
            }
        
        # Load template contract
        template_yaml = template_path / "agent.yaml"
        if not template_yaml.exists():
            return {
                "success": False,
                "agent_path": None,
                "errors": [f"agent.yaml not found in template"],
                "warnings": []
            }
        
        with open(template_yaml) as f:
            agent_contract = yaml.safe_load(f)
        
        # Validate compatibility with pattern if specified
        if pattern_id and placeholder_id:
            validation_result = self.validator.validate_agent_for_pattern(
                agent_contract,
                pattern_id,
                placeholder_id
            )
            
            if not validation_result.valid:
                errors.extend(validation_result.errors)
            
            if validation_result.warnings:
                warnings.extend(validation_result.warnings)
        
        if errors:
            return {
                "success": False,
                "agent_path": None,
                "errors": errors,
                "warnings": warnings
            }
        
        # Create agent directory
        if agent_path.exists():
            shutil.rmtree(agent_path)
        agent_path.mkdir(parents=True, exist_ok=True)
        
        # Copy files
        files_copied = self._copy_template_files(template_path, agent_path)
        
        # Create metadata file
        self._create_metadata_file(
            agent_path,
            template_id,
            agent_contract.get("version", "1.0"),
            pattern_id,
            placeholder_id
        )
        
        # Install dependencies
        if install_deps:
            req_file = agent_path / "requirements.txt"
            if req_file.exists():
                try:
                    subprocess.run(
                        ["pip", "install", "-r", str(req_file)],
                        check=True,
                        capture_output=True
                    )
                except subprocess.CalledProcessError as e:
                    warnings.append(f"Dependency installation failed: {e}")
        
        return {
            "success": True,
            "agent_path": agent_path,
            "files_copied": files_copied,
            "errors": errors,
            "warnings": warnings
        }
    
    def _find_template(self, template_id: str) -> Optional[Path]:
        """Find template directory."""
        # Try standalone
        standalone_path = self.templates_dir / "standalone" / template_id
        if standalone_path.exists():
            return standalone_path
        
        # Try patterns
        for pattern_dir in (self.templates_dir / "patterns").iterdir():
            if not pattern_dir.is_dir():
                continue
            
            # Check each placeholder
            for placeholder_dir in pattern_dir.iterdir():
                if placeholder_dir.name == template_id.split("_")[-1]:
                    # Match found
                    full_id = f"{pattern_dir.name}_{placeholder_dir.name}"
                    if full_id == template_id:
                        return placeholder_dir
        
        return None
    
    def _copy_template_files(self, template_path: Path, agent_path: Path) -> Dict[str, str]:
        """Copy template files to agent directory."""
        files_copied = {}
        
        # Copy agent.yaml
        src = template_path / "agent.yaml"
        if src.exists():
            shutil.copy(src, agent_path / "agent.yaml")
            files_copied["agent.yaml"] = "contract + metadata"
        
        # Copy agent.md
        src = template_path / "agent.md"
        if src.exists():
            shutil.copy(src, agent_path / "agent.md")
            files_copied["agent.md"] = "documentation"
        
        # Copy prompt.txt
        src = template_path / "prompt.txt"
        if src.exists():
            shutil.copy(src, agent_path / "prompt.txt")
            files_copied["prompt.txt"] = "system prompt"
        
        # Copy requirements.txt
        src = template_path / "requirements.txt"
        if src.exists():
            shutil.copy(src, agent_path / "requirements.txt")
            files_copied["requirements.txt"] = "dependencies"
        
        # Copy scripts directory
        src = template_path / "scripts"
        if src.exists() and src.is_dir():
            shutil.copytree(src, agent_path / "scripts")
            files_copied["scripts/"] = "helper code"
        
        return files_copied
    
    def _create_metadata_file(
        self,
        agent_path: Path,
        template_id: str,
        template_version: str,
        pattern_id: Optional[str],
        placeholder_id: Optional[str]
    ):
        """Create .agent-metadata.yml file."""
        metadata = {
            "source_template": f"templates/agents/{template_id}",
            "source_version": template_version,
            "copied_date": datetime.now().isoformat(),
            "customized": False,
            "customization_notes": []
        }
        
        if pattern_id and placeholder_id:
            metadata["pattern_assignment"] = {
                "pattern": pattern_id,
                "placeholder": placeholder_id,
                "assigned_date": datetime.now().isoformat()
            }
        
        metadata_file = agent_path / ".agent-metadata.yml"
        with open(metadata_file, "w") as f:
            yaml.dump(metadata, f, default_flow_style=False)


class AgentValidator:
    """Validates agents before using in routes."""
    
    def __init__(self):
        self.validator = ContractValidator()
    
    def validate_agent_directory(self, agent_path: Path) -> Dict[str, Any]:
        """Validate agent in project directory."""
        agent_yaml = agent_path / "agent.yaml"
        
        if not agent_yaml.exists():
            return {
                "valid": False,
                "errors": [f"agent.yaml not found at {agent_yaml}"],
                "warnings": []
            }
        
        with open(agent_yaml) as f:
            agent_contract = yaml.safe_load(f)
        
        # Load metadata
        metadata_file = agent_path / ".agent-metadata.yml"
        if metadata_file.exists():
            with open(metadata_file) as f:
                metadata = yaml.safe_load(f)
            
            # Check pattern assignment
            if "pattern_assignment" in metadata:
                pattern = metadata["pattern_assignment"].get("pattern")
                placeholder = metadata["pattern_assignment"].get("placeholder")
                
                return self.validator.validate_agent_for_pattern(
                    agent_contract,
                    pattern,
                    placeholder
                )
        
        # Just validate the contract itself
        if "contract" not in agent_contract:
            return {
                "valid": False,
                "errors": ["No contract defined"],
                "warnings": []
            }
        
        return {
            "valid": True,
            "errors": [],
            "warnings": []
        }


# ============================================================================
# Setup Functions
# ============================================================================

def setup_agent_templates(project_root: Path):
    """Set up agent templates directory structure."""
    templates_dir = project_root / "templates" / "agents"
    
    # Create directories
    (templates_dir / "standalone").mkdir(parents=True, exist_ok=True)
    (templates_dir / "patterns").mkdir(parents=True, exist_ok=True)
    
    # Create subdirectories for each pattern
    patterns = [
        "supervisor-manager",
        "fan-out-fan-in",
        "map-reduce",
        "sequential-pipeline"
    ]
    
    for pattern in patterns:
        (templates_dir / "patterns" / pattern).mkdir(exist_ok=True)


def setup_safe_project(project_root: Path):
    """Set up a new SAFE project with agent structure."""
    # Create directories
    (project_root / "agents").mkdir(exist_ok=True)
    (project_root / "routes").mkdir(exist_ok=True)
    (project_root / "tests").mkdir(exist_ok=True)
    
    # Set up templates
    setup_agent_templates(project_root)
    
    # Create README
    readme = project_root / "README.md"
    if not readme.exists():
        with open(readme, "w") as f:
            f.write("""# SAFE Project

A Simplified Agent Flow Engineering project using Microsoft Agent Framework.

## Structure

- `agents/` - Agent definitions
- `routes/` - Route definitions
- `templates/agents/` - Agent templates
- `tests/` - Tests

## Quick Start

List agents:
```bash
python -m safe_cli.cli list-agents
```

Create agent from template:
```bash
python -m safe_cli.cli create-agent --from-template
```

Create route:
```bash
python -m safe_cli.cli create-route-interactive --pattern supervisor-manager
```
""")
