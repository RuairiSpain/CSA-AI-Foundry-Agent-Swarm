# SAFE Recipe: Training Course Generation
## A Complex Dynamic Route Example

**Recipe ID:** `training-course-generation`  
**Complexity:** Advanced (dynamic routing, loops, state management)  
**Agents:** 7 (manager, writers, critic, designer, validator, publisher, orchestrator)  
**Pattern:** Dynamic routing with feedback loops  
**Use Case:** Corporate training course creation with governance

---

## Business Flow

```
Training Manager starts course creation
    ↓
Course Manager Agent validates prerequisites
    ↓
Manager creates outline
    ↓
Chapters assigned to Writers (parallel)
    ↓
All chapters complete? 
    → Yes: Continue
    → No: Wait for writers
    ↓
Chapters sent to Critic Agent for review
    ↓
Critic satisfied?
    → Yes: Continue
    → No: Critic sends feedback to Manager
         Manager re-assigns chapters to Writers
         Loop back to Critic
    ↓
Manager routes to Designer
    ↓
Chapters already in PowerPoint?
    → Yes: Skip designer, go to Validator
    → No: Send to Designer Agent
    ↓
Brand Validator checks formatting/branding
    ↓
Publisher saves to OneDrive
    ↓
Manager receives "Course Published" confirmation
```

---

## Agent Decomposition

| Agent | Role | Input | Output | Decision Point |
|-------|------|-------|--------|-----------------|
| **CourseManager** | Validates prerequisites, creates outline, orchestrates flow | Course title, prerequisites, chapters | Outline + chapter assignments | None (coordinator) |
| **ChapterWriter** | Writes chapter content based on outline | Chapter outline, context | Draft chapter (markdown/docx) | None (worker) |
| **CriticAgent** | Reviews chapters for quality, completeness, tone | Draft chapters | Approval or feedback | `approved=true/false` |
| **DesignerAgent** | Converts chapters to PowerPoint slides | Chapters + brand guide | Designed deck (pptx) | None (conditional invoke) |
| **BrandValidator** | Checks company branding, formatting, compliance | Chapters ± designed deck | Approved deck or feedback | `compliant=true/false` |
| **PublisherAgent** | Saves final course to OneDrive folder | Approved chapters | Confirmation + OneDrive link | None (final step) |
| **TrainingOrchestrator** | Super-agent; routes based on decisions | Everything | Final course package | Routes all decisions |

---

## Dynamic Route Definition (YAML)

```yaml
name: training-course-generation
version: "1.0"
type: dynamic
description: "Generate corporate training courses with multi-stage review loops."

# Initial setup
preprocessing:
  agent: CourseManager
  version: "1.0"
  role: "Validates prerequisites, creates outline, assigns chapters"

# Main decision tree
decision_input: 
  - critic_approved  # true/false after critic review
  - chapters_already_pptx  # true/false for designer skip
  - brand_compliant  # true/false after brand validator

# Phases
phases:
  - name: chapter_writing
    agents: [ChapterWriter]  # Parallel: one per chapter
    pattern: fan-out  # Each chapter written in parallel
    aggregation: fan-in  # Collect all chapters
  
  - name: critic_review
    agent: CriticAgent
    decision: critic_approved
    routes:
      - condition: "critic_approved == false"
        action: send_feedback_to_manager
        next_phase: chapter_writing  # Loop back
        note: "Manager re-assigns chapters to free writers"
      
      - condition: "critic_approved == true"
        action: continue
        next_phase: designer_decision

  - name: designer_decision
    agent: none  # Pure decision, no agent
    decision: chapters_already_pptx
    routes:
      - condition: "chapters_already_pptx == true"
        action: skip_designer
        next_phase: brand_validation
      
      - condition: "chapters_already_pptx == false"
        action: invoke_designer
        next_phase: designer_work

  - name: designer_work
    agent: DesignerAgent
    next_phase: brand_validation

  - name: brand_validation
    agent: BrandValidator
    decision: brand_compliant
    routes:
      - condition: "brand_compliant == false"
        action: send_feedback_to_manager
        next_phase: chapter_writing  # Loop back (or designer)
        note: "Manager can re-route to designer or update chapters"
      
      - condition: "brand_compliant == true"
        action: continue
        next_phase: publish

  - name: publish
    agent: PublisherAgent
    final: true
    output: course_package

# Error handling
error_handling:
  ChapterWriter:
    timeout: 86400  # 24 hours per chapter
    retry: 1
    on_failure: escalate_to_manager
  
  CriticAgent:
    timeout: 14400  # 4 hours
    on_failure: escalate_to_manager
  
  DesignerAgent:
    timeout: 86400  # 24 hours
    on_failure: skip_designer  # Use chapters as-is
  
  BrandValidator:
    timeout: 3600  # 1 hour
    on_failure: use_chapters_as_is

# Monitoring thresholds
monitoring:
  warn_if_loop_count > 3:  # More than 3 revision cycles
    action: escalate_to_training_director
  
  warn_if_total_duration > 604800:  # More than 1 week
    action: notify_manager_of_delay
```

---

## Generated Python Code (What Route Writer Produces)

```python
# File: /routes/training-course-generation/v1.0.py
# Generated by: DynamicRouteWriterAgent
# Timestamp: 2026-06-20T10:00:00Z

import asyncio
import json
from datetime import datetime
from enum import Enum
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from semantic_kernel import Kernel
from safe.workflow import WorkflowInput, WorkflowOutput, TraceContext


@dataclass
class CourseState:
    """Track course creation state across phases."""
    course_id: str
    chapters: List[Dict[str, Any]]
    outline: Dict[str, Any]
    critic_feedback: Optional[Dict] = None
    revision_count: int = 0
    designer_skipped: bool = False
    brand_issues: Optional[List[str]] = None
    final_deck: Optional[str] = None


class Phase(Enum):
    MANAGER_SETUP = "manager_setup"
    CHAPTER_WRITING = "chapter_writing"
    CRITIC_REVIEW = "critic_review"
    DESIGNER_DECISION = "designer_decision"
    DESIGNER_WORK = "designer_work"
    BRAND_VALIDATION = "brand_validation"
    PUBLISH = "publish"


async def training_course_generation(
    kernel: Kernel,
    input: WorkflowInput,
    trace_context: TraceContext
) -> WorkflowOutput:
    """
    Dynamic Route: training-course-generation
    
    Generates corporate training courses with multi-stage review and approval loops.
    Routes depend on:
      - critic_approved (critic review decision)
      - chapters_already_pptx (skip designer if chapters already in PowerPoint)
      - brand_compliant (brand validation decision)
    
    Can loop back to chapter writing or designer based on feedback.
    """
    
    state = CourseState(
        course_id=input.get("course_id", f"course-{datetime.now().timestamp()}"),
        chapters=[],
        outline={}
    )
    
    with trace_context.span("training_course_generation") as root_span:
        root_span.set_attribute("course_id", state.course_id)
        root_span.set_attribute("route", "training-course-generation")
        root_span.set_attribute("version", "1.0")
        
        # PHASE 1: Manager Setup (validate prerequisites, create outline)
        with trace_context.span("phase_manager_setup") as span:
            span.add_event("manager_setup_start")
            
            manager = kernel.get_agent("CourseManager")
            if not manager:
                raise ValueError("CourseManager agent not found")
            
            manager_output = await manager.invoke(
                {
                    "course_title": input.get("course_title"),
                    "prerequisites": input.get("prerequisites", []),
                    "chapter_count": input.get("chapter_count", 5)
                },
                trace_context=trace_context
            )
            
            state.outline = manager_output.get("outline", {})
            chapter_assignments = manager_output.get("chapter_assignments", [])
            
            span.add_event("manager_setup_complete", {
                "outline_created": True,
                "chapters_assigned": len(chapter_assignments)
            })
        
        # PHASE 2–6: Main Loop (can loop back on feedback)
        current_phase = Phase.CHAPTER_WRITING
        max_revision_loops = 5
        
        while state.revision_count < max_revision_loops:
            
            # PHASE 2: Parallel Chapter Writing
            if current_phase == Phase.CHAPTER_WRITING:
                with trace_context.span("phase_chapter_writing") as span:
                    span.add_event("chapter_writing_start", {
                        "chapter_count": len(chapter_assignments),
                        "revision_count": state.revision_count
                    })
                    
                    writer_tasks = []
                    for i, chapter_outline in enumerate(chapter_assignments):
                        writer = kernel.get_agent("ChapterWriter")
                        if not writer:
                            raise ValueError("ChapterWriter agent not found")
                        
                        task = writer.invoke(
                            {
                                "chapter_number": i + 1,
                                "chapter_outline": chapter_outline,
                                "course_context": state.outline,
                                "feedback": state.critic_feedback.get(f"chapter_{i+1}") if state.critic_feedback else None
                            },
                            trace_context=trace_context
                        )
                        writer_tasks.append((i + 1, task))
                    
                    # Execute all writers in parallel
                    writer_results = await asyncio.gather(
                        *[task for _, task in writer_tasks],
                        return_exceptions=True
                    )
                    
                    state.chapters = []
                    failed_chapters = []
                    
                    for (chapter_num, _), result in zip(writer_tasks, writer_results):
                        if isinstance(result, Exception):
                            failed_chapters.append((chapter_num, str(result)))
                            span.add_event("chapter_write_failed", {
                                "chapter": chapter_num,
                                "error": str(result)
                            })
                        else:
                            state.chapters.append({
                                "chapter_number": chapter_num,
                                "content": result.get("content"),
                                "metadata": result.get("metadata", {})
                            })
                    
                    if failed_chapters:
                        trace_context.warn(
                            f"Failed chapters: {failed_chapters}. Escalating to manager."
                        )
                        # Manager will re-assign failed chapters
                    
                    span.add_event("chapter_writing_complete", {
                        "successful": len(state.chapters),
                        "failed": len(failed_chapters)
                    })
                
                current_phase = Phase.CRITIC_REVIEW
            
            # PHASE 3: Critic Review (can loop back)
            elif current_phase == Phase.CRITIC_REVIEW:
                with trace_context.span("phase_critic_review") as span:
                    span.add_event("critic_review_start", {
                        "chapters_to_review": len(state.chapters)
                    })
                    
                    critic = kernel.get_agent("CriticAgent")
                    if not critic:
                        raise ValueError("CriticAgent agent not found")
                    
                    critic_output = await critic.invoke(
                        {
                            "chapters": state.chapters,
                            "outline": state.outline,
                            "revision_number": state.revision_count + 1
                        },
                        trace_context=trace_context
                    )
                    
                    critic_approved = critic_output.get("approved", False)
                    
                    span.add_event("critic_review_complete", {
                        "approved": critic_approved,
                        "has_feedback": "feedback" in critic_output
                    })
                    
                    # DECISION: Loop back or continue?
                    if not critic_approved:
                        state.critic_feedback = critic_output.get("feedback", {})
                        state.revision_count += 1
                        
                        span.add_event("critic_revision_needed", {
                            "revision_count": state.revision_count,
                            "feedback_chapters": list(state.critic_feedback.keys())
                        })
                        
                        if state.revision_count >= max_revision_loops:
                            trace_context.error(
                                f"Max revision loops ({max_revision_loops}) reached. Escalating."
                            )
                            # In production, escalate to training director
                            raise RuntimeError(
                                f"Course {state.course_id} exceeded max revision loops"
                            )
                        
                        # Loop back to chapter writing with feedback
                        current_phase = Phase.CHAPTER_WRITING
                    else:
                        # Critic approved; move to designer decision
                        current_phase = Phase.DESIGNER_DECISION
            
            # PHASE 4: Designer Decision (pure routing, no agent)
            elif current_phase == Phase.DESIGNER_DECISION:
                with trace_context.span("phase_designer_decision") as span:
                    # Check if chapters are already in PowerPoint format
                    chapters_are_pptx = any(
                        chapter.get("metadata", {}).get("format") == "pptx"
                        for chapter in state.chapters
                    )
                    
                    span.add_event("designer_decision", {
                        "chapters_already_pptx": chapters_are_pptx
                    })
                    
                    # DECISION: Skip designer or invoke?
                    if chapters_are_pptx:
                        state.designer_skipped = True
                        span.add_event("designer_skipped", {
                            "reason": "chapters_already_in_pptx"
                        })
                        current_phase = Phase.BRAND_VALIDATION
                    else:
                        current_phase = Phase.DESIGNER_WORK
            
            # PHASE 5: Designer Work (optional, based on decision)
            elif current_phase == Phase.DESIGNER_WORK:
                with trace_context.span("phase_designer_work") as span:
                    span.add_event("designer_work_start")
                    
                    designer = kernel.get_agent("DesignerAgent")
                    if not designer:
                        # Fallback: skip designer if not available
                        trace_context.warn("DesignerAgent not found, skipping design phase")
                        current_phase = Phase.BRAND_VALIDATION
                    else:
                        try:
                            designer_output = await asyncio.wait_for(
                                designer.invoke(
                                    {
                                        "chapters": state.chapters,
                                        "brand_guide": input.get("brand_guide", {}),
                                        "template": input.get("pptx_template")
                                    },
                                    trace_context=trace_context
                                ),
                                timeout=86400  # 24 hours
                            )
                            
                            state.final_deck = designer_output.get("designed_deck")
                            span.add_event("designer_work_complete", {
                                "deck_created": bool(state.final_deck)
                            })
                            
                        except asyncio.TimeoutError:
                            trace_context.error("Designer timeout; using chapters as-is")
                            # Use chapters as-is, skip to brand validation
                        
                        current_phase = Phase.BRAND_VALIDATION
            
            # PHASE 6: Brand Validation
            elif current_phase == Phase.BRAND_VALIDATION:
                with trace_context.span("phase_brand_validation") as span:
                    span.add_event("brand_validation_start")
                    
                    validator = kernel.get_agent("BrandValidator")
                    if not validator:
                        raise ValueError("BrandValidator agent not found")
                    
                    validator_output = await validator.invoke(
                        {
                            "chapters": state.chapters,
                            "designed_deck": state.final_deck,
                            "brand_guide": input.get("brand_guide", {}),
                            "compliance_checks": input.get("compliance_checks", [])
                        },
                        trace_context=trace_context
                    )
                    
                    brand_compliant = validator_output.get("compliant", False)
                    
                    span.add_event("brand_validation_complete", {
                        "compliant": brand_compliant,
                        "issues": len(validator_output.get("issues", []))
                    })
                    
                    # DECISION: Compliant or back to revisions?
                    if not brand_compliant:
                        state.brand_issues = validator_output.get("issues", [])
                        state.revision_count += 1
                        
                        span.add_event("brand_issues_found", {
                            "revision_count": state.revision_count,
                            "issue_count": len(state.brand_issues)
                        })
                        
                        if state.revision_count >= max_revision_loops:
                            trace_context.error("Max revisions; using current version")
                            # Fallback: proceed anyway
                        else:
                            # Loop back to chapter writing or designer
                            current_phase = Phase.CHAPTER_WRITING
                            continue
                    
                    # Compliant; proceed to publish
                    current_phase = Phase.PUBLISH
            
            # PHASE 7: Publish
            elif current_phase == Phase.PUBLISH:
                with trace_context.span("phase_publish") as span:
                    span.add_event("publish_start")
                    
                    publisher = kernel.get_agent("PublisherAgent")
                    if not publisher:
                        raise ValueError("PublisherAgent agent not found")
                    
                    publish_output = await publisher.invoke(
                        {
                            "chapters": state.chapters,
                            "final_deck": state.final_deck,
                            "course_metadata": {
                                "course_id": state.course_id,
                                "title": input.get("course_title"),
                                "created_at": datetime.now().isoformat(),
                                "revision_count": state.revision_count,
                                "designer_skipped": state.designer_skipped
                            },
                            "output_folder": input.get("onedrive_folder", "/shared/Training/Courses")
                        },
                        trace_context=trace_context
                    )
                    
                    onedrive_link = publish_output.get("onedrive_link")
                    
                    span.add_event("publish_complete", {
                        "onedrive_link": onedrive_link
                    })
                    
                    # Exit main loop
                    break
        
        # Compile final output
        final_output = {
            "status": "success" if current_phase == Phase.PUBLISH else "incomplete",
            "course_id": state.course_id,
            "chapters_count": len(state.chapters),
            "revision_count": state.revision_count,
            "designer_skipped": state.designer_skipped,
            "brand_issues": state.brand_issues,
            "onedrive_link": onedrive_link if current_phase == Phase.PUBLISH else None,
            "metadata": {
                "route": "training-course-generation",
                "version": "1.0",
                "execution_time": trace_context.duration
            }
        }
        
        root_span.add_event("route_complete", final_output)
        
        return final_output
```

---

## Workflow Definition (YAML)

```yaml
# File: workflows/training-course-production.yaml

name: TrainingCourseProduction
description: "End-to-end training course creation with feedback loops."
version: "1.0"

type: workflow

implementation:
  route: training-course-generation:1.0

preprocessing:
  agent: CourseInputValidator
  version: "1.0"
  role: "Validates course title, prerequisites, chapter count, OneDrive access"

postprocessing:
  agent: CourseCompletionNotifier
  version: "1.0"
  role: "Sends notification to training director with OneDrive link"

monitoring:
  warn_if_revision_count > 3:
    action: "notify_training_director"
    message: "Course exceeded 3 revision cycles; manual review recommended"
  
  warn_if_duration > 604800:  # 1 week
    action: "notify_training_director"
    message: "Course creation took >1 week; check for bottlenecks"

estimated_duration:
  happy_path: 72  # hours (3 days)
  with_revisions: 168  # hours (1 week with 2–3 revision cycles)
```

---

## CLI Walkthrough (What CSA Experiences)

### Step 1: Create the Route

```bash
$ /route create

RouteWriter: "What's the route name?"
CSA: "training-course-generation"

RouteWriter: "Description?"
CSA: "Generate corporate training courses with multi-stage review and approval loops."

RouteWriter: "Static or dynamic?"
CSA: "Dynamic"

RouteWriter: "What agents are involved?"
         Available: CourseManager, ChapterWriter, CriticAgent, DesignerAgent, 
                   BrandValidator, PublisherAgent
CSA: [selects all 6 agents]

RouteWriter: "What decision inputs will drive routing?"
         Examples: critic_approved, chapters_already_pptx, brand_compliant
CSA: "critic_approved - if false, loop back to writers
      chapters_already_pptx - if true, skip designer
      brand_compliant - if false, loop back to writers or designer"

RouteWriter: "What's the main pattern? [sequential | fan-out-fan-in | custom]"
CSA: "Custom - chapters written in parallel (fan-out), then converge to critic, 
      then conditional design, then validator, then publish"

RouteWriter: "Error handling?"
CSA: "ChapterWriter timeout 24h, escalate if fails
      CriticAgent timeout 4h
      DesignerAgent optional - use chapters as-is if fails
      BrandValidator optional - use current version if fails"

RouteWriter: "Preprocessing? (e.g., validate input)"
CSA: "Yes - CourseInputValidator"

RouteWriter: "Postprocessing? (e.g., notify on completion)"
CSA: "Yes - CourseCompletionNotifier"

RouteWriter: "Loop handling? (max revision cycles before escalate)"
CSA: "5 loops maximum"

RouteWriter: [generates code - shows preview with 150+ lines]

RouteWriter: "Preview looks good? Want to test with sample data?"
CSA: "Yes"

RouteWriter: "Sample input?"
CSA: "course_title: 'Python for Finance', 
      chapter_count: 5,
      prerequisites: ['Python 101'],
      onedrive_folder: '/shared/Training/Finance'"

RouteWriter: [tests route with sample data]
RouteWriter: ✅ "Test passed!
              
              - CourseManager: validated prerequisites, created outline
              - ChapterWriter: wrote 5 chapters in parallel (took ~5s mock)
              - CriticAgent: approved all chapters
              - chapters_already_pptx: false → invoke designer
              - DesignerAgent: created PowerPoint deck
              - BrandValidator: validated formatting
              - PublisherAgent: saved to OneDrive
              
              Revision count: 0
              Total duration: 12 seconds (mock)
              OneDrive link: https://company.sharepoint.com/.../Python-Finance-v1.pdf"

CSA: "Perfect! Publish as v1.0"

RouteWriter: "✅ Published to Foundry as training-course-generation v1.0
              Registered in Agent 365
              Status: ready
              
              You can now use it:
              /workflow create --name 'TrainingCourseProduction' 
                --route 'training-course-generation:1.0' 
                --preprocess 'CourseInputValidator' 
                --postprocess 'CourseCompletionNotifier'"
```

### Step 2: Create the Workflow

```bash
$ /workflow create --name TrainingCourseProduction \
    --route training-course-generation:1.0 \
    --preprocess CourseInputValidator:1.0 \
    --postprocess CourseCompletionNotifier:1.0

✅ Workflow created: TrainingCourseProduction
   Status: ready
   You can now invoke it with:
   /workflow invoke TrainingCourseProduction \
     --input '{"course_title":"...", "chapter_count": 5, ...}'
```

### Step 3: Invoke the Workflow (Training Manager's Perspective)

```bash
$ /workflow invoke TrainingCourseProduction \
    --input '{
      "course_title": "Advanced Python for Finance",
      "prerequisites": ["Python 101", "Finance Fundamentals"],
      "chapter_count": 6,
      "onedrive_folder": "/shared/Training/Finance/2026"
    }'

[Route executes across multiple phases...]

✅ Course Published!
   Course ID: course-1718872800
   Chapters: 6
   Revision count: 1 (critic had feedback, writers revised)
   OneDrive link: https://company.sharepoint.com/.../Advanced-Python-Finance-v1.pdf
   
   Notifications sent to:
   - Training Director (course ready for deployment)
   - Finance Team (course available)
```

### Step 4: Monitor Route Health

```bash
$ /health show training-course-generation:1.0

Route: training-course-generation v1.0
Status: ready
Executions (last 7 days): 12
Success rate: 100%
Average duration: 72 hours (3 days)
P95 latency: 4.2 days
Average cost: $8.50 per course
Estimated monthly cost: $1,020 (120 courses)

Flags: [ready]

Recent executions:
  1. course-1718872800: ✅ published (1 revision cycle, 2.8 days)
  2. course-1718786400: ✅ published (0 revision cycles, 2.1 days)
  3. course-1718700000: ✅ published (2 revision cycles, 4.5 days)
```

---

## Test Scenarios

### Scenario 1: Happy Path (No Revisions)

**Input:**
```json
{
  "course_title": "Python 101",
  "prerequisites": [],
  "chapter_count": 3,
  "onedrive_folder": "/shared/Training"
}
```

**Expected flow:**
- Manager validates (✅)
- 3 chapters written in parallel (✅)
- Critic approves (✅)
- chapters_already_pptx: false → invoke Designer (✅)
- Designer creates deck (✅)
- Brand Validator approves (✅)
- Publisher saves (✅)

**Duration:** ~2–3 days  
**Status:** Course published, no flags

---

### Scenario 2: One Revision Cycle

**Input:** Same as Scenario 1

**Critic feedback:** "Chapter 2 needs more examples"

**Expected flow:**
- Manager validates (✅)
- 3 chapters written (✅)
- Critic rejects (❌) → sends feedback
- Manager re-assigns Chapter 2 to a free writer
- Writer revises Chapter 2 (✅)
- All chapters sent back to Critic
- Critic approves (✅)
- Designer → Validator → Publisher (✅)

**Duration:** ~4–5 days  
**Status:** Course published, revision_count=1

---

### Scenario 3: Chapters Already in PowerPoint (Skip Designer)

**Input:**
```json
{
  "course_title": "Advanced SQL",
  "chapter_outline": [
    {
      "chapter": 1,
      "format": "pptx",  # Already in PowerPoint!
      "existing_file": "/shared/SQL-Chapter1.pptx"
    }
  ]
}
```

**Expected flow:**
- Manager validates (✅)
- Chapters already in pptx → skip Designer decision (✅)
- BrandValidator checks pptx formatting (✅)
- Publisher saves (✅)

**Duration:** ~1–2 days  
**Status:** Course published, designer_skipped=true

---

### Scenario 4: Designer Agent Times Out (Error Recovery)

**Designer timeout:** No response after 24 hours

**Expected flow:**
- Manager validates (✅)
- Chapters written (✅)
- Critic approves (✅)
- Designer invoked → timeout after 24h
- Fallback: use chapters as-is (⚠️ as markdown/docx, not PowerPoint)
- Brand Validator checks current version (✅)
- Publisher saves chapters as-is (✅)

**Duration:** ~1.5–2.5 days + 24h timeout = ~3 days  
**Status:** Course published with warning (designer_timeout), no PowerPoint deck

**Health Registry Flag:** `warn-slow` (exceeded SLA due to designer timeout)

---

### Scenario 5: Max Revision Cycles Exceeded

**Input:** Course with complex requirements

**Flow:**
- Revision cycle 1: Critic feedback → revise
- Revision cycle 2: Critic feedback → revise
- Revision cycle 3: Critic feedback → revise
- Revision cycle 4: Critic feedback → revise
- Revision cycle 5: Critic feedback → **max reached**
- Escalate to training director
- Director approves as-is or cancels

**Status:** `incomplete` (escalated, requires manual intervention)  
**Health Registry Flag:** `warn-failing` (high revision count)

---

## Integration with Foundry & Agent 365

### Foundry Catalog Entry

```json
{
  "name": "training-course-generation",
  "version": "1.0",
  "type": "route",
  "status": "published",
  "file": "/routes/training-course-generation/v1.0.py",
  
  "metadata": {
    "pattern": "dynamic-with-loops",
    "agents": [
      "CourseManager",
      "ChapterWriter",
      "CriticAgent",
      "DesignerAgent",
      "BrandValidator",
      "PublisherAgent"
    ],
    "decision_points": [
      "critic_approved",
      "chapters_already_pptx",
      "brand_compliant"
    ],
    "author": "training-team",
    "created_at": "2026-06-20T10:00:00Z",
    "tags": ["training", "course-generation", "complex-routing"],
    "estimated_duration_hours": 72,
    "estimated_cost_per_run": 8.50,
    "sla_latency_p95_seconds": 345600,  # 4 days
    "max_cost_per_run": 15.00,
    "error_recovery": {
      "designer_agent_timeout": "use_chapters_as_is",
      "brand_validator_failure": "proceed_with_warning"
    }
  }
}
```

### Agent 365 Registry Entry

```json
{
  "name": "training-course-generation-v1",
  "type": "Route",
  "owner": "training-team@company.com",
  "status": "Published",
  "tags": ["training", "complex"],
  "usage_count": 12,
  "last_executed": "2026-06-20T08:15:00Z",
  "health_status": "Healthy",
  
  "metrics": {
    "executions_last_7_days": 12,
    "success_rate": 1.0,
    "avg_duration_hours": 72,
    "p95_latency_hours": 96,
    "total_cost_last_7_days": 102.00,
    "estimated_monthly_cost": 1020.00
  },
  
  "governance": {
    "approval_required": false,
    "access_groups": ["training-team", "hr-team"],
    "cost_budget_monthly": 1500.00,
    "latency_sla_hours": 120
  }
}
```

---

## CSA Runbook: "I Want to Create a Training Course"

### Pre-Requisites
1. ✅ Foundry access (you have this)
2. ✅ All micro-agents deployed:
   - CourseManager, ChapterWriter, CriticAgent, DesignerAgent, BrandValidator, PublisherAgent
3. ✅ PowerPoint template (optional, for designer)
4. ✅ Brand guide (PDF or markdown)
5. ✅ OneDrive folder created

### Steps

#### 1. Design Your Course (15 min)
- Define course title and learning outcomes
- List chapter topics
- Identify prerequisites
- Decide if chapters are already in PowerPoint (for designer skip)

#### 2. Create the Route (with Route Writer) (15 min)
```bash
/route create --name training-course-generation
# Follow interactive prompts
# Route Writer will generate + test + publish
```

#### 3. Create the Workflow (5 min)
```bash
/workflow create --name TrainingCourseProduction \
  --route training-course-generation:1.0 \
  --preprocess CourseInputValidator:1.0 \
  --postprocess CourseCompletionNotifier:1.0
```

#### 4. Invoke the Workflow (Hands-off)
```bash
/workflow invoke TrainingCourseProduction \
  --input '{
    "course_title": "Your Course Title",
    "prerequisites": ["Pre-req 1", "Pre-req 2"],
    "chapter_count": 5,
    "onedrive_folder": "/shared/Training/YourCourse"
  }'
```

#### 5. Monitor Progress (Daily)
```bash
/health show training-course-generation:1.0

# Expect:
# - Revision count 0–2 (normal)
# - Duration 2–4 days (typical)
# - No flags or warn-* only
```

#### 6. Handle Feedback Loops (If Revision Needed)
**If Critic has feedback:**
- You (CourseManager) receive feedback via notification
- Reassign affected chapters to available ChapterWriters
- Writers revise
- Critic reviews again
- (Repeat up to 5 times; then escalate)

**If Brand Validator has issues:**
- You decide: fix chapters or send to designer to redesign
- Revise and loop back

#### 7. Course Published 🎉
- OneDrive link in final notification
- Share with team
- Track in course registry

### Estimated Timeline

| Phase | Duration | Parallel? |
|-------|----------|-----------|
| Manager setup | 30 min | — |
| Chapter writing | 24–48 h | Yes (all chapters in parallel) |
| Critic review | 4 h | — |
| (If revisions) | +24 h per cycle | — |
| Designer | 24 h | Optional |
| Brand validation | 1 h | — |
| Publish | 5 min | — |
| **Total (happy path)** | **2–3 days** | — |
| **Total (1 revision)** | **4–5 days** | — |

### Common Issues & Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| **ChapterWriter timeout** | Writer didn't submit within 24h | Reassign to another writer; notify original writer |
| **Critic keeps rejecting** | Outline unclear or expectations misaligned | Manager clarifies requirements with critic; restart writers |
| **Designer timeout** | Complex deck design | System uses chapters as-is; you can manually design later |
| **Brand compliance fails** | Branding/formatting issues | Revert to template or manual fix; loop back |

---

## Recipe Metadata (For SAFE Catalog)

```yaml
recipe_id: training-course-generation
recipe_name: "Training Course Generation with Review Loops"
complexity: advanced
pattern: dynamic-with-loops
agents_count: 7
use_case: corporate-training
industry: any
estimated_duration_hours: 72
estimated_cost_per_execution: 8.50

description: |
  End-to-end training course creation workflow with multi-stage reviews,
  feedback loops, optional design, and brand validation. Demonstrates:
  - Dynamic routing based on runtime decisions
  - Parallel execution (chapters written simultaneously)
  - Feedback loops (critic → writers → critic)
  - Conditional agents (skip designer if chapters already in PowerPoint)
  - Error recovery (designer timeout → use chapters as-is)
  - State management across phases

learning_objectives:
  - Understand complex dynamic routing
  - Handle feedback loops and state tracking
  - Implement conditional agent selection
  - Manage error recovery gracefully
  - Monitor long-running workflows

prerequisites:
  - Familiarity with SAFE routes and workflows
  - SAFE recipe: document-review (simpler static route)

deploy_checklist:
  - [ ] Implement all 6 micro-agents
  - [ ] Configure OneDrive integration
  - [ ] Setup PowerPoint template
  - [ ] Create brand guide document
  - [ ] Test with sample course (5 chapters)
  - [ ] Configure monitoring alerts
  - [ ] Train training team on runbook

tags:
  - training
  - course-generation
  - complex-routing
  - feedback-loops
  - production
```

---

## Next Steps (For Implementation)

1. **Define micro-agent specs** for each of the 7 agents (input/output contracts)
2. **Implement test ChapterWriter** (fast, deterministic for testing)
3. **Implement Route Writer interview logic** for dynamic routing (Week 2)
4. **Generate & test route code** with mocked agents (Week 3)
5. **Integrate with real agents** (Week 4–6)
6. **Test end-to-end** with sample courses (Week 6–7)
7. **Train CSA team** on route and runbook (Week 8)
8. **Deploy to Foundry + Agent 365** (Week 9)

---

**Recipe Status:** Ready for design phase  
**Estimated Implementation Time:** 6–8 weeks (after SAFE MVP)  
**Owner:** [Training Team Lead]  
**Last Updated:** 2026-06-20
