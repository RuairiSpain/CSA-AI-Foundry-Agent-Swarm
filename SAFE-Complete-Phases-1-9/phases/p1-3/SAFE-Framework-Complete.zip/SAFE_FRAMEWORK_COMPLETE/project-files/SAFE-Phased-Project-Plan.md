# SAFE Framework v2.0
## Detailed Phased Project Plan (12 Weeks)

**Project Duration:** 8–12 weeks (depending on team size)  
**Team Size:** 2–3 engineers + 1 CSA (for validation)  
**Language:** Python 3.11+  
**Success Criteria:** End-to-end route creation → invocation → health tracking

---

## Overview: The 9 Phases

| Phase | Name | Duration | Goal |
|-------|------|----------|------|
| **0** | Foundation | Weeks 1–2 | Infrastructure & dependencies |
| **1** | Route Writer Agent | Weeks 2–4 | Interactive route creation |
| **2** | Health Registry | Weeks 4–5 | Status tracking & auto-flags |
| **3** | Agent 365 Integration | Weeks 5–6 | Governance & lifecycle |
| **4** | Workflow Execution | Weeks 6–7 | Route invocation & metrics |
| **5** | CLI Polish | Weeks 7–8 | User experience |
| **6** | Reference Recipes | Weeks 8–9 | Example workflows |
| **7** | Testing & Hardening | Weeks 9–10 | Quality & reliability |
| **8** | Monitoring Agent | Weeks 10–11 | Auto-recovery & escalation |
| **9** | Release & Handoff | Weeks 11–12 | Production launch |

---

## Phase 0: Foundation (Weeks 1–2)

**Goal:** Repo structure, tooling, and dependency setup. Everything compiles and runs.

### Sprint 0.1: Repo & Tooling (Week 1)

**Deliverables:**
- [ ] GitHub repo created with standard structure (see Section 13, Repository Structure)
- [ ] `.python-version` pinned to 3.11
- [ ] `requirements.txt` with dependencies:
  ```
  semantic-kernel==1.0.0
  microsoft-agent-framework==0.2.0
  pytest==7.0.0
  pytest-asyncio==0.21.0
  typer==0.9.0  # CLI library
  pydantic==2.0.0
  python-dotenv==1.0.0
  opentelemetry-api==1.20.0
  opentelemetry-exporter-otlp==0.41b0
  ```
- [ ] CI/CD pipeline (GitHub Actions):
  - Run pytest on every push
  - Run linting (pylint, black)
  - Build docker image on main
- [ ] Local dev setup script (`scripts/setup-dev.sh`)
- [ ] Makefile for common tasks:
  ```makefile
  make setup       # Install deps
  make test        # Run tests
  make lint        # Run linters
  make run-cli     # Run CLI
  ```

**Tasks:**
- Setup repo structure
- Configure Python env (pyenv, venv)
- Setup linting (black, pylint config)
- Create GitHub Actions workflows
- Create local dev guide (docs/SETUP.md)

**Definition of Done:**
- All team members can `make setup && make test` and pass
- CI passes on main branch

### Sprint 0.2: Foundry & Agent 365 Auth (Week 1)

**Deliverables:**
- [ ] Foundry SDK client wrapper
  ```python
  class FoundryCatalog:
      def __init__(self, endpoint, api_key):
          self.client = FoundryClient(endpoint, api_key)
      
      async def publish_component(self, name, version, type, metadata):
          # Wrapper around Foundry API
          pass
  ```
- [ ] Agent 365 REST client
  ```python
  class Agent365Client:
      def __init__(self, tenant_id, client_id, client_secret):
          self.auth = AzureAuth(...)
          self.base_url = "https://agent365.microsoft.com/api"
      
      async def register_route(self, route_entry):
          # POST to /routes
          pass
  ```
- [ ] Entra ID authentication setup
  - Use `azure-identity` library for MSAL
  - Support both interactive (device flow) and service principal auth
- [ ] Config file support (`~/.safe/config.yaml`)
  ```yaml
  foundry:
    endpoint: https://...
    api_key: ${FOUNDRY_API_KEY}
  
  agent365:
    tenant_id: ${TENANT_ID}
    client_id: ${CLIENT_ID}
  
  opentelemetry:
    otlp_endpoint: https://...
  ```
- [ ] Unit tests for auth (mock Foundry/Agent 365 responses)

**Tasks:**
- Research Foundry Python SDK (or implement REST client if not available)
- Research Agent 365 REST API (endpoints, auth, payload schemas)
- Implement credential management (environment variables + config file)
- Add tests for auth failure scenarios
- Create auth setup guide for CSAs

**Definition of Done:**
- `FoundryCatalog` can authenticate and list components
- `Agent365Client` can authenticate and list agents
- Config file loads correctly
- All auth tests pass

### Sprint 0.3: MAF & SK Integration (Week 2)

**Deliverables:**
- [ ] MAF Kernel initialization
  ```python
  async def create_kernel(config: Dict) -> Kernel:
      kernel = Kernel()
      
      # Add SK plugins
      kernel.add_plugins(...)
      
      # Add middleware hooks (for health tracking)
      kernel.add_filter("route_health_tracking", health_middleware)
      
      # Setup OTel
      kernel.setup_telemetry(config["opentelemetry"])
      
      return kernel
  ```
- [ ] SK Memory integration
  ```python
  class SemanticKernelMemoryStore(IRouteHealthStore):
      def __init__(self, kernel: Kernel):
          self.memory = kernel.memory
      
      async def get(self, route_id, version):
          return await self.memory.get(f"route:{route_id}:{version}")
  ```
- [ ] OTel setup
  - Configure OTLP exporter
  - Add GenAI semantic conventions
  - Verify spans show up in local collector
- [ ] Test kernel lifecycle (startup, shutdown, memory cleanup)

**Tasks:**
- Create `kernel_factory.py` with kernel initialization
- Implement SK Memory wrapper
- Setup local OTel collector (Docker compose)
- Write integration tests for kernel lifecycle
- Document kernel setup for team

**Definition of Done:**
- Kernel initializes and runs a simple agent
- SK Memory store works (write/read)
- OTel traces appear in local collector
- All integration tests pass

---

## Phase 1: Route Writer Agent (Weeks 2–4)

**Goal:** CSAs can interactively create routes (static + dynamic). Generated code compiles and runs.

### Sprint 1.1: Code Generation Foundation (Week 2)

**Deliverables:**
- [ ] Route code generation templates (Jinja2)
  - Static route template (sequential, fan-out, fan-in, handoff)
  - Dynamic route template (decision tree)
  ```python
  # templates/static_route.py.jinja2
  async def {{ route_name }}(kernel, input, trace_context):
      """Route: {{ route_name }}"""
      
      {% for agent in ordered_agents %}
      {{ agent }} = kernel.get_agent("{{ agent }}")
      {% endfor %}
      
      # Phase 1: {{ phase1_agent }}
      result1 = await {{ phase1_agent }}.invoke(input)
      
      # ... more phases
  ```
- [ ] Route definition model (Pydantic)
  ```python
  class StaticRouteDefinition(BaseModel):
      name: str
      type: Literal["static"]
      pattern: str  # sequential, fan-out-fan-in, etc.
      agents: List[str]
      error_handling: Dict[str, str]  # per-agent policy
  
  class DynamicRouteDefinition(BaseModel):
      name: str
      type: Literal["dynamic"]
      decision_inputs: List[str]
      routes: List[ConditionalRoute]  # condition → agents
      aggregator: str
  ```
- [ ] Code generator class
  ```python
  class RouteCodeGenerator:
      def generate_static(self, definition: StaticRouteDefinition) -> str:
          template = self.env.get_template("static_route.py.jinja2")
          return template.render(route_def=definition)
      
      def generate_dynamic(self, definition: DynamicRouteDefinition) -> str:
          template = self.env.get_template("dynamic_route.py.jinja2")
          return template.render(route_def=definition)
  ```
- [ ] Python syntax validator
  ```python
  def validate_python_syntax(code: str) -> Dict[str, Any]:
      try:
          compile(code, "<string>", "exec")
          return {"valid": True, "errors": []}
      except SyntaxError as e:
          return {"valid": False, "errors": [{"line": e.lineno, "msg": e.msg}]}
  ```
- [ ] Unit tests for code generation (static + dynamic templates)

**Tasks:**
- Design Jinja2 templates for all pattern types
- Implement Pydantic models for route definitions
- Build code generator (render templates)
- Implement syntax validator
- Write unit tests for each template type
- Document template variables

**Definition of Done:**
- All templates render without errors
- Generated code validates (syntax check passes)
- Unit tests pass (>90% coverage for code generation)
- CSA can manually create a route definition YAML and see valid Python output

### Sprint 1.2: Route Writer Agent (Interview Loop) (Week 3)

**Deliverables:**
- [ ] Route Writer Agent skeleton
  ```python
  class DynamicRouteWriterAgent:
      def __init__(self, kernel: Kernel, code_generator: RouteCodeGenerator):
          self.kernel = kernel
          self.code_gen = code_generator
          self.conversation = []
          self.route_definition = {}
      
      async def start_session(self, initial_prompt: str = None):
          """Main interview loop."""
          await self.ask_basics()
          
          if self.route_definition["type"] == "static":
              await self.ask_static_route()
          else:
              await self.ask_dynamic_route()
          
          await self.ask_error_handling()
          await self.generate_and_preview()
      
      async def ask_basics(self):
          """Interview phase 1: name, type, description."""
          pass
      
      async def ask_static_route(self):
          """Interview phase 2a: static route specifics."""
          pass
      
      async def ask_dynamic_route(self):
          """Interview phase 2b: dynamic route specifics."""
          pass
  ```
- [ ] Integration with MAF's agent invocation
  - Route Writer is a MAF agent (has skills, tools, reasoning)
  - Uses MAF's AgentSkillsProvider to load interview "skills"
- [ ] Tools for Route Writer
  ```python
  tools = {
      "list_agents": self._list_agents(),
      "list_patterns": self._list_patterns(),
      "get_agent_schema": self._get_agent_schema(),
      "validate_syntax": self._validate_python(),
      "test_route": self._test_route(),
  }
  ```
- [ ] Conversation state management
  - Store conversation history
  - Build route_definition incrementally
  - Allow backtracking (ask again, edit previous answer)

**Tasks:**
- Implement question/answer loop (async)
- Create tools for agent discovery (list_agents, list_patterns)
- Implement state machine for interview flow
- Add logging for conversation history
- Write tests for interview flow (mock user input)
- Create example dialogues (doc as conversation script)

**Definition of Done:**
- Route Writer Agent can be invoked (e.g., `route_writer.start_session()`)
- Interview loop completes without errors
- Generated route_definition is valid (passes Pydantic validation)
- Tests show complete interview flows (static, dynamic, error cases)

### Sprint 1.3: Code Generation & Testing (Week 4)

**Deliverables:**
- [ ] Code generation from route definition
  ```python
  async def generate_code(self, definition):
      code = self.code_gen.generate(definition)
      
      # Validate syntax
      validation = validate_python_syntax(code)
      if not validation["valid"]:
          raise ValueError(f"Generated code has errors: {validation['errors']}")
      
      return code
  ```
- [ ] Route testing framework
  ```python
  async def test_route(self, code: str, sample_input: Dict) -> Dict:
      """Load generated route code and test with sample data."""
      
      # Dynamically import generated code
      spec = importlib.util.spec_from_loader("generated_route", loader=None)
      module = importlib.util.module_from_spec(spec)
      exec(code, module.__dict__)
      
      # Extract the async function
      route_func = getattr(module, "route_" + self.route_name)
      
      # Execute
      result = await route_func(self.kernel, sample_input, trace_context)
      return {"success": True, "output": result}
  ```
- [ ] Integration test: interview → code → test
  - Mock Foundry/Agent 365
  - Simulate CSA answering questions
  - Generate code
  - Run test with sample data
  - Verify output schema

**Tasks:**
- Implement code generation step
- Build route testing harness
- Add error handling (compilation failures, runtime errors)
- Write integration test for complete flow
- Create test fixtures (sample routes, test data)
- Document testing strategy

**Definition of Done:**
- Route Writer can generate valid Python code
- Generated code can be tested with sample input
- Integration test passes (mock interview → code → test)
- CSA can see preview of generated code before publishing

---

## Phase 2: Health Registry (Weeks 4–5)

**Goal:** Track route execution metrics and automatically detect issues.

### Sprint 2.1: Data Model & Storage (Week 4)

**Deliverables:**
- [ ] RouteHealthRecord and RouteExecution models
  ```python
  @dataclass
  class RouteExecution:
      route_id: str
      version: str
      success: bool
      duration_seconds: float
      tokens_used: int
      error: Optional[str]
      timestamp: datetime
  
  @dataclass
  class RouteHealthRecord:
      route_id: str
      version: str
      status_flags: Set[str]  # ready, warn-cost, warn-failing, etc.
      execution_count: int
      success_rate: float
      p95_latency_seconds: float
      avg_tokens_used: int
      estimated_monthly_cost: float
      sla_latency_p95: float = 45.0
      max_cost_per_run: float = 1.50
      max_failure_rate: float = 0.10
  ```
- [ ] IRouteHealthStore interface
  ```python
  class IRouteHealthStore(ABC):
      @abstractmethod
      async def get(self, route_id: str, version: str) -> RouteHealthRecord:
          pass
      
      @abstractmethod
      async def upsert(self, record: RouteHealthRecord) -> None:
          pass
      
      @abstractmethod
      async def record_execution(self, execution: RouteExecution) -> None:
          pass
      
      @abstractmethod
      async def query_by_status(self, flag: str) -> List[RouteHealthRecord]:
          pass
  ```
- [ ] SK-based implementation
  ```python
  class SemanticKernelRouteHealthStore(IRouteHealthStore):
      def __init__(self, kernel: Kernel):
          self.memory = kernel.memory
      
      async def record_execution(self, execution: RouteExecution):
          key = f"route:{execution.route_id}:{execution.version}:executions"
          await self.memory.save_record(key, json.dumps(asdict(execution)))
  ```
- [ ] Unit tests for store operations

**Tasks:**
- Define data models (Pydantic + dataclasses)
- Design SK Memory schema (keys, values)
- Implement SK store
- Write CRUD tests
- Document store design

**Definition of Done:**
- All data models validated
- SK store passes CRUD tests
- Executions can be saved and retrieved
- Query-by-status works

### Sprint 2.2: Automatic Flag Detection & Metrics (Week 5)

**Deliverables:**
- [ ] RouteHealthRegistry class
  ```python
  class RouteHealthRegistry:
      def __init__(self, store: IRouteHealthStore):
          self.store = store
      
      async def record_execution(self, execution: RouteExecution):
          """Called by MAF middleware after each invocation."""
          await self.store.record_execution(execution)
          
          # Update rolling metrics
          health = await self.store.get(execution.route_id, execution.version)
          health.execution_count += 1
          health.success_rate = await self._calculate_success_rate(execution.route_id)
          health.p95_latency_seconds = await self._calculate_p95(execution.route_id)
          health.estimated_monthly_cost = await self._estimate_cost(execution.route_id)
          
          # Check and set flags
          await self._check_and_set_flags(health)
          
          await self.store.upsert(health)
      
      async def _check_and_set_flags(self, health: RouteHealthRecord):
          """Auto-detect issues and set flags."""
          if health.estimated_monthly_cost > 10000:
              health.status_flags.add("warn-cost")
          
          if health.success_rate < 0.90:
              health.status_flags.add("warn-failing")
          
          if health.p95_latency_seconds > health.sla_latency_p95:
              health.status_flags.add("warn-slow")
  ```
- [ ] MAF middleware hook for execution tracking
  ```python
  async def route_health_tracking_filter(context, next_func):
      route_id = context.get("route_id")
      start_time = time.time()
      start_tokens = context.token_count
      
      try:
          await next_func()
          success = True
          error = None
      except Exception as e:
          success = False
          error = str(e)
          raise
      finally:
          if route_id:
              execution = RouteExecution(
                  route_id=route_id,
                  version=context.get("version"),
                  success=success,
                  duration_seconds=time.time() - start_time,
                  tokens_used=context.token_count - start_tokens,
                  error=error,
                  timestamp=datetime.now()
              )
              health_registry.record_execution(execution)
  ```
- [ ] Query API
  ```python
  async def get_health(self, route_id: str, version: str) -> RouteHealthRecord:
      return await self.store.get(route_id, version)
  
  async def routes_by_flag(self, flag: str) -> List[RouteHealthRecord]:
      return await self.store.query_by_status(flag)
  ```
- [ ] Unit tests for flag detection, metrics calculation

**Tasks:**
- Implement RouteHealthRegistry
- Add MAF middleware for execution tracking
- Implement metrics calculation (success_rate, p95, cost estimation)
- Write flag detection logic with thresholds
- Add unit tests for all metrics
- Create monitoring alert definitions

**Definition of Done:**
- RouteHealthRegistry can be instantiated
- Executions are recorded and metrics updated
- Flags are auto-set when thresholds exceeded
- Query API works (get_health, routes_by_flag)
- All tests pass

---

## Phase 3: Agent 365 Integration (Weeks 5–6)

**Goal:** Routes are registered and governed in Agent 365. Admins can block/unblock routes.

### Sprint 3.1: Registration & Sync (Week 5)

**Deliverables:**
- [ ] Agent 365 registration when route is published
  ```python
  async def publish_route(self, code: str, definition: RouteDefinition):
      # Save to Foundry
      route_component = await self.foundry_catalog.publish(...)
      
      # Register in Agent 365
      route_entry = {
          "name": f"{definition.name}-v{definition.version}",
          "type": "Route",
          "owner": self.csa_email,
          "status": "Published",
          "metadata": {
              "pattern": definition.pattern,
              "agents": definition.agents,
              "sla_latency_p95": definition.sla_latency_p95,
              "cost_budget": definition.max_cost_per_run
          }
      }
      
      await self.agent365_client.register_route(route_entry)
  ```
- [ ] Agent 365 client methods
  ```python
  class Agent365Client:
      async def register_route(self, entry: Dict) -> str:
          """Register a new route."""
      
      async def list_routes(self) -> List[Dict]:
          """List all routes."""
      
      async def get_route(self, route_id: str) -> Dict:
          """Get route details."""
      
      async def update_route_status(self, route_id: str, status: str) -> None:
          """Update lifecycle status (block, unblock, retire)."""
      
      async def set_approval_required(self, route_id: str, required: bool) -> None:
          """Mark route as requiring approval before promotion."""
  ```
- [ ] Audit logging for all Agent 365 operations

**Tasks:**
- Design Agent 365 entry schema
- Implement registration flow
- Add error handling (registration failures)
- Create audit log entries
- Test registration with mock Agent 365

**Definition of Done:**
- Routes can be registered in Agent 365
- Route metadata appears in Agent 365 API response
- Audit log shows registration events

### Sprint 3.2: Lifecycle Management & Admin Actions (Week 6)

**Deliverables:**
- [ ] Block/unblock routes
  ```python
  async def block_route(self, route_id: str, reason: str = None):
      """Block a route from being invoked."""
      await self.agent365_client.update_route_status(
          route_id,
          status="Blocked",
          reason=reason
      )
      
      # Also update Health Registry
      health = await self.health_registry.get_health(route_id, version="all")
      for h in health:
          h.status_flags.add("offline")
          await self.health_registry.store.upsert(h)
  ```
- [ ] Approval workflows
  ```python
  async def request_approval_for_promotion(self, route_id: str, from_version: str, to_version: str):
      """Request approval from route admins."""
      await self.agent365_client.request_approval(
          route_id=route_id,
          action="promote",
          from_version=from_version,
          to_version=to_version
      )
  ```
- [ ] Admin dashboard query
  ```python
  async def get_admin_dashboard(self) -> Dict:
      """Dashboard for admins: routes by status, recent changes, etc."""
      routes = await self.agent365_client.list_routes()
      health = [await self.health_registry.get_health(r["id"]) for r in routes]
      
      return {
          "total_routes": len(routes),
          "healthy": len([h for h in health if not h.status_flags]),
          "with_warnings": len([h for h in health if h.status_flags]),
          "blocked": len([r for r in routes if r["status"] == "Blocked"]),
          "routes_by_flag": {
              "warn-cost": await self.health_registry.routes_by_flag("warn-cost"),
              "warn-failing": await self.health_registry.routes_by_flag("warn-failing"),
              "warn-slow": await self.health_registry.routes_by_flag("warn-slow"),
          }
      }
  ```
- [ ] Integration test: publish → register → block → unblock

**Tasks:**
- Implement block/unblock logic
- Implement approval workflow integration
- Create admin dashboard query
- Write integration tests
- Document admin workflows

**Definition of Done:**
- Routes can be blocked/unblocked
- Admin dashboard shows route health status
- Approval workflow works end-to-end
- All integration tests pass

---

## Phase 4: Workflow Execution (Weeks 6–7)

**Goal:** Routes can be invoked from CLI. Metrics are recorded in Health Registry.

### Sprint 4.1: Route Loader & Executor (Week 6)

**Deliverables:**
- [ ] Dynamic route loader
  ```python
  class RouteLoader:
      async def load_route(self, route_id: str, version: str) -> Callable:
          """Load route code from Foundry and return the async function."""
          code = await self.foundry_catalog.get_route_code(route_id, version)
          
          # Compile and import
          spec = importlib.util.spec_from_loader("route_module", loader=None)
          module = importlib.util.module_from_spec(spec)
          exec(code, module.__dict__)
          
          # Extract function (e.g., route_document_review)
          route_func_name = f"route_{route_id.replace('-', '_')}"
          return getattr(module, route_func_name)
  ```
- [ ] Route executor
  ```python
  class RouteExecutor:
      async def invoke(self, route_id: str, version: str, input_data: Dict, trace_context) -> Dict:
          """Execute a route."""
          
          # Check if route is blocked
          health = await self.health_registry.get_health(route_id, version)
          if "offline" in health.status_flags or health.status_flags & {"frozen"}:
              raise RouteBlockedError(f"Route {route_id} is blocked: {health.status_flags}")
          
          # Load and invoke
          route_func = await self.loader.load_route(route_id, version)
          
          # Execution happens with middleware hooks active
          result = await route_func(
              kernel=self.kernel,
              input=input_data,
              trace_context=trace_context
          )
          
          return result
  ```
- [ ] Error handling (missing agents, timeouts, etc.)

**Tasks:**
- Implement route loader (dynamic code loading)
- Implement route executor
- Add error handling and recovery
- Write unit tests for loader/executor
- Test with generated routes

**Definition of Done:**
- Routes can be loaded dynamically
- Routes can be executed with sample input
- Errors are caught and reported
- All tests pass

### Sprint 4.2: Workflow Orchestration & CLI Integration (Week 7)

**Deliverables:**
- [ ] Workflow executor
  ```python
  class WorkflowExecutor:
      async def invoke(self, workflow_id: str, input_data: Dict):
          """Execute a workflow (route + pre/post-processing)."""
          
          workflow = await self.catalog.get_workflow(workflow_id)
          
          # Preprocessing
          if workflow.preprocessing:
              preprocessor = self.kernel.get_agent(workflow.preprocessing)
              input_data = await preprocessor.invoke(input_data)
          
          # Main route
          route_result = await self.route_executor.invoke(
              workflow.route.id,
              workflow.route.version,
              input_data
          )
          
          # Postprocessing
          if workflow.postprocessing:
              postprocessor = self.kernel.get_agent(workflow.postprocessing)
              output = await postprocessor.invoke(route_result)
          else:
              output = route_result
          
          return output
  ```
- [ ] CLI commands
  ```python
  @app.command()
  async def workflow_invoke(
      name: str = typer.Argument(..., help="Workflow name"),
      input_file: str = typer.Option(None, help="JSON input file"),
      input_raw: str = typer.Option(None, help="Raw JSON input")
  ):
      """Invoke a workflow."""
      
      if input_file:
          with open(input_file) as f:
              input_data = json.load(f)
      elif input_raw:
          input_data = json.loads(input_raw)
      else:
          raise ValueError("Provide either --input-file or --input-raw")
      
      executor = WorkflowExecutor(kernel, catalog)
      result = await executor.invoke(name, input_data)
      
      typer.echo(json.dumps(result, indent=2))
  ```
- [ ] Trace propagation & context
  - Ensure OTel context flows through workflow → route → agents

**Tasks:**
- Implement workflow executor
- Create CLI commands (invoke, show, list)
- Add input validation
- Add output formatting (JSON, pretty-print)
- Write integration tests
- Document workflow usage

**Definition of Done:**
- Workflows can be created and stored
- Workflows can be invoked via CLI
- Results are returned and formatted
- Traces show complete flow
- Integration tests pass

---

## Phase 5: CLI Polish & Documentation (Weeks 7–8)

**Goal:** CSAs can use SAFE without reading source code.

### Sprint 5.1: CLI Usability (Week 7)

**Deliverables:**
- [ ] Help system
  ```bash
  /route --help
  /route create --help
  /workflow invoke --help
  /health show --help
  ```
- [ ] Better error messages
  - Human-readable errors
  - Suggestions for common mistakes
  - Links to docs
- [ ] Interactive prompts
  ```bash
  route create
  > Route name? document-routing
  > Static or dynamic? (static/dynamic) static
  > Design pattern? (sequential/fan-out-fan-in/handoff) fan-out-fan-in
  ```
- [ ] Output formatting
  - JSON (for scripts)
  - Table (for human reading)
  - YAML (for config)
  ```bash
  /health show doc-routing:1.0 --format table
  /health show doc-routing:1.0 --format json
  /health show doc-routing:1.0 --format yaml
  ```
- [ ] Config file support (~/.safe/config.yaml)
  ```yaml
  default_catalog: foundry
  default_output_format: table
  auto_promote_routes: false
  ```

**Tasks:**
- Add comprehensive help text
- Improve error messages
- Implement interactive prompts (using `typer` or `inquirer`)
- Add output formatters
- Test all CLI paths
- Create usage examples

**Definition of Done:**
- All CLI commands have help text
- Error messages are clear and actionable
- Interactive prompts work
- Output can be formatted as JSON/table/YAML
- Config file loads and is respected

### Sprint 5.2: Documentation & CSA Guide (Week 8)

**Deliverables:**
- [ ] CSA user guide (docs/CSA_GUIDE.md)
  - How to create a route (step-by-step walkthrough)
  - How to test a route
  - How to invoke a workflow
  - How to monitor route health
  - Troubleshooting guide
- [ ] Architecture guide (docs/ARCHITECTURE.md)
  - Component interactions
  - Data flow diagrams
  - Storage schema
- [ ] API reference (docs/API_REFERENCE.md)
  - All CLI commands
  - Python SDK (if exposed)
- [ ] Example workflows (docs/EXAMPLES.md)
  - Document review (static)
  - Loan approval (dynamic)
  - Data validation (sequential + error recovery)
- [ ] Video walkthrough (optional)
  - 5-minute demo of creating a route
  - 5-minute demo of invoking a workflow

**Tasks:**
- Write CSA user guide
- Create architecture diagrams (Mermaid)
- Write API reference
- Collect example routes
- Record demo video
- Review docs with CSA team

**Definition of Done:**
- CSA guide is complete and clear
- All components documented
- Examples are runnable
- Docs are reviewed by CSA team

---

## Phase 6: Reference Recipes (Weeks 8–9)

**Goal:** CSAs have copy-paste-ready route examples.

### Sprint 6.1: Pre-built Routes (Week 8)

**Deliverables:**
- [ ] Recipe 1: Document Review (Static)
  - Agents: DocumentExtractor, ReviewerA, ReviewerB, Aggregator
  - Pattern: fan-out-fan-in
  - Route code at: `recipes/document-review/v1.0.py`
  - Test data: `recipes/document-review/test-input.json`
  - Workflow: `recipes/document-review/workflow.yaml`
- [ ] Recipe 2: Loan Approval (Dynamic)
  - Agents: LoanExtractor, MortgageAnalyst, AutoAnalyst, GeneralAnalyst, Aggregator
  - Decision: loan_type (mortgage, auto, general)
  - Route code at: `recipes/loan-approval/v1.0.py`
  - Test data: `recipes/loan-approval/test-inputs/`
  - Workflow: `recipes/loan-approval/workflow.yaml`
- [ ] Recipe 3: Data Validation (Sequential + Error Recovery)
  - Agents: InputValidator, DataProcessor, OutputValidator
  - Pattern: Sequential with retry on failure
  - Route code: `recipes/data-validation/v1.0.py`

**Tasks:**
- Design 3 representative recipes
- Implement agents for each recipe
- Create route code and workflows
- Create test data (happy path + error cases)
- Write runbook for each recipe
- Test end-to-end

**Definition of Done:**
- 3 recipes are complete
- All recipes pass test suite
- Test data covers happy path + edge cases
- Runbooks are clear

### Sprint 6.2: Runbooks & Documentation (Week 9)

**Deliverables:**
- [ ] Runbook for each recipe
  - Setup instructions
  - How to customize for your use case
  - Expected outputs
  - Troubleshooting
- [ ] Video walkthrough for each recipe
- [ ] Recipe registry (searchable index)
  ```json
  {
    "recipes": [
      {
        "id": "document-review-static",
        "name": "Document Review",
        "pattern": "fan-out-fan-in",
        "agents": ["DocumentExtractor", "ReviewerA", "ReviewerB", "Aggregator"],
        "difficulty": "beginner",
        "use_cases": ["compliance review", "editorial review"],
        "location": "recipes/document-review/"
      }
    ]
  }
  ```

**Tasks:**
- Write runbooks for each recipe
- Record demo videos
- Create recipe registry
- Test setup instructions with fresh user
- Gather feedback

**Definition of Done:**
- Runbooks are clear and tested
- Videos are recorded and public
- Recipe registry is searchable
- CSA can follow instructions without help

---

## Phase 7: Testing & Hardening (Weeks 9–10)

**Goal:** Production-ready reliability and performance.

### Sprint 7.1: Integration Tests (Week 9)

**Deliverables:**
- [ ] End-to-end tests
  - Route Writer interview → code generation → execution → health tracking
  - Workflow creation → invocation → result
  - Health monitoring → flag auto-set → admin notification
- [ ] Test fixtures
  - Mock agents (fast, deterministic)
  - Sample routes (static, dynamic, error cases)
  - Test data (varied input types)
- [ ] Performance tests
  - Route creation (should be <5 seconds)
  - Route execution (p95 latency target)
  - Health queries (should be fast, <100ms)

**Tasks:**
- Write comprehensive integration tests
- Create mock agents & test fixtures
- Benchmark performance
- Optimize slow paths
- Add load testing (1000+ routes, high throughput)

**Definition of Done:**
- >80% code coverage for core paths
- All integration tests pass
- Performance targets met (latency, throughput)
- Load test shows acceptable degradation

### Sprint 7.2: Security & Edge Cases (Week 10)

**Deliverables:**
- [ ] Security tests
  - Code injection in route code (try to break out of sandbox)
  - Agent name injection (try to invoke unauthorized agents)
  - Auth bypass attempts
- [ ] Edge case tests
  - Empty input
  - Missing agents
  - Timeout handling
  - Large inputs (memory limits)
  - Concurrent invocations (race conditions)
- [ ] Error recovery tests
  - Network failures (Foundry, Agent 365)
  - Agent crashes mid-execution
  - OOM, timeout scenarios

**Tasks:**
- Design security test cases
- Implement fuzz testing (random inputs)
- Test error scenarios (simulated failures)
- Add resilience (retries, fallbacks)
- Document known limitations

**Definition of Done:**
- Security tests pass
- All edge cases handled gracefully
- Error messages are helpful
- No data loss or crashes

---

## Phase 8: Monitoring Agent (Weeks 10–11)

**Goal:** Routes auto-recover and escalate issues to CSAs.

### Sprint 8.1: Health Monitoring & Auto-Recovery (Week 10)

**Deliverables:**
- [ ] RouteHealthMonitor agent
  - Runs as background job (scheduled)
  - Detects routes with warn-* flags
  - Takes action (notify, rollback, escalate)
  ```python
  @workflow
  async def route_health_monitor(kernel: Kernel):
      health_registry = kernel.get_service("RouteHealthRegistry")
      
      routes_with_warnings = await health_registry.query_all_with_flags()
      
      for route in routes_with_warnings:
          if "warn-failing" in route.status_flags:
              # Analyze failures
              analyzer = kernel.get_agent("RouteAnalyzer")
              analysis = await analyzer.invoke({...})
              
              # Maybe rollback
              if analysis.recommend_rollback:
                  previous = await foundry.get_previous_version(route.id)
                  await promote_version(route.id, previous)
  ```
- [ ] RouteRecoveryAgent
  - Checks if offline routes are back online
  - Automatically unblocks recovered routes
  - Notifies CSA on recovery
- [ ] Notification system
  - Slack integration
  - Email integration
  - In-app notifications

**Tasks:**
- Implement monitoring agent
- Implement recovery logic
- Add Slack/email notifications
- Test scenarios (failure → recovery)
- Create monitoring dashboards (optional)

**Definition of Done:**
- Monitoring agent runs and detects issues
- Auto-rollback works
- Notifications are sent
- Recovery agent brings routes back online

### Sprint 8.2: Escalation & CSA Engagement (Week 11)

**Deliverables:**
- [ ] Escalation policy
  - Severity levels (low, medium, high)
  - Escalation criteria (repeated failures, cost explosion)
  - Escalation targets (CSA team, on-call, manager)
- [ ] Incident creation
  - Auto-create ticket in incident system (e.g., Azure DevOps, Jira)
  - Include route diagnostics (failure logs, metrics)
  - Link to route in Agent 365
- [ ] CSA handoff
  - Clear action items
  - Suggested fixes
  - Links to runbooks

**Tasks:**
- Design escalation policy
- Integrate with incident system
- Create diagnostic reports
- Write escalation templates
- Test end-to-end escalation

**Definition of Done:**
- Escalations create tickets automatically
- Tickets include clear diagnostics
- CSA can act on ticket immediately

---

## Phase 9: Release & Handoff (Weeks 11–12)

**Goal:** SAFE is production-ready and CSAs are trained.

### Sprint 9.1: Release Preparation (Week 11)

**Deliverables:**
- [ ] Release notes
  - Features
  - Known issues
  - Upgrade guide
- [ ] Deployment playbook
  - How to deploy SAFE to production
  - Configuration checklist
  - Rollback procedures
- [ ] Monitoring setup
  - Dashboard for SAFE health (routes, executions, errors)
  - Alerts for SAFE itself (not just routes)
- [ ] Documentation freeze
  - All docs final
  - Spelling/grammar check
  - Links verified

**Tasks:**
- Write release notes
- Create deployment guide
- Setup monitoring for SAFE itself
- Review all documentation
- Create launch checklist

**Definition of Done:**
- Release notes are complete
- Deployment guide is tested
- Monitoring is configured
- All documentation is reviewed

### Sprint 9.2: CSA Onboarding & Training (Week 12)

**Deliverables:**
- [ ] CSA training session (2 hours)
  - Live demo of route creation (static + dynamic)
  - Live demo of workflow invocation
  - Q&A and troubleshooting
- [ ] CSA handbook (printed or PDF)
  - Quick reference guide
  - Common workflows
  - Troubleshooting tips
- [ ] First engagement support
  - CSA team has access to dev team for questions
  - Daily standup for first week of production use
  - Runbook reviews before first CSA route

**Tasks:**
- Prepare training materials
- Run training session
- Gather feedback
- Create handbook
- Plan first week support

**Definition of Done:**
- CSAs trained and confident
- Handbook distributed
- Support plan in place
- Go-live approved

---

## Success Criteria & Milestones

### Critical Milestones (Must-Have)

| Milestone | Target Week | Criteria |
|-----------|-------------|----------|
| **MVP 1: Route Writer** | Week 4 | `/route create` generates valid Python code |
| **MVP 2: Health Tracking** | Week 5 | Routes track execution metrics, auto-set flags |
| **MVP 3: Agent 365** | Week 6 | Routes visible in Agent 365, admins can block |
| **MVP 4: Workflow Invocation** | Week 7 | `/workflow invoke` works end-to-end |
| **MVP 5: CSA Ready** | Week 8 | CSAs can use SAFE without dev help |
| **Release** | Week 12 | CSAs deployed first production route |

### Success Metrics

| Metric | Target |
|--------|--------|
| Route creation time | <15 min |
| Route success rate (first execution) | >95% |
| P95 latency | <60 seconds |
| Code generation accuracy | 100% (valid Python) |
| CSA onboarding time | <1 hour |
| Documentation completeness | 100% of commands/features |

---

## Risk Mitigation

| Risk | Impact | Mitigation |
|------|--------|-----------|
| **Foundry API changes** | High | Pin SDK version; have fallback REST client |
| **Agent 365 delays** | Medium | Mock Agent 365 in MVP; integrate later |
| **Route execution timeouts** | Medium | Implement configurable timeouts; auto-retry |
| **SK Memory limitations** | Medium | Start with SK; plan CosmosDB migration |
| **Code injection attacks** | High | Use `compile()` only; no `eval()`. Sandbox code in container |
| **CSA adoption resistance** | Medium | Involve CSAs early; iterate on feedback |

---

## Team Roles & Responsibilities

| Role | Responsibility | Hours/Week |
|------|---|---|
| **Tech Lead** | Architecture, code review, Foundry/Agent 365 integration | 40 |
| **Engineer 1** | Route Writer Agent, code generation | 40 |
| **Engineer 2** | Health Registry, CLI, testing | 40 |
| **CSA (Validation)** | Requirements, testing, training | 10–20 |

---

## Dependencies & Blockers

### Hard Dependencies
- Foundry SDK (Python) — Required for catalog integration
- Agent Framework (MAF) — Required for agent execution
- Semantic Kernel (SK) — Required for memory & plugins
- Agent 365 API — Required for governance (can mock initially)

### Soft Dependencies
- OTel collector (local) — For development; optional for MVP
- Docker — For local testing; optional

### Known Blockers
- None identified yet; will update as project progresses

---

## Communication & Standup

**Daily Standup:** 15 min at 10 AM  
- What did I complete?
- What am I blocked on?
- What's next?

**Weekly Sync:** 1 hour every Friday  
- Phase progress
- Blockers & risks
- CSA feedback (if available)
- Next week plan

**CSA Sync:** Every 2 weeks (starting Phase 3)  
- Demo of latest features
- Feedback on UX/docs
- Requirements clarification

---

## Sign-Off & Approval

| Role | Name | Date | Status |
|------|------|------|--------|
| Tech Lead | [Name] | | [ ] |
| PM | [Name] | | [ ] |
| CSA Lead | [Name] | | [ ] |

---

**Document Version:** 1.0  
**Last Updated:** [DATE]  
**Next Review:** [DATE + 4 weeks]
