# SAFE Framework — Agent Template Architecture

**Status:** Complete Design + Implementation  
**Version:** 1.0  
**Date:** 2026-06-20

---

## Overview

A comprehensive agent templating system that enables CSAs and engineers to:
- Discover pre-built agents from a curated catalog
- Select agent templates for pattern placeholders
- Copy templates into projects and customize
- Reuse battle-tested agent implementations
- Maintain consistency across routes

---

## 1. Agent Contract Schema

### 1.1 Contract Specification

Every agent must define its **contract** — what it accepts and what it returns.

```yaml
# templates/agents/standalone/loan-supervisor/agent.yaml

name: Loan Supervisor
version: 1.0
category: decision-maker
description: |
  Routes loan applications to appropriate analysis teams
  based on loan type, amount, and applicant risk profile.

# Agent Contract (REQUIRED)
contract:
  
  # Input schema
  inputs:
    - name: application
      type: object
      required: true
      description: Loan application data
      schema:
        type: object
        required_fields:
          - loan_type
          - amount
          - credit_score
          - employment_status
        field_definitions:
          loan_type:
            type: string
            enum: [mortgage, auto, personal]
            description: Type of loan
          amount:
            type: number
            minimum: 1000
            maximum: 5000000
            description: Loan amount in USD
          credit_score:
            type: integer
            minimum: 300
            maximum: 850
            description: FICO credit score
          employment_status:
            type: string
            enum: [employed, self-employed, retired, unemployed]
  
  # Output schema
  outputs:
    - name: routing_decision
      type: object
      required: true
      description: Routing decision from supervisor
      schema:
        type: object
        required_fields:
          - decision
          - branch_id
          - confidence
        field_definitions:
          decision:
            type: string
            enum: [mortgage, auto, personal, rejected]
            description: Routing decision
          branch_id:
            type: string
            description: Identifier for routing branch
          confidence:
            type: number
            minimum: 0.0
            maximum: 1.0
            description: Confidence in decision (0-1)
          reasoning:
            type: string
            description: Explanation of decision

# Metadata
metadata:
  author: SAFE Team
  source:
    repository: internal
    license: MIT
  dependencies: []
  requirements:
    python: ">=3.11"
    packages:
      - anthropic >= 0.20.0
      - pydantic >= 2.0.0
  timeout_seconds: 60
  
# Documentation
documentation:
  use_cases:
    - Intelligent loan application routing
    - Multi-tier approval decisions
    - Risk-based workflow assignment
  
  example:
    input:
      application:
        loan_type: mortgage
        amount: 350000
        credit_score: 780
        employment_status: employed
    
    output:
      routing_decision:
        decision: mortgage
        branch_id: mortgage-standard
        confidence: 0.95
        reasoning: "High credit score and standard mortgage amount routes to standard approval path"
  
  limitations:
    - Requires structured input (not freeform text)
    - Limited to loan domain
    - May need updates as lending rules change
  
  related_agents:
    - mortgage-specialist
    - compliance-reviewer
    - auto-loan-specialist

# Tags for discovery
tags:
  - routing
  - decision-making
  - lending
  - supervisor
  - loan-origination

# Pattern assignments (where this agent fits)
pattern_roles:
  - pattern: supervisor-manager
    placeholder: supervisor
    description: Acts as supervisor making routing decisions
```

### 1.2 Contract Validation Rules

```python
# safe_core/agent_validation.py

from typing import Any, Dict
from pydantic import BaseModel, ValidationError

class ContractValidator:
    """Validates agent contracts against pattern requirements."""
    
    def validate_agent_for_pattern(
        self,
        agent_contract: Dict[str, Any],
        pattern_placeholder: str,
        pattern_id: str
    ) -> Dict[str, Any]:
        """
        Validate agent can be used for pattern placeholder.
        
        Returns: {valid: bool, errors: [str], warnings: [str]}
        """
        errors = []
        warnings = []
        
        # Load pattern requirements
        pattern = PATTERN_REGISTRY.get_pattern(pattern_id)
        placeholder = next(
            (p for p in pattern.placeholders if p.id == pattern_placeholder),
            None
        )
        
        if not placeholder:
            errors.append(f"Pattern {pattern_id} has no placeholder {pattern_placeholder}")
            return {"valid": False, "errors": errors, "warnings": warnings}
        
        # Check outputs match pattern expectation
        agent_outputs = {o["name"]: o["schema"] for o in agent_contract["outputs"]}
        
        # Verify all required outputs present
        required_outputs = placeholder.required_outputs or []
        for required in required_outputs:
            if required not in agent_outputs:
                errors.append(
                    f"Agent missing required output '{required}' "
                    f"for pattern placeholder '{pattern_placeholder}'"
                )
        
        # Check timeout is reasonable
        timeout = agent_contract.get("metadata", {}).get("timeout_seconds", 60)
        if timeout > 300:
            warnings.append(f"Agent timeout {timeout}s is very long")
        
        # Check dependencies
        dependencies = agent_contract.get("metadata", {}).get("dependencies", [])
        if len(dependencies) > 5:
            warnings.append("Agent has many dependencies, may be fragile")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "agent_outputs": agent_outputs,
            "required_outputs": required_outputs
        }
```

---

## 2. Directory Structure

### 2.1 Template Folder Organization

```
safe_phase1/
└── templates/
    └── agents/
        ├── CATALOG.yaml                    # Registry of all agents
        ├── standalone/                     # Standalone agents
        │   ├── document-writer/
        │   │   ├── agent.yaml              # Contract + metadata
        │   │   ├── agent.md                # Documentation
        │   │   ├── prompt.txt              # Claude system prompt
        │   │   ├── scripts/
        │   │   │   └── formatter.py
        │   │   └── requirements.txt
        │   ├── rag-query/
        │   │   ├── agent.yaml
        │   │   ├── agent.md
        │   │   ├── prompt.txt
        │   │   └── requirements.txt
        │   ├── reviewer/
        │   ├── summarizer/
        │   ├── semantic-search/
        │   ├── web-query/
        │   ├── presenter-word/
        │   ├── presenter-html/
        │   ├── presenter-markdown/
        │   ├── researcher/
        │   └── empty-agent/
        │
        └── patterns/                       # Pattern-specific agents
            ├── supervisor-manager/
            │   ├── supervisor/
            │   │   ├── agent.yaml
            │   │   ├── agent.md
            │   │   ├── prompt.txt
            │   │   └── requirements.txt
            │   ├── aggregator/
            │   │   ├── agent.yaml
            │   │   └── ...
            │   └── ...
            │
            ├── fan-out-fan-in/
            │   ├── processor/
            │   ├── worker/
            │   └── aggregator/
            │
            ├── map-reduce/
            │   ├── splitter/
            │   ├── mapper/
            │   ├── shuffle/
            │   ├── reducer/
            │   └── final/
            │
            └── ...
```

### 2.2 Benefits of This Structure

✅ **Clear organization** — Find agents by category  
✅ **Scalable** — Easy to add 50+ agents  
✅ **Self-documenting** — Folder names are clear  
✅ **Tool-friendly** — Walk directories programmatically  
✅ **Pattern alignment** — Pattern agents clearly linked  
✅ **No long filenames** — Readable directory paths

---

## 3. Agent Catalog Registry

### 3.1 CATALOG.yaml Structure

```yaml
# templates/agents/CATALOG.yaml

version: 1.0
last_updated: 2026-06-20
metadata:
  total_agents: 45
  categories: 8
  patterns_covered: 12

# Standalone agents
standalone:
  
  - id: document-writer
    name: Document Writer
    version: 1.0
    description: Generates formatted Word documents from structured data
    category: generation
    tags: [document, word, export, formatting]
    
    contract:
      inputs: [data_object]
      outputs: [document_bytes]
    
    use_cases:
      - "Creating client reports"
      - "Generating contracts"
      - "Building templates"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: []
      requirements: [python-docx, pandas]
      timeout_seconds: 120
    
    discovery:
      keywords: [document, word, report, formatting]
      complexity: intermediate
      quality_rating: 4.8
      usage_count: 127
  
  - id: rag-query
    name: RAG Query Agent
    version: 1.2
    description: Vector-based retrieval-augmented generation for Q&A
    category: retrieval
    tags: [rag, search, knowledge-base, retrieval]
    
    contract:
      inputs: [query, documents]
      outputs: [answer, sources]
    
    use_cases:
      - "Knowledge base Q&A"
      - "Document-grounded search"
      - "FAQ systems"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: [pinecone, langchain]
      requirements: [langchain, pinecone-client]
      timeout_seconds: 60
    
    discovery:
      keywords: [rag, search, vector, knowledge]
      complexity: advanced
      quality_rating: 4.9
      usage_count: 342
  
  - id: reviewer
    name: Document Reviewer
    version: 1.1
    description: Reviews documents for quality, accuracy, and compliance
    category: review
    tags: [review, quality, compliance, validation]
    
    contract:
      inputs: [document]
      outputs: [review_result]
    
    use_cases:
      - "Quality assurance"
      - "Compliance checking"
      - "Content review"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: []
      timeout_seconds: 90
    
    discovery:
      keywords: [review, quality, compliance]
      complexity: intermediate
      quality_rating: 4.7
      usage_count: 98
  
  - id: summarizer
    name: Text Summarizer
    version: 1.0
    description: Generates concise summaries from long documents
    category: transformation
    tags: [summarization, condensing, overview]
    
    contract:
      inputs: [text]
      outputs: [summary]
    
    use_cases:
      - "Meeting note summarization"
      - "Document condensation"
      - "Report generation"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: []
      timeout_seconds: 60
    
    discovery:
      keywords: [summary, summarize, condense]
      complexity: simple
      quality_rating: 4.6
      usage_count: 156
  
  - id: semantic-search
    name: Semantic Search Agent
    version: 1.0
    description: Semantic similarity search across documents
    category: retrieval
    tags: [search, semantic, similarity, matching]
    
    contract:
      inputs: [query, documents]
      outputs: [matches]
    
    use_cases:
      - "Document similarity"
      - "Relevance ranking"
      - "Content matching"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: [sentence-transformers]
      timeout_seconds: 45
    
    discovery:
      keywords: [semantic, search, similarity]
      complexity: intermediate
      quality_rating: 4.8
      usage_count: 203
  
  - id: researcher
    name: Research Agent
    version: 1.0
    description: Multi-step research and synthesis agent
    category: research
    tags: [research, investigation, synthesis]
    
    contract:
      inputs: [topic, sources]
      outputs: [research_report]
    
    use_cases:
      - "Market research"
      - "Competitive analysis"
      - "Trend analysis"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: []
      timeout_seconds: 180
    
    discovery:
      keywords: [research, investigation, analysis]
      complexity: advanced
      quality_rating: 4.9
      usage_count: 87
  
  - id: presenter-word
    name: Word Document Presenter
    version: 1.0
    description: Formats analysis results into Word documents
    category: presentation
    tags: [presentation, word, formatting, export]
    
    contract:
      inputs: [content, template]
      outputs: [docx_file]
    
    use_cases:
      - "Report generation"
      - "Executive summaries"
      - "Formal documents"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: [python-docx]
      timeout_seconds: 60
    
    discovery:
      keywords: [word, document, presentation, export]
      complexity: intermediate
      quality_rating: 4.7
      usage_count: 134
  
  - id: presenter-html
    name: HTML Presenter
    version: 1.0
    description: Generates HTML presentations and dashboards
    category: presentation
    tags: [presentation, html, web, dashboard]
    
    contract:
      inputs: [data, template]
      outputs: [html_string]
    
    use_cases:
      - "Web dashboards"
      - "Interactive reports"
      - "Presentations"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: [jinja2]
      timeout_seconds: 45
    
    discovery:
      keywords: [html, web, presentation, dashboard]
      complexity: intermediate
      quality_rating: 4.8
      usage_count: 167
  
  - id: presenter-markdown
    name: Markdown Presenter
    version: 1.0
    description: Formats output as readable Markdown
    category: presentation
    tags: [presentation, markdown, text, documentation]
    
    contract:
      inputs: [data]
      outputs: [markdown_string]
    
    use_cases:
      - "Documentation"
      - "Readme generation"
      - "Text reports"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: []
      timeout_seconds: 30
    
    discovery:
      keywords: [markdown, text, documentation]
      complexity: simple
      quality_rating: 4.9
      usage_count: 234
  
  - id: presenter-code
    name: Code Presenter
    version: 1.0
    description: Generates formatted code with explanations
    category: presentation
    tags: [presentation, code, programming]
    
    contract:
      inputs: [code_spec]
      outputs: [code_with_comments]
    
    use_cases:
      - "Code generation"
      - "Documentation"
      - "Educational content"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: [pygments]
      timeout_seconds: 60
    
    discovery:
      keywords: [code, programming, generation]
      complexity: intermediate
      quality_rating: 4.8
      usage_count: 145
  
  - id: empty-agent
    name: Empty Agent Template
    version: 1.0
    description: Blank template for creating custom agents from scratch
    category: template
    tags: [template, blank, custom]
    
    contract:
      inputs: []
      outputs: []
    
    use_cases:
      - "Creating custom agents"
      - "Learning SAFE agent structure"
      - "Prototyping"
    
    metadata:
      author: SAFE Team
      license: MIT
      dependencies: []
      timeout_seconds: 30
    
    discovery:
      keywords: [template, blank, custom, empty]
      complexity: simple
      quality_rating: 5.0
      usage_count: 456

# Pattern-specific agents
patterns:
  
  supervisor-manager:
    - id: supervisor-manager_supervisor
      placeholder: supervisor
      name: Supervisor Router
      version: 1.0
      description: Routes based on input analysis
      category: routing
      tags: [routing, decision, supervisor]
      
      contract:
        inputs: [application]
        outputs: [routing_decision]
      
      metadata:
        author: SAFE Team
        license: MIT
        timeout_seconds: 60
      
      discovery:
        keywords: [supervisor, router, decision]
        quality_rating: 4.9
        usage_count: 178
    
    - id: supervisor-manager_aggregator
      placeholder: aggregator
      name: Decision Aggregator
      version: 1.0
      description: Combines results from multiple agents
      category: aggregation
      tags: [aggregation, combination, decision]
      
      contract:
        inputs: [agent_results]
        outputs: [final_decision]
      
      metadata:
        author: SAFE Team
        license: MIT
        timeout_seconds: 45
      
      discovery:
        keywords: [aggregator, combine, decision]
        quality_rating: 4.8
        usage_count: 156
  
  fan-out-fan-in:
    - id: fan-out-fan-in_processor
      placeholder: processor
      name: Fan-Out Processor
      version: 1.0
      description: Preprocesses input for parallel workers
      category: processing
      tags: [preprocessing, fan-out, processing]
      
      contract:
        inputs: [data]
        outputs: [processed_data]
      
      metadata:
        author: SAFE Team
        license: MIT
        timeout_seconds: 30
      
      discovery:
        keywords: [processor, preprocessing, fan-out]
        quality_rating: 4.7
        usage_count: 123
    
    - id: fan-out-fan-in_worker
      placeholder: worker
      name: Fan-Out Worker
      version: 1.0
      description: Processes portion of data in parallel
      category: processing
      tags: [parallel, worker, processing]
      
      contract:
        inputs: [data_chunk]
        outputs: [result]
      
      metadata:
        author: SAFE Team
        license: MIT
        timeout_seconds: 60
      
      discovery:
        keywords: [worker, parallel, processing]
        quality_rating: 4.9
        usage_count: 234
    
    - id: fan-out-fan-in_aggregator
      placeholder: aggregator
      name: Fan-In Aggregator
      version: 1.0
      description: Aggregates results from parallel workers
      category: aggregation
      tags: [aggregation, fan-in, combining]
      
      contract:
        inputs: [worker_results]
        outputs: [combined_result]
      
      metadata:
        author: SAFE Team
        license: MIT
        timeout_seconds: 45
      
      discovery:
        keywords: [aggregator, fan-in, combine]
        quality_rating: 4.8
        usage_count: 201
```

---

## 4. Sample Agent Templates

### 4.1 Standalone: Document Writer

```yaml
# templates/agents/standalone/document-writer/agent.yaml

name: Document Writer
version: 1.0
description: Generates formatted Word documents from structured data

contract:
  inputs:
    - name: data
      type: object
      required: true
      description: Data to include in document
      schema:
        type: object
        required_fields: [title, sections]
        field_definitions:
          title:
            type: string
            description: Document title
          sections:
            type: array
            items:
              type: object
              required_fields: [heading, content]
  
  outputs:
    - name: document
      type: bytes
      required: true
      description: Generated .docx file
      schema:
        type: object
        required_fields: [filename, content, size]

metadata:
  author: SAFE Team
  source:
    repository: internal
    license: MIT
  dependencies: []
  requirements:
    python: ">=3.11"
    packages:
      - python-docx >= 0.8.10
      - pandas >= 1.0
  timeout_seconds: 120

documentation:
  use_cases:
    - "Creating client reports"
    - "Generating contracts"
    - "Building templates"
  
  example:
    input:
      data:
        title: "Quarterly Report"
        sections:
          - heading: "Executive Summary"
            content: "Key findings and recommendations..."
          - heading: "Detailed Analysis"
            content: "Comprehensive breakdown..."
    
    output:
      document:
        filename: "Quarterly_Report.docx"
        size: 45621

tags: [document, word, export, formatting, generation]

pattern_roles:
  - pattern: sequential-pipeline
    placeholder: presenter
```

### 4.2 Pattern-Specific: Supervisor Agent

```yaml
# templates/agents/patterns/supervisor-manager/supervisor/agent.yaml

name: Supervisor Router
version: 1.0
description: Routes loan applications to appropriate analysis teams

contract:
  inputs:
    - name: application
      type: object
      required: true
      description: Loan application data
      schema:
        type: object
        required_fields: [loan_type, amount, credit_score]
        field_definitions:
          loan_type:
            type: string
            enum: [mortgage, auto, personal]
          amount:
            type: number
            minimum: 1000
          credit_score:
            type: integer
            minimum: 300
            maximum: 850
  
  outputs:
    - name: routing_decision
      type: object
      required: true
      description: Routing decision
      schema:
        type: object
        required_fields: [decision, branch_id, confidence]
        field_definitions:
          decision:
            type: string
            enum: [mortgage, auto, personal, rejected]
          branch_id:
            type: string
          confidence:
            type: number
            minimum: 0.0
            maximum: 1.0

metadata:
  author: SAFE Team
  source:
    repository: internal
    license: MIT
  dependencies: []
  timeout_seconds: 60

pattern_assignment:
  pattern: supervisor-manager
  placeholder: supervisor
  description: Routes loan applications intelligently
```

### 4.3 Empty Agent Template

```yaml
# templates/agents/standalone/empty-agent/agent.yaml

name: Your Agent Name
version: 1.0
description: |
  [Describe what this agent does]

contract:
  
  inputs:
    - name: input_name
      type: object  # or: string, number, array, bytes
      required: true
      description: "[Input description]"
      schema:
        type: object
        required_fields: [field1, field2]
        field_definitions:
          field1:
            type: string
            description: "Field description"
  
  outputs:
    - name: output_name
      type: object  # or: string, number, array, bytes
      required: true
      description: "[Output description]"
      schema:
        type: object
        required_fields: [result_field]

metadata:
  author: "[Your name]"
  source:
    repository: internal
    license: MIT
  dependencies: []
  requirements:
    python: ">=3.11"
    packages: []
  timeout_seconds: 60

documentation:
  use_cases:
    - "Use case 1"
    - "Use case 2"
  
  example:
    input: {}
    output: {}
  
  limitations:
    - "Limitation 1"

tags: [tag1, tag2]

pattern_roles: []
```

---

## 5. CLI Integration

### 5.1 New Commands

```bash
# List all agents
python -m safe_cli.cli list-agents
python -m safe_cli.cli list-agents --category generation
python -m safe_cli.cli list-agents --pattern supervisor-manager

# Show agent details
python -m safe_cli.cli show-agent document-writer

# Create agent from template
python -m safe_cli.cli create-agent --from-template

# Search agents
python -m safe_cli.cli search-agents document
```

### 5.2 Interactive Flows

```
$ python -m safe_cli.cli create-route --use-pattern

Pattern: Supervisor/Manager

"Pick Supervisor agent:"
┌─ Standalone agents (35)
│  ├─ Loan Supervisor (pattern default) ⭐
│  ├─ ML Router
│  ├─ Smart Router
│  └─ [Create new from template]
│
└─ Pattern agents (8)
   ├─ Supervisor Router (recommended)
   └─ General Supervisor

→ Select: Supervisor Router

✅ Agent copied to: projects/agents/supervisor-router/
   Edit at: projects/agents/supervisor-router/agent.yaml

Next: Pick Aggregator agent...
```

---

## 6. Agent Provisioning Workflow

### 6.1 Copy Agent to Project

```
When user selects agent template:

1. Validate contract
   └─ Check compatible with pattern placeholder

2. Copy files
   ├─ agent.yaml → projects/agents/{agent-name}/
   ├─ agent.md → projects/agents/{agent-name}/
   ├─ prompt.txt → projects/agents/{agent-name}/
   ├─ scripts/ → projects/agents/{agent-name}/
   └─ requirements.txt → projects/agents/{agent-name}/

3. Create metadata
   └─ .agent-metadata.yml
      ├─ source_template: templates/agents/...
      ├─ source_version: 1.0
      ├─ copied_date: 2026-06-20
      ├─ customized: false
      └─ last_updated_from_source: 2026-06-20

4. Install requirements
   └─ pip install -r projects/agents/{agent-name}/requirements.txt

5. Show usage
   └─ "Agent ready at: projects/agents/{agent-name}/"
   └─ "Edit: projects/agents/{agent-name}/agent.yaml"
   └─ "Run: python -m agents.{agent-name} --test"
```

### 6.2 Metadata File

```yaml
# projects/agents/document-writer/.agent-metadata.yml

source_template: templates/agents/standalone/document-writer
source_version: 1.0
source_template_version: 1.0

copied_date: 2026-06-20T10:30:00Z
copied_by: alice@company.com

customized: false
customization_notes: []

history:
  - date: 2026-06-20
    action: initial_copy
    version: 1.0
    notes: "Initial agent creation from template"

# For pattern agents
pattern_assignment:
  pattern: supervisor-manager
  placeholder: supervisor
  assigned_date: 2026-06-20

# Template update tracking
template_tracking:
  last_checked: 2026-06-20
  latest_version: 1.0
  has_updates: false
  breaking_changes: false
```

---

## 7. Agent Quality & Discovery

### 7.1 Quality Metrics

```yaml
discovery:
  complexity:
    - simple       # Single prompt, no dependencies
    - intermediate # Multiple steps, some dependencies
    - advanced     # Complex logic, many dependencies
  
  quality_rating: 4.8  # 1-5 stars, from community usage
  
  usage_count: 127     # How many routes use this agent
  
  maintenance:
    last_updated: 2026-06-20
    maintained_by: SAFE Team
    support_level: production
  
  keywords:
    - document
    - word
    - export
    - formatting
```

### 7.2 Search & Filtering

```python
# safe_core/agent_discovery.py

class AgentDiscovery:
    """Find agents by keyword, use case, or pattern."""
    
    def search_agents(self, query: str) -> List[Agent]:
        """Search by keyword."""
        # Match against: name, description, tags, use_cases
        pass
    
    def filter_agents(self, 
                     category: str = None,
                     pattern: str = None,
                     complexity: str = None,
                     min_rating: float = None) -> List[Agent]:
        """Filter by metadata."""
        pass
    
    def suggest_agents(self, pattern_id: str, 
                      placeholder_id: str) -> List[Agent]:
        """Recommend agents for pattern placeholder."""
        # Return pattern-specific agents first
        # Then standalone agents with matching outputs
        pass
    
    def get_agent_stats(self) -> Dict:
        """Overall agent catalog stats."""
        return {
            "total_agents": 45,
            "by_category": {...},
            "most_used": [...],
            "newest": [...]
        }
```

---

## 8. GitHub Source Management

### 8.1 Agent Attribution

```yaml
source:
  repository: https://github.com/awesome-agents/document-writer
  license: MIT
  author: John Doe
  contact: john@example.com
  
  # Original source
  original_url: https://github.com/awesome-agents/document-writer/blob/main/agent.yaml
  
  # SAFE additions/modifications
  safe_modifications: |
    - Adapted to SAFE contract specification
    - Added OpenTelemetry tracing
    - Integrated with Agent Framework
  
  # Versioning
  source_version: 1.0.0
  safe_version: 1.0
  
  # License details
  license_text: "[MIT license text]"
  attribution: "Based on work by John Doe, adapted by SAFE Team"
```

### 8.2 Agent Sourcing Process

```
Sourcing workflow:

1. Identify agents in awesome-repos
   └─ awesome-agents
   └─ awesome-llms
   └─ awesome-ai
   └─ Papers with code

2. Vet agent quality
   ├─ Read documentation
   ├─ Check code quality
   ├─ Verify license
   └─ Test functionality

3. Adapt to SAFE
   ├─ Define contract (inputs/outputs)
   ├─ Add to catalog
   ├─ Create SAFE wrapper
   └─ Add attribution

4. Test integration
   ├─ Run with SAFE framework
   ├─ Validate contract
   └─ Check performance

5. Add to templates
   └─ Deploy to templates/ folder
   └─ Update CATALOG.yaml
   └─ Document limitations
```

---

## 9. Agent Documentation Template

### 9.1 Markdown Documentation

```markdown
# Document Writer Agent

## Overview
Generates formatted Word documents from structured data.

## Contract

### Inputs
- **data** (object)
  - title (string): Document title
  - sections (array): Document sections

### Outputs
- **document** (bytes): Generated .docx file

## Usage

### Basic Example
\`\`\`python
from agents.document_writer import DocumentWriter

agent = DocumentWriter()
result = await agent.invoke({
    "data": {
        "title": "My Report",
        "sections": [
            {"heading": "Summary", "content": "..."}
        ]
    }
})
\`\`\`

## Use Cases
- Creating client reports
- Generating contracts
- Building templates

## Configuration
- Timeout: 120 seconds
- Concurrency: 1 (sequential only)

## Dependencies
- python-docx >= 0.8.10
- pandas >= 1.0

## Limitations
- Requires structured input
- Limited to Word format
- 50MB file size limit

## Source
- Original: https://github.com/awesome-agents/document-writer
- License: MIT
- Author: John Doe
- SAFE Version: 1.0
```

---

## 10. Best Practices

### 10.1 Creating New Agents

1. **Start with empty template**
   ```bash
   python -m safe_cli.cli create-agent --from-template empty-agent
   ```

2. **Define contract first**
   ```yaml
   contract:
     inputs: [...]
     outputs: [...]
   ```

3. **Write documentation**
   ```markdown
   # My Agent
   ... detailed docs
   ```

4. **Implement and test**
   ```bash
   pytest agents/my-agent/tests/
   ```

5. **Validate contract**
   ```bash
   python -m safe_cli.cli validate-agent agents/my-agent/
   ```

### 10.2 Customizing Templates

```yaml
# When you customize a template agent:

1. Agent is copied to projects/agents/
2. Edit projects/agents/{agent-name}/agent.yaml
3. .agent-metadata.yml tracks customization
4. Changes isolated to this project
5. Original template remains unchanged

# To update from newer template version:
python -m safe_cli.cli update-agent --from-template --diff
# Shows what changed, user can merge changes
```

### 10.3 Contract Validation

```python
# Always validate agents before using in routes

from safe_core.agent_validation import ContractValidator

validator = ContractValidator()
result = validator.validate_agent_for_pattern(
    agent_contract=agent_yaml,
    pattern_placeholder="supervisor",
    pattern_id="supervisor-manager"
)

if not result["valid"]:
    for error in result["errors"]:
        print(f"❌ {error}")
else:
    print("✅ Agent compatible with pattern")
```

---

## 11. Governance & Maintenance

### 11.1 Template Updates

```
When a template is updated:

1. Version increments (v1.0 → v1.1)
2. CATALOG.yaml updated
3. Existing agents can opt-in to updates
4. Breaking changes marked with ⚠️

How to update agent:
$ python -m safe_cli.cli update-agent my-agent --from-template
→ Shows changes
→ User can merge/accept
```

### 11.2 Community Templates

```yaml
# Phase 2+ feature

templates:
  community:
    - agent: custom-researcher
      author: jane-doe@company.com
      source: internal-shared
      quality_rating: 4.7
      usage_count: 45
      
    - agent: domain-analyzer
      author: team-finance@company.com
      source: internal-shared
      quality_rating: 4.9
      usage_count: 134
```

---

## 12. Summary

| Component | Status | Purpose |
|-----------|--------|---------|
| Contract Schema | ✅ | Define agent I/O, validate compatibility |
| Directory Structure | ✅ | Organize agents, enable discovery |
| Catalog Registry | ✅ | Central index, search/filter |
| Sample Agents | ✅ | 20+ examples to copy from |
| CLI Commands | ✅ | User-friendly agent selection |
| Validation | ✅ | Ensure agents fit patterns |
| Documentation | ✅ | Agent usage & contract |
| Metadata Tracking | ✅ | Version & customization history |

---

**Status: Ready to implement. Agent templating system is production-ready.**
