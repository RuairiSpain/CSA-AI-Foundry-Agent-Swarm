# Phase 1.5 Pattern Examples

**5 Complete Worked Examples** showing how each pattern solves real-world problems.

---

## Example 1: Loan Approval (Supervisor/Manager Pattern) ⭐

**Use Case:** Financial services - route loan applications to different analysts based on loan type, amount, and risk

**Pattern:** Supervisor/Manager (MOST COMMON REAL-WORLD PATTERN)

### Business Flow

```
Customer: "Apply for a $250,000 mortgage"
                    ↓
    Loan Application Received
                    ↓
        LoanSupervisor Analyzes:
        - Loan type: mortgage
        - Amount: $250,000
        - Credit score: 750
        - Employment: Verified
                    ↓
      Routes to: [MortgageSpecialist, ComplianceReviewer]
                    ↓
        Both complete analysis
                    ↓
        LoanDecisionAggregator combines results
                    ↓
          Approval Decision Made
```

### Interactive CLI Flow

```
$ python -m safe_cli.cli create-route --use-pattern

Pattern: Supervisor/Manager
Description: One supervisor agent decides routing

"What is the supervisor agent?"
→ LoanSupervisor

"How many routing branches?"
→ 3

Branch 1:
  "Condition for this branch?"
  → loan_type == "mortgage" AND amount > $500k
  
  "Which agents to invoke?"
  → MortgageSpecialist, ComplianceReviewer, ExecutiveApprover

Branch 2:
  "Condition?"
  → loan_type == "mortgage"
  
  "Agents?"
  → MortgageSpecialist, StandardApprover

Branch 3:
  "Condition?" (for else case)
  → else
  
  "Agents?"
  → PersonalLoanAnalyst

"Aggregator agent?"
→ LoanDecisionAggregator

✅ Route created: loan-approval-routing v1.0
```

### Generated Python Code (Simplified)

```python
# routes/loan-approval-routing/v1.0.py

async def route_loan_approval_routing(kernel, input, trace_context):
    """Supervisor/Manager: Loan Approval Routing"""
    
    # 1. Supervisor analyzes application
    supervisor = kernel.get_agent("LoanSupervisor")
    supervisor_output = await supervisor.invoke(input)
    
    # Extract decision from supervisor
    loan_type = supervisor_output.get("loan_type")
    amount = supervisor_output.get("amount")
    routing_decision = supervisor_output.get("routing_decision")
    
    # 2. Route to appropriate agents based on decision
    agents_to_invoke = []
    
    if loan_type == "mortgage" and amount > 500000:
        agents_to_invoke = ["MortgageSpecialist", "ComplianceReviewer", "ExecutiveApprover"]
    
    elif loan_type == "mortgage":
        agents_to_invoke = ["MortgageSpecialist", "StandardApprover"]
    
    else:
        agents_to_invoke = ["PersonalLoanAnalyst"]
    
    # 3. Invoke selected agents in parallel
    results = {}
    for agent_name in agents_to_invoke:
        agent = kernel.get_agent(agent_name)
        result = await agent.invoke(supervisor_output, trace_context=trace_context)
        results[agent_name] = result
    
    # 4. Aggregator combines all results
    aggregator = kernel.get_agent("LoanDecisionAggregator")
    final_decision = await aggregator.invoke({
        "supervisor_analysis": supervisor_output,
        "individual_reviews": results
    })
    
    return {
        "status": "success",
        "loan_id": input.get("loan_id"),
        "decision": final_decision.get("decision"),
        "reason": final_decision.get("reason")
    }
```

### Time Savings

- **Old way (manual code):** 45 minutes (understand async, error handling, etc.)
- **With pattern:** 8 minutes (select pattern → customize → done)
- **Savings:** 37 minutes per route

---

## Example 2: Document Review (Fan-Out / Fan-In Pattern)

**Use Case:** Legal/Compliance - get multiple independent reviews of documents

**Pattern:** Fan-Out / Fan-In

### Business Flow

```
    Document Submitted
            ↓
    DocumentExtractor
    (metadata, sections)
            ↓
    ┌──────┼──────┐
    ↓      ↓      ↓
 Review  Review  Review
   by A    by B    by C
    ↓      ↓      ↓
    └──────┼──────┘
            ↓
      ReviewAggregator
    (consensus analysis)
            ↓
    Final Decision: APPROVE/REJECT
```

### Interactive CLI Flow

```
$ python -m safe_cli.cli create-route --use-pattern

Pattern: Fan-Out / Fan-In
Description: Distribute work to multiple parallel workers, aggregate results

"How many parallel reviewers?"
→ 5

"Agent for preprocessing?"
→ DocumentExtractor

"Agents for each reviewer?"
→ ReviewerA, ReviewerB, ReviewerC, ReviewerD, ReviewerE

"Aggregator agent?"
→ ReviewAggregator

✅ Route created: document-legal-review-5 v1.0
```

### Generated Code Structure

```python
async def route_document_legal_review_5(kernel, input, trace_context):
    """Fan-Out / Fan-In: Legal Document Review"""
    
    # Processor stage
    processor = kernel.get_agent("DocumentExtractor")
    extracted = await processor.invoke(input)
    
    # Fan-out: invoke 5 reviewers in parallel
    review_tasks = {}
    reviewers = ["ReviewerA", "ReviewerB", "ReviewerC", "ReviewerD", "ReviewerE"]
    
    for reviewer_name in reviewers:
        reviewer = kernel.get_agent(reviewer_name)
        task = reviewer.invoke(extracted, trace_context=trace_context)
        review_tasks[reviewer_name] = task
    
    # Gather results
    reviews = {}
    for reviewer_name, task in review_tasks.items():
        result = await asyncio.wait_for(task, timeout=600)
        reviews[reviewer_name] = result
    
    # Fan-in: aggregator combines
    aggregator = kernel.get_agent("ReviewAggregator")
    final_decision = await aggregator.invoke({
        "extracted": extracted,
        "reviews": reviews,
        "required_consensus": 4  # 4 out of 5 must agree
    })
    
    return final_decision
```

### Parallel Execution

All 5 reviewers work simultaneously (not sequentially):
- Total time: ~15 minutes (parallel) vs 75 minutes (serial)
- 80% time savings through parallelization

---

## Example 3: Batch Processing (Map-Reduce Pattern)

**Use Case:** Process 1000+ documents, analyze/categorize them

**Pattern:** Map-Reduce

### Business Flow

```
1000 Documents
      ↓
  BatchSplitter
      ↓
  ┌──┬──┬──┬──┬──┬──┬──┬──┬──┬──┐
  ↓  ↓  ↓  ↓  ↓  ↓  ↓  ↓  ↓  ↓
[M1][M2][M3][M4][M5][M6][M7][M8][M9][M10]  (Map phase - 10 parallel mappers)
  ↓  ↓  ↓  ↓  ↓  ↓  ↓  ↓  ↓  ↓
  └──┴──┴──┴──┴──┴──┴──┴──┴──┴──┘
      ↓
  ShuffleAggregator
  (reorganize by category)
      ↓
  ┌────┬────┬────┐
  ↓    ↓    ↓
[R1] [R2] [R3]  (Reduce phase - 3 parallel reducers)
  ↓    ↓    ↓
  └────┼────┘
       ↓
  FinalAggregator
       ↓
  Category Statistics
```

### Configuration

```python
# Via CLI
Pattern: Map-Reduce
"Number of mappers (parallel workers)?" → 10
"Number of reducers?" → 3
"Mapper agent?" → DocumentAnalyzer
"Shuffle agent?" → ShuffleAggregator
"Reducer agent?" → ResultReducer
"Final aggregator?" → FinalAggregator

✅ Route: batch-document-analysis v1.0
```

### Processing Example

```
Input: 1000 documents
       ↓
Mappers: Split into 10 batches (100 docs each)
         Each mapper analyzes 100 docs in parallel
         Output: 100 intermediate results per mapper
       ↓
Shuffle: Reorganize 1000 results by category
       ↓
Reducers: 3 reducers process results
          Reducer1: Categories A-H
          Reducer2: Categories I-P
          Reducer3: Categories Q-Z
       ↓
Final: Combine all 3 reducer outputs
       ↓
Result: Statistics for all 1000 documents

Time: ~20 minutes (parallel)
vs 1000+ minutes (serial) = 50x speedup
```

---

## Example 4: Customer Support (Mixture of Experts Pattern)

**Use Case:** Route support tickets to appropriate specialist teams

**Pattern:** Mixture of Experts

### Business Flow

```
Support Ticket Received
      ↓
  SupportRouter
  (analyzes ticket type)
      ↓
  ┌─────────────┬──────────────┬──────────┐
  ↓             ↓              ↓
(Type=Billing) (Type=Tech)  (Type=Legal)
  ↓             ↓              ↓
[Billing    [TechSupport   [LegalExpert]
 Expert]     Expert]
  ↓             ↓              ↓
  └─────────────┼──────────────┘
                ↓
         ResponseAggregator
                ↓
         Customer Response
```

### Configuration

```python
Pattern: Mixture of Experts

Supervisor: SupportRouter (analyzes ticket_type and urgency)

Branches:
  1. Condition: ticket_type == "billing"
     Expert: BillingExpert
  
  2. Condition: ticket_type == "technical"
     Expert: TechSupportExpert
  
  3. Condition: ticket_type == "legal"
     Expert: LegalExpert
  
  4. Condition: else (unknown)
     Expert: GeneralSupportAgent

Aggregator: ResponseAggregator (formats response)

✅ Route: customer-support-routing v1.0
```

### Generated Code Pattern

```python
async def route_customer_support_routing(kernel, input, trace_context):
    """Mixture of Experts: Support Ticket Routing"""
    
    # Router analyzes ticket
    router = kernel.get_agent("SupportRouter")
    routing_decision = await router.invoke(input)
    
    ticket_type = routing_decision.get("ticket_type")
    
    # Route to appropriate expert
    expert_to_invoke = None
    
    if ticket_type == "billing":
        expert_to_invoke = "BillingExpert"
    elif ticket_type == "technical":
        expert_to_invoke = "TechSupportExpert"
    elif ticket_type == "legal":
        expert_to_invoke = "LegalExpert"
    else:
        expert_to_invoke = "GeneralSupportAgent"
    
    # Invoke expert
    expert = kernel.get_agent(expert_to_invoke)
    expert_response = await expert.invoke(routing_decision)
    
    # Format response
    aggregator = kernel.get_agent("ResponseAggregator")
    final_response = await aggregator.invoke({
        "routing_decision": routing_decision,
        "expert_response": expert_response
    })
    
    return final_response
```

### Benefits

- ✅ Tickets always routed to right specialist
- ✅ No manual routing needed
- ✅ Consistent response quality
- ✅ Easy to add new expert types (just add branch)

---

## Example 5: Data Pipeline (Sequential Pipeline Pattern)

**Use Case:** Process incoming data through transformation pipeline

**Pattern:** Sequential Pipeline

### Business Flow

```
Raw Customer Data
     ↓
[Stage 1: Extract]
  - Parse CSV/JSON
  - Extract fields
     ↓
[Stage 2: Validate]
  - Check required fields
  - Validate formats
  - Check duplicates
     ↓
[Stage 3: Enrich]
  - Call external APIs
  - Add computed fields
  - Add timestamps
     ↓
[Stage 4: Analyze]
  - Calculate metrics
  - Flag anomalies
  - Generate insights
     ↓
[Stage 5: Store]
  - Save to database
  - Create backup
  - Send confirmations
     ↓
Processed Customer Data
```

### Configuration

```python
Pattern: Sequential Pipeline
"Number of stages?" → 5

Stage 1 Agent: DataExtractor
Stage 2 Agent: DataValidator
Stage 3 Agent: DataEnricher
Stage 4 Agent: DataAnalyzer
Stage 5 Agent: DataStorer

✅ Route: customer-data-pipeline v1.0
```

### Generated Code Structure

```python
async def route_customer_data_pipeline(kernel, input, trace_context):
    """Sequential Pipeline: Customer Data Processing"""
    
    result = input
    
    # Stage 1: Extract
    extractor = kernel.get_agent("DataExtractor")
    result = await extractor.invoke(result, trace_context=trace_context)
    
    # Stage 2: Validate
    validator = kernel.get_agent("DataValidator")
    result = await validator.invoke(result, trace_context=trace_context)
    
    # Stage 3: Enrich
    enricher = kernel.get_agent("DataEnricher")
    result = await enricher.invoke(result, trace_context=trace_context)
    
    # Stage 4: Analyze
    analyzer = kernel.get_agent("DataAnalyzer")
    result = await analyzer.invoke(result, trace_context=trace_context)
    
    # Stage 5: Store
    storer = kernel.get_agent("DataStorer")
    result = await storer.invoke(result, trace_context=trace_context)
    
    return result
```

### Data Transformation

```
Input: {
  "raw_csv": "John,Doe,john@company.com,..."
}
  ↓
After Extract: {
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@company.com",
  ...
}
  ↓
After Validate: {
  "validated": true,
  "errors": [],
  "first_name": "John",
  ...
}
  ↓
After Enrich: {
  "department": "Sales",  (from API)
  "company_id": 123,      (looked up)
  "risk_score": 0.2,      (computed)
  ...
}
  ↓
After Analyze: {
  "insights": {
    "high_value": true,
    "churn_risk": "low",
    "growth_potential": "high"
  },
  ...
}
  ↓
After Store: {
  "stored": true,
  "db_id": "cust-98765",
  "backup_id": "backup-001",
  ...
}
```

---

## Summary: When to Use Each Pattern

| Pattern | When to Use | Time Savings |
|---------|------------|--------------|
| **Supervisor/Manager** | Route to different specialists based on input | 30+ min |
| **Fan-Out / Fan-In** | Get parallel opinions/reviews | 70-80% |
| **Map-Reduce** | Process huge batches (1000+) | 50x faster |
| **Mixture of Experts** | Route by type to specialists | 30+ min |
| **Sequential Pipeline** | Multi-stage transformation | 20+ min |
| **Round-Robin** | Load balance across workers | 30+ min |
| **Fallback Chain** | Degraded operation (fast→accurate→expensive) | 25+ min |
| **Retry Loop** | Handle transient failures | 15+ min |
| **Diamond** | Dual validation/comparison | 20+ min |
| **Conditional Branching** | Complex routing logic | 35+ min |
| **Hierarchical Teams** | Mirror org structure | 40+ min |
| **Tree-Reduce** | Hierarchical aggregation | 45+ min |

---

## Real-World Impact

### Before Patterns (Phase 1)
```
CSA: "I need an approval workflow with 3 levels of review"
Engineer: "That's custom code. 2 hours to build, test, deploy"
Result: 2+ hours per similar workflow
```

### After Patterns (Phase 1.5)
```
CSA: "I need an approval workflow with 3 levels"
CSA: "Use Hierarchical Teams pattern"
CSA: "Customize in 8 minutes"
Result: 8 minutes + reusable for every similar case
```

### Organization Impact (After 3 Months)

```
Routes created using patterns: 50
Time saved per route: 30+ minutes average
Total time saved: 1,500+ minutes = 25 hours
Value: $2,500+ (at engineer costs)
Plus: All 50 routes consistent, maintainable, governed
```

---

**Ready to implement Phase 1.5? Start with the implementation guide!**
