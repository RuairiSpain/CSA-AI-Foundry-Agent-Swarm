# Phase 1.5 Implementation Guide

**Phase:** 1.5 (Weeks 4-5 of 12-week plan)  
**Status:** Implementation Ready  
**Lines of Code:** ~3,500 new  
**Test Coverage Goal:** 90%+

---

## Quick Start for Implementation Team

### Prerequisites
- Understand Phase 1 (Route Writer, code generation)
- Familiar with Jinja2 templating
- Experience with async/await patterns
- Knowledge of test-driven development

### Week 1: Core Implementation

#### Day 1-2: Pattern Library
**File:** `safe_core/pattern_library.py`

```python
# Already implemented - see safe_phase1_5_pattern_library.py
# This file provides:
# - 12 PatternTemplate definitions
# - PatternRegistry class
# - Pattern discovery/search/statistics

from safe_core.pattern_library import PATTERN_REGISTRY

# Example usage:
registry = PATTERN_REGISTRY
patterns = registry.list_patterns(category=PatternCategory.PARALLEL)
fan_out = registry.get_pattern("fan-out-fan-in")
```

**What to do:**
1. Copy `safe_phase1_5_pattern_library.py` to `safe_core/pattern_library.py`
2. Add unit tests (test_pattern_library.py)
3. Verify all 12 patterns register correctly

---

#### Day 3-4: Pattern Customizer
**File:** `safe_core/pattern_customizer.py` (~350 lines)

**Key Class:**
```python
class PatternCustomizer:
    """Interactive pattern customization session."""
    
    async def select_pattern(self, pattern_id: str) -> PatternTemplate:
        """User picks a pattern."""
        pass
    
    async def customize_variables(self, pattern: PatternTemplate) -> Dict:
        """Ask for variable parameters."""
        # For each variable in pattern.variables:
        #   - Show display_name and description
        #   - Get user input (within min/max range)
        #   - Validate and store
        pass
    
    async def customize_placeholders(self, pattern: PatternTemplate) -> Dict:
        """Ask for agent assignments."""
        # For each placeholder in pattern.placeholders:
        #   - If is_array: ask for N agents (from variable count)
        #   - If not: ask for 1 agent
        #   - Validate agent exists
        #   - Store assignments
        pass
    
    async def preview_route(self) -> str:
        """Show preview of generated route."""
        pass
    
    def get_summary(self) -> Dict:
        """Return configuration summary."""
        pass
```

**What to do:**
1. Implement PatternCustomizer class
2. Add interview flow (async user input)
3. Add validation
4. Add preview generation
5. Add tests (test_pattern_customizer.py)

---

#### Day 5: Jinja2 Templates (Start)

**Key Template:** `pattern_templates/supervisor_manager.py.jinja2` (250 lines)

Since Supervisor/Manager is the most critical pattern, start here.

**Template Structure:**
```jinja2
# File: routes/{{ route_name }}/v{{ route_version }}.py
# Generated: {{ timestamp }}
# Pattern: Supervisor/Manager

async def route_{{ route_name }}(kernel, input, trace_context):
    """
    Supervisor/Manager Route
    Supervisor analyzes input and decides routing.
    """
    
    with trace_context.span("route_{{ route_name }}"):
        # 1. Invoke supervisor agent
        supervisor = kernel.get_agent("{{ supervisor_agent }}")
        supervisor_output = await supervisor.invoke(input)
        
        # 2. Based on supervisor decision, invoke appropriate agents
        decision = supervisor_output.get("routing_decision")
        
        if decision == "branch_1":
            agents_to_invoke = {{ branch_1_agents | tojson }}
        elif decision == "branch_2":
            agents_to_invoke = {{ branch_2_agents | tojson }}
        # ... more branches
        else:
            agents_to_invoke = {{ fallback_agents | tojson }}
        
        # 3. Invoke selected agents in parallel
        results = {}
        for agent_name in agents_to_invoke:
            agent = kernel.get_agent(agent_name)
            result = await agent.invoke(supervisor_output, trace_context=trace_context)
            results[agent_name] = result
        
        # 4. Aggregator combines results
        aggregator = kernel.get_agent("{{ aggregator_agent }}")
        final_result = await aggregator.invoke({
            "supervisor_output": supervisor_output,
            "agent_results": results
        })
        
        return final_result
```

**What to do:**
1. Create 12 Jinja2 templates (one for each pattern)
2. Start with supervisor_manager.py.jinja2
3. Each template should:
   - Use pattern-specific logic
   - Include full type hints
   - Include tracing
   - Include error handling
   - Be ~200-280 lines

---

### Week 2: CLI Integration + Testing

#### Day 6-7: CLI Updates
**File:** `safe_cli/cli.py` (~200 additional lines)

**New Commands:**
```bash
# List all patterns
@app.command()
def list_patterns(
    category: Optional[str] = typer.Option(None),
    complexity: Optional[str] = typer.Option(None)
):
    """List available patterns."""
    # Show patterns with descriptions, diagrams, usage count

# Show specific pattern
@app.command()
def show_pattern(pattern_id: str = typer.Argument(...)):
    """Show pattern details."""
    # Show diagram, use cases, complexity, etc.

# Create route using pattern
@app.command()
def create_route(use_pattern: bool = typer.Option(False)):
    """Create route (optionally from pattern)."""
    if use_pattern:
        # Show pattern list
        # User selects pattern
        # Customizer interview
        # Generate code
    else:
        # Original flow (Phase 1)
```

**What to do:**
1. Add `list_patterns` command
2. Add `show_pattern` command
3. Update `create_route` to support `--use-pattern` flag
4. Integrate with PatternCustomizer
5. Add to tests

---

#### Day 8-9: Comprehensive Tests

**Test Files:**
1. `test_pattern_library.py` (200 lines)
   - Pattern registration
   - Pattern retrieval
   - Pattern filtering
   - Search functionality

2. `test_pattern_customizer.py` (250 lines)
   - Variable customization
   - Placeholder assignment
   - Route preview
   - Route testing

3. `test_patterns_integration.py` (400 lines)
   - Each pattern with real agents
   - Code generation for each pattern
   - End-to-end workflows
   - Performance benchmarks

**Example Test:**
```python
@pytest.mark.asyncio
async def test_supervisor_manager_route():
    """Test supervisor/manager pattern."""
    customizer = PatternCustomizer()
    
    # Select pattern
    pattern = customizer.get_pattern("supervisor-manager")
    
    # Customize
    customizer.customize_variables(pattern, {
        "branch_count": 3
    })
    
    customizer.customize_placeholders(pattern, {
        "supervisor": "LoanSupervisor",
        "branches": [
            {"condition": 'type == "mortgage"', "agents": ["MortgageAnalyst"]},
            {"condition": 'type == "auto"', "agents": ["AutoAnalyst"]},
            {"condition": "else", "agents": ["DefaultAnalyst"]}
        ],
        "aggregator": "LoanAggregator"
    })
    
    # Generate code
    code = customizer.generate_code()
    
    # Validate
    assert SyntaxValidator.validate(code)["valid"]
    
    # Test
    result = await customizer.test_route(code, sample_input)
    assert result["success"]
```

**What to do:**
1. Write tests for each pattern
2. Aim for 60+ total tests
3. 90%+ coverage
4. Performance tests

---

#### Day 10: Documentation

**Files to Create:**
1. `PHASE_1.5_IMPLEMENTATION_GUIDE.md` (this file + more)
2. `PATTERN_EXAMPLES.md` (5 worked examples)
3. Update `CLI_COMMANDS.md`
4. Update `README.md`

**What to do:**
1. Create pattern examples guide
2. Add to README.md
3. Add CLI help text
4. Create troubleshooting guide

---

## File Structure for Phase 1.5

```
safe_phase1/
├── safe_core/
│   ├── pattern_library.py              (1,050 lines) ← CREATE FROM safe_phase1_5_pattern_library.py
│   ├── pattern_customizer.py           (350 lines)   ← CREATE
│   ├── pattern_authoring.py            (300 lines)   ← CREATE (foundation)
│   ├── pattern_templates/              (NEW DIR)
│   │   ├── fan_out_fan_in.py.jinja2    (200 lines)
│   │   ├── map_reduce.py.jinja2        (220 lines)
│   │   ├── round_robin.py.jinja2       (180 lines)
│   │   ├── mixture_of_experts.py.jinja2 (200 lines)
│   │   ├── sequential_pipeline.py.jinja2 (180 lines)
│   │   ├── supervisor_manager.py.jinja2 (250 lines)   ← PRIORITY
│   │   ├── hierarchical_teams.py.jinja2 (280 lines)
│   │   ├── fallback_chain.py.jinja2    (200 lines)
│   │   ├── retry_loop.py.jinja2        (220 lines)
│   │   ├── diamond.py.jinja2           (180 lines)
│   │   ├── conditional_branching.py.jinja2 (240 lines)
│   │   └── tree_reduce.py.jinja2       (200 lines)
│   ├── route_writer.py                 (UPDATED, +100 lines)
│   ├── code_generator.py               (UPDATED, +50 lines)
│   └── example_agents.py               (unchanged)
│
├── safe_cli/
│   └── cli.py                          (UPDATED, +200 lines)
│
├── tests/
│   ├── test_pattern_library.py         (200 lines)
│   ├── test_pattern_customizer.py      (250 lines)
│   ├── test_patterns_integration.py    (400 lines)
│   └── [existing tests]
│
├── examples/
│   ├── patterns/                       (NEW DIR)
│   │   ├── loan_approval_supervisor.py
│   │   ├── document_review_fan_out.py
│   │   ├── batch_processing_map_reduce.py
│   │   ├── customer_support_mixture.py
│   │   └── data_pipeline_sequential.py
│   └── ...
│
└── PHASE_1.5_SPECIFICATION.md          (THIS FILE)
```

---

## Priority Order

### Must Have (Week 1)
1. ✅ Pattern Library (safe_phase1_5_pattern_library.py) - PROVIDED
2. Pattern Customizer (create)
3. Supervisor/Manager Template (create - most used)
4. Fan-Out/Fan-In Template (create - most used)
5. CLI list-patterns, show-pattern (create)

### Should Have (Week 2)
6. All 12 Jinja2 templates
7. Pattern authoring foundation
8. Comprehensive tests (60+)
9. Documentation
10. Examples

### Nice to Have (Phase 2+)
- User pattern governance UI
- Pattern marketplace
- Community patterns
- Advanced pattern analytics

---

## Testing Strategy

### Unit Tests (30 tests)
- Pattern library operations
- Pattern customizer logic
- Template rendering

### Integration Tests (20 tests)
- End-to-end pattern workflows
- Real agent integration
- Code generation and testing

### Performance Tests (10 tests)
- Pattern selection <100ms
- Code generation <200ms
- Registry load <50ms

---

## Success Criteria

**Code Quality**
- ✅ All 12 patterns implemented
- ✅ 60+ tests, 90%+ coverage
- ✅ Full type hints
- ✅ Google-style docstrings
- ✅ Passes linting

**Functionality**
- ✅ Pattern selection works
- ✅ All patterns generate valid code
- ✅ Code compiles and runs
- ✅ User interviews work

**Performance**
- ✅ Pattern selection: <100ms
- ✅ Code generation: <200ms
- ✅ CLI responsive

**UX**
- ✅ Clear pattern discovery
- ✅ Intuitive interviews
- ✅ Helpful error messages
- ✅ CSA time-to-route: 5-10 min

---

## Common Pitfalls & Solutions

| Pitfall | Solution |
|---------|----------|
| Template complexity | Start with sequential (simplest), then parallel |
| Async/await in templates | Use {% await %} in Jinja2 (or raw Python) |
| Agent not found errors | Add clear error messages in generated code |
| Variable name clashes | Use prefix (e.g., "pattern_worker_count") |
| User pattern governance | Start simple: draft → submitted → approved |

---

## Rollout Plan

### Week 4 (Implementation)
- Developers implement all code
- QA reviews code quality
- Integration testing

### Week 5 (Refinement)
- User testing with CSA team
- Fix bugs/UX issues
- Documentation review
- Performance tuning

### End of Week 5
- All tests passing
- Documentation complete
- Ready for Phase 2

---

## Questions During Implementation?

1. **Template syntax unclear?**
   - Refer to existing Phase 1 templates
   - Check Jinja2 documentation

2. **Pattern logic wrong?**
   - Review specification section
   - Compare with real-world examples

3. **Test failing?**
   - Check error message
   - Review test expectations
   - Verify mock agents

4. **Performance issue?**
   - Profile with timing
   - Check template complexity
   - Optimize if needed

---

## Phase 1.5 Checklist

- [ ] Pattern library implemented and tested
- [ ] Pattern customizer implemented and tested
- [ ] 12 Jinja2 templates created
- [ ] CLI updated (list-patterns, show-pattern, create-route)
- [ ] 60+ tests written and passing
- [ ] Performance benchmarks met
- [ ] Documentation complete
- [ ] Example patterns created
- [ ] CSA user testing done
- [ ] All code reviewed and approved
- [ ] Ready for Phase 2!

---

**Timeline:** Weeks 4-5  
**Effort:** One senior engineer, ~160 hours  
**Success Metric:** CSA time-to-route < 10 minutes for any pattern
