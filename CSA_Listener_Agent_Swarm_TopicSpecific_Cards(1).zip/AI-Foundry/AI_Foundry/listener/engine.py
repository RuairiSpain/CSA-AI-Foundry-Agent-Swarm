from __future__ import annotations

import os
import json
import time
import uuid
from typing import Any, Dict, List, Tuple

from .models import FoundryModelClient
from .prompts import (
    MODE_GUIDANCE,
    PERSONA_GUIDANCE,
    INDUSTRY_GUIDANCE,
    LISTENER_FAST_SYSTEM,
    TOPIC_STYLE_CLASSIFIER_SYSTEM,
    INDUSTRY_CLASSIFIER_SYSTEM,
    INDUSTRY_ADVISOR_SYSTEM,
    LISTENER_EXTRACT_SYSTEM,
    DISCOVERY_COACH_SYSTEM,
    SOLUTION_ARCH_SYSTEM,
    OPPORTUNITY_SYSTEM,
    GAP_SYSTEM,
    WHISPER_SYSTEM,
    TALKTRACK_SYSTEM,
)

TOPIC_CUES = {
    'security_compliance': ['security','compliance','gdpr','hipaa','pci','sox','audit','pii','phi','encryption','key vault','defender','purview','policy','regulatory'],
    'governance_risk': ['governance','risk','approval','guardrail','control','responsible ai','model governance','data governance','tenant','policy-as-code'],
    'cost_finops': ['cost','budget','finops','spend','macc','chargeback','showback','unit cost','pricing','tco','roi'],
    'architecture_networking': ['vnet','private endpoint','private link','dns','peering','expressroute','firewall','waf','apim','api management','load balancer','gateway','network'],
    'operations_observability': ['observability','monitor','app insights','log analytics','kql','alerts','slo','sli','oncall','runbook','incident','dr','rto','rpo','backup'],
    'data_ai': ['rag','retrieval','vector','embeddings','search','fabric','cosmos','sql','data lake','etl','pipeline','prompt flow','evaluation','grounding','hallucination'],
    'delivery_next_steps': ['next step','workshop','vbd','pilot','poc','timeline','milestone','scope','deliverable','stakeholder','action item'],
    'requirements_discovery': ['use case','scenario','requirements','success criteria','pain point','problem','goal','users','workflow','current state'],
}

TOPIC_TO_MODE = {
    'security_compliance': 'executive',
    'governance_risk': 'executive',
    'cost_finops': 'executive',
    'delivery_next_steps': 'executive',
    'architecture_networking': 'technical',
    'operations_observability': 'technical',
    'data_ai': 'technical',
    'requirements_discovery': 'consultative',
}

VP_CUES = ['vp','vice president','director','cxo','cio','cto','ciso','head of']
LEAD_CUES = ['tech lead','architect','engineer','developer lead','platform team','sre']
GRAD_CUES = ['graduate','junior','new to','first time','learning']

# Topic-specific card formats (UI-friendly)
# Each format returns a dict in guidance['_card'] with a stable schema per topic.
CARD_FORMATS: Dict[str, Dict[str, Any]] = {
    'security_compliance': {
        'title': 'Security & Compliance',
        'sections': ['risk', 'controls', 'ask', 'next_step'],
    },
    'governance_risk': {
        'title': 'Governance & Risk',
        'sections': ['ownership', 'guardrails', 'ask', 'next_step'],
    },
    'cost_finops': {
        'title': 'Cost & FinOps',
        'sections': ['cost_driver', 'guardrail', 'ask', 'next_step'],
    },
    'architecture_networking': {
        'title': 'Architecture & Networking',
        'sections': ['constraint', 'options', 'tradeoff', 'ask'],
    },
    'operations_observability': {
        'title': 'Operations & Observability',
        'sections': ['signal', 'slo', 'instrumentation', 'ask'],
    },
    'data_ai': {
        'title': 'Data & AI',
        'sections': ['data_sources', 'retrieval', 'evaluation', 'ask'],
    },
    'delivery_next_steps': {
        'title': 'Delivery Next Steps',
        'sections': ['decision', 'owner', 'date', 'next_step'],
    },
    'requirements_discovery': {
        'title': 'Requirements Discovery',
        'sections': ['goal', 'pain', 'constraints', 'ask'],
    },
}


class ListenerEngine:
    def __init__(self):
        self.primary_model = os.getenv('PRIMARY_MODEL','gpt-5-mini')
        self.project_endpoint = os.getenv('FOUNDRY_PROJECT_ENDPOINT','')
        self.deep_on_final = os.getenv('LISTENER_DEEP_ON_FINAL','true').lower()=='true'
        self.pause_seconds = float(os.getenv('LISTENER_DEEP_PAUSE_SECONDS','8'))
        self.auto_lock_seconds = float(os.getenv('LISTENER_AUTO_LOCK_SECONDS','20'))
        self.auto_llm = os.getenv('LISTENER_AUTO_LLM','true').lower()=='true'

    def _client(self) -> FoundryModelClient:
        return FoundryModelClient(project_endpoint=self.project_endpoint, model=self.primary_model)

    def _window(self, state: Dict[str, Any], n: int = 25) -> str:
        turns = state.get('transcript', [])[-n:]
        return '\n'.join([f"{t['speaker']}: {t['text']}" for t in turns if t.get('text')])

    def _facts_text(self, state: Dict[str, Any]) -> str:
        return json.dumps(state.get('facts', {}), ensure_ascii=False)

    def _context_header(self, state: Dict[str, Any]) -> str:
        mode = state.get('mode','consultative')
        persona = state.get('persona','unknown')
        industry = state.get('industry','general')
        topic = state.get('topic','requirements_discovery')
        return (
            f"Topic: {topic}\n"
            f"Mode guidance: {MODE_GUIDANCE.get(mode, MODE_GUIDANCE['consultative'])}\n"
            f"Persona guidance: {PERSONA_GUIDANCE.get(persona, PERSONA_GUIDANCE['unknown'])}\n"
            f"Industry guidance: {INDUSTRY_GUIDANCE.get(industry, INDUSTRY_GUIDANCE['general'])}\n"
        )

    def _det_topic(self, window_lower: str, facts_lower: str) -> Tuple[str, str, List[str]]:
        best = ('requirements_discovery', 0, [])
        for topic, cues in TOPIC_CUES.items():
            hits = [c for c in cues if c in window_lower or c in facts_lower]
            if len(hits) > best[1]:
                best = (topic, len(hits), hits)
        topic, score, hits = best
        if score >= 3:
            conf = 'high'
        elif score == 2:
            conf = 'medium'
        else:
            conf = 'low'
            if score == 0:
                topic = 'requirements_discovery'
                hits = []
        return topic, conf, hits

    def _det_persona(self, window_lower: str) -> Tuple[str, List[str]]:
        if any(c in window_lower for c in VP_CUES):
            return 'director_vp', [c for c in VP_CUES if c in window_lower][:4]
        if any(c in window_lower for c in LEAD_CUES):
            return 'tech_lead', [c for c in LEAD_CUES if c in window_lower][:4]
        if any(c in window_lower for c in GRAD_CUES):
            return 'graduate', [c for c in GRAD_CUES if c in window_lower][:4]
        return 'unknown', []

    def _maybe_auto_style(self, state: Dict[str, Any]) -> Dict[str, Any]:
        now = time.time()
        if not state.get('auto_mode', True) and not state.get('auto_persona', True) and not state.get('auto_topic', True):
            return {'changed': False}

        auto_mode_allowed = bool(state.get('auto_mode', True)) and state.get('mode_source') != 'manual'
        auto_persona_allowed = bool(state.get('auto_persona', True)) and state.get('persona_source') != 'manual'
        auto_topic_allowed = bool(state.get('auto_topic', True)) and state.get('topic_source') != 'manual'
        if not auto_mode_allowed and not auto_persona_allowed and not auto_topic_allowed:
            return {'changed': False}

        last_change = float(state.get('last_style_change_ts', 0.0) or 0.0)
        if (now - last_change) < self.auto_lock_seconds:
            return {'changed': False}

        window = self._window(state)
        window_lower = window.lower()
        facts_lower = self._facts_text(state).lower()

        topic_guess, topic_conf, topic_cues = self._det_topic(window_lower, facts_lower)
        persona_guess, persona_cues = self._det_persona(window_lower)
        mode_guess = TOPIC_TO_MODE.get(topic_guess, 'consultative')

        cues = (topic_cues + persona_cues)[:8]
        confidence = topic_conf

        if self.auto_llm:
            llm = None
            try:
                raw = self._client().ask(TOPIC_STYLE_CLASSIFIER_SYSTEM, f"Window:\n{window}\nFacts:\n{self._facts_text(state)}\nReturn STRICT JSON.")
                llm = _safe_json(raw)
            except Exception:
                llm = None
            if isinstance(llm, dict) and llm.get('confidence') in ('medium','high'):
                if llm.get('topic') in TOPIC_TO_MODE:
                    topic_guess = llm['topic']
                if llm.get('mode') in ('consultative','executive','technical'):
                    mode_guess = llm['mode']
                if llm.get('persona') in ('director_vp','tech_lead','graduate','unknown'):
                    persona_guess = llm['persona']
                confidence = llm.get('confidence', confidence)
                if isinstance(llm.get('cues'), list):
                    cues = llm.get('cues')[:8]

        changed = False
        if auto_topic_allowed and topic_guess != state.get('topic'):
            state['topic'] = topic_guess
            state['topic_confidence'] = confidence
            state['topic_source'] = 'auto'
            changed = True
        if auto_mode_allowed and mode_guess != state.get('mode'):
            state['mode'] = mode_guess
            state['mode_source'] = 'auto'
            changed = True
        if auto_persona_allowed and persona_guess != state.get('persona'):
            state['persona'] = persona_guess
            state['persona_source'] = 'auto'
            changed = True
        if changed:
            state['last_style_change_ts'] = now
        return {'changed': changed, 'topic': state.get('topic'), 'mode': state.get('mode'), 'persona': state.get('persona'), 'confidence': confidence, 'cues': cues}

    def process_chunk(self, state: Dict[str, Any], chunk: Dict[str, Any]) -> Dict[str, Any]:
        now = time.time()
        state.setdefault('transcript', []).append({'ts': now, 'speaker': chunk.get('speaker','unknown'), 'text': chunk.get('text',''), 'final': bool(chunk.get('is_final', False))})

        style_change = self._maybe_auto_style(state)

        is_final = bool(chunk.get('is_final', False))
        force_deep = bool(chunk.get('force_deep', False))

        route = 'fast'
        if force_deep:
            route = 'deep'
        elif is_final and self.deep_on_final:
            route = 'deep'
        else:
            last_final_ts = None
            for t in reversed(state['transcript']):
                if t.get('final'):
                    last_final_ts = t.get('ts')
                    break
            if last_final_ts and (now - last_final_ts) >= self.pause_seconds:
                route = 'deep'

        out = self._deep(state) if route == 'deep' else self._fast(state)

        # Apply topic-specific card formatting
        out['guidance'] = _apply_card_format(out['guidance'], state)

        if style_change.get('changed'):
            out['guidance']['_style_switch'] = style_change
        return out

    def _fast(self, state: Dict[str, Any]) -> Dict[str, Any]:
        client = self._client()
        header = self._context_header(state)
        facts = json.dumps(state.get('facts', {}), ensure_ascii=False)
        window = self._window(state)
        raw = client.ask(LISTENER_FAST_SYSTEM, header + f"\nRunning facts:\n{facts}\n\nWindow:\n{window}\nReturn STRICT JSON.")
        guidance = _safe_json(raw) or _fallback_guidance(raw)
        extracted = guidance.get('extracted', {}) or {}
        state['facts'] = _merge_facts(state.get('facts', {}), extracted)
        card = _to_card(guidance, state, mode='fast')
        state.setdefault('cards', []).append(card)
        state['last_guidance'] = card
        return {'state': state, 'guidance': card}

    def _deep(self, state: Dict[str, Any]) -> Dict[str, Any]:
        client = self._client()
        header = self._context_header(state)
        facts0 = state.get('facts', {})
        window = self._window(state)

        ind_raw = client.ask(INDUSTRY_CLASSIFIER_SYSTEM, header + f"\nWindow:\n{window}\nReturn STRICT JSON.")
        ind = _safe_json(ind_raw) or {'industry':'general','confidence':'low','signals':[]}
        state['industry'] = ind.get('industry','general')
        state['industry_confidence'] = ind.get('confidence','low')

        header = self._context_header(state)

        ex_raw = client.ask(LISTENER_EXTRACT_SYSTEM, header + f"\nFacts so far:\n{json.dumps(facts0, ensure_ascii=False)}\n\nWindow:\n{window}\nReturn STRICT JSON.")
        extracted = _safe_json(ex_raw) or {}
        facts = _merge_facts(facts0, extracted)
        state['facts'] = facts

        ia_raw = client.ask(INDUSTRY_ADVISOR_SYSTEM, header + f"\nFacts:\n{json.dumps(facts, ensure_ascii=False)}\n\nWindow:\n{window}\nReturn STRICT JSON.")
        industry_pack = _safe_json(ia_raw) or {}

        q_raw = client.ask(DISCOVERY_COACH_SYSTEM, header + f"\nFacts:\n{json.dumps(facts, ensure_ascii=False)}\n\nWindow:\n{window}")
        questions = (_safe_json(q_raw) or {}).get('questions', [])

        h_raw = client.ask(SOLUTION_ARCH_SYSTEM, header + f"\nFacts:\n{json.dumps(facts, ensure_ascii=False)}\n\nWindow:\n{window}")
        hypotheses = (_safe_json(h_raw) or {}).get('hypotheses', [])

        o_raw = client.ask(OPPORTUNITY_SYSTEM, header + f"\nFacts:\n{json.dumps(facts, ensure_ascii=False)}\n\nWindow:\n{window}")
        opportunities = (_safe_json(o_raw) or {}).get('opportunities', [])

        g_raw = client.ask(GAP_SYSTEM, header + f"\nFacts:\n{json.dumps(facts, ensure_ascii=False)}\n\nWindow:\n{window}")
        gap_obj = _safe_json(g_raw) or {}

        whisper_inputs = {
            'extracted': facts,
            'industry': {'industry': state.get('industry','general'), 'confidence': state.get('industry_confidence','low'), 'insights': industry_pack},
            'questions': questions,
            'hypotheses': hypotheses,
            'opportunities': opportunities,
            'gap': gap_obj,
        }

        w_raw = client.ask(WHISPER_SYSTEM, header + f"\nInputs:\n{json.dumps(whisper_inputs, ensure_ascii=False)}\nReturn STRICT JSON.")
        guidance = _safe_json(w_raw) or _fallback_guidance(w_raw)
        guidance['extracted'] = facts
        guidance['_deep'] = {
            'industry': whisper_inputs['industry'],
            'questions': questions,
            'hypotheses': hypotheses,
            'opportunities': opportunities,
            'gap': gap_obj,
        }

        card = _to_card(guidance, state, mode='deep')
        state.setdefault('cards', []).append(card)
        state['last_guidance'] = card
        return {'state': state, 'guidance': card}

    def talk_track(self, state: Dict[str, Any], card: Dict[str, Any], mode: str | None = None, persona: str | None = None) -> Dict[str, Any]:
        client = self._client()
        if mode:
            state['mode'] = mode
            state['mode_source'] = 'manual'
        if persona:
            state['persona'] = persona
            state['persona_source'] = 'manual'
        header = self._context_header(state)
        payload = {'card': card, 'mode': state.get('mode'), 'persona': state.get('persona'), 'industry': state.get('industry'), 'topic': state.get('topic')}
        raw = client.ask(TALKTRACK_SYSTEM, header + f"\nCard:\n{json.dumps(payload, ensure_ascii=False)}\nReturn STRICT JSON.")
        out = _safe_json(raw)
        if out and isinstance(out.get('talk_track'), list):
            return out
        return {'talk_track':[f"Based on what you've shared, {card.get('key_insight','...')}", f"Could you clarify: {card.get('suggested_question','...')}", f"One direction we can explore is: {card.get('solution_hint','...')}", "Does that align with your priorities?"], 'one_liner': card.get('suggested_question','')}


def _apply_card_format(guidance: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
    topic = state.get('topic', 'requirements_discovery')
    fmt = CARD_FORMATS.get(topic, CARD_FORMATS['requirements_discovery'])

    # Build a topic-specific payload using existing guidance + deep fields
    deep = guidance.get('_deep') or {}
    extracted = guidance.get('extracted') or {}

    def pick_first(lst):
        if isinstance(lst, list) and lst:
            return lst[0]
        return ''

    card_payload = {
        'schema': f"csa.card.{topic}.v1",
        'title': fmt['title'],
        'topic': topic,
        'sections': {},
    }

    # Populate by topic
    if topic == 'security_compliance':
        card_payload['sections'] = {
            'risk': pick_first(extracted.get('constraints')) or guidance.get('critical_gap',''),
            'controls': pick_first(extracted.get('current_state')),
            'ask': guidance.get('suggested_question',''),
            'next_step': guidance.get('solution_hint',''),
        }
    elif topic == 'governance_risk':
        card_payload['sections'] = {
            'ownership': pick_first(extracted.get('current_state')),
            'guardrails': pick_first(extracted.get('constraints')),
            'ask': guidance.get('suggested_question',''),
            'next_step': guidance.get('solution_hint',''),
        }
    elif topic == 'cost_finops':
        card_payload['sections'] = {
            'cost_driver': pick_first(extracted.get('pain_points')),
            'guardrail': pick_first(extracted.get('constraints')),
            'ask': guidance.get('suggested_question',''),
            'next_step': guidance.get('solution_hint',''),
        }
    elif topic == 'architecture_networking':
        card_payload['sections'] = {
            'constraint': pick_first(extracted.get('constraints')),
            'options': deep.get('hypotheses') or [],
            'tradeoff': pick_first(deep.get('gap', {}).get('why_it_matters')) if isinstance(deep.get('gap'), dict) else '',
            'ask': guidance.get('suggested_question',''),
        }
    elif topic == 'operations_observability':
        card_payload['sections'] = {
            'signal': pick_first(extracted.get('pain_points')),
            'slo': pick_first(extracted.get('constraints')),
            'instrumentation': deep.get('hypotheses') or [],
            'ask': guidance.get('suggested_question',''),
        }
    elif topic == 'data_ai':
        card_payload['sections'] = {
            'data_sources': extracted.get('current_state') or [],
            'retrieval': deep.get('hypotheses') or [],
            'evaluation': deep.get('gap', {}).get('critical_gap') if isinstance(deep.get('gap'), dict) else guidance.get('critical_gap',''),
            'ask': guidance.get('suggested_question',''),
        }
    elif topic == 'delivery_next_steps':
        card_payload['sections'] = {
            'decision': guidance.get('key_insight',''),
            'owner': '',
            'date': '',
            'next_step': guidance.get('solution_hint',''),
        }
    else:  # requirements_discovery
        card_payload['sections'] = {
            'goal': extracted.get('customer_goal') or '',
            'pain': pick_first(extracted.get('pain_points')),
            'constraints': extracted.get('constraints') or [],
            'ask': guidance.get('suggested_question',''),
        }

    # Attach to guidance; do not remove existing fields
    guidance['_card'] = card_payload
    return guidance


def _to_card(guidance: Dict[str, Any], state: Dict[str, Any], mode: str) -> Dict[str, Any]:
    # base card fields
    return {
        'card_id': str(uuid.uuid4()),
        'ts': time.time(),
        'mode': mode,
        'topic': state.get('topic','requirements_discovery'),
        'topic_confidence': state.get('topic_confidence','low'),
        'topic_source': state.get('topic_source','default'),
        'conversation_mode': state.get('mode','consultative'),
        'mode_source': state.get('mode_source','default'),
        'persona': state.get('persona','unknown'),
        'persona_source': state.get('persona_source','default'),
        'industry': state.get('industry','general'),
        'industry_confidence': state.get('industry_confidence','low'),
        'key_insight': guidance.get('key_insight',''),
        'suggested_question': guidance.get('suggested_question',''),
        'solution_hint': guidance.get('solution_hint',''),
        'critical_gap': guidance.get('critical_gap',''),
        'extracted': guidance.get('extracted', {}),
        '_deep': guidance.get('_deep'),
    }


def _merge_facts(existing: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(existing or {})
    if new.get('customer_goal'):
        out['customer_goal'] = new.get('customer_goal')
    for k in ['pain_points','constraints','current_state','open_questions']:
        items = new.get(k)
        if not items:
            continue
        if not isinstance(items, list):
            items = [items]
        out.setdefault(k, [])
        for it in items:
            if it and it not in out[k]:
                out[k].append(it)
    return out


def _safe_json(text: str):
    try:
        t = text.strip()
        if t.startswith('```'):
            t = t.split('\n', 1)[-1]
            if t.endswith('```'):
                t = t.rsplit('```', 1)[0]
        return json.loads(t)
    except Exception:
        return None


def _fallback_guidance(raw: str) -> Dict[str, Any]:
    return {
        'key_insight': 'Conversation in progress; capture more details.',
        'suggested_question': 'Could you describe the current system and what success looks like?',
        'solution_hint': 'Clarify requirements and constraints before selecting Foundry services.',
        'critical_gap': 'Need clearer requirements.',
        'extracted': {},
        '_raw': raw,
    }
