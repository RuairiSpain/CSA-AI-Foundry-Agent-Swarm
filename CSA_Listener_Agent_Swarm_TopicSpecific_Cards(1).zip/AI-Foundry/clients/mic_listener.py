"""CSA Listener mic client (topic-aware auto-mode).

Commands:
- h : history
- m exec|tech|consult : manual mode
- p vp|lead|grad : manual persona
- auto on|off : enable/disable auto for mode/persona/topic
- pin <card_id> : pin a card
- t : talk track for pinned/last

"""

import os
import json
import asyncio

import azure.cognitiveservices.speech as speechsdk
import websockets

SERVER_WS = os.getenv('LISTENER_WS','ws://127.0.0.1:8001/listener/ws')
SPEECH_KEY = os.getenv('SPEECH_KEY')
SPEECH_REGION = os.getenv('SPEECH_REGION')
LANG = os.getenv('SPEECH_LANG','en-US')

MODE_MAP = {'exec':'executive','tech':'technical','consult':'consultative'}
P_MAP = {'vp':'director_vp','lead':'tech_lead','grad':'graduate'}

async def main():
    if not SPEECH_KEY or not SPEECH_REGION:
        raise SystemExit('Set SPEECH_KEY and SPEECH_REGION')

    async with websockets.connect(SERVER_WS) as ws:
        await ws.send(json.dumps({}))
        msg = json.loads(await ws.recv())
        session_id = msg.get('session_id')
        print('Session:', session_id)

        speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
        speech_config.speech_recognition_language = LANG
        audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
        recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)

        def on_recognizing(evt):
            t = evt.result.text
            if t:
                asyncio.create_task(ws.send(json.dumps({'session_id': session_id,'text': t,'speaker':'customer','is_final': False})))

        def on_recognized(evt):
            t = evt.result.text
            if t:
                asyncio.create_task(ws.send(json.dumps({'session_id': session_id,'text': t,'speaker':'customer','is_final': True})))

        recognizer.recognizing.connect(on_recognizing)
        recognizer.recognized.connect(on_recognized)
        recognizer.start_continuous_recognition()

        async def keyboard():
            while True:
                s = await asyncio.get_event_loop().run_in_executor(None, input)
                parts = s.strip().split()
                if not parts:
                    continue
                cmd = parts[0].lower()
                if cmd == 'h':
                    await ws.send(json.dumps({'type':'history','session_id': session_id,'limit': 8}))
                elif cmd == 'm' and len(parts)>1:
                    m = MODE_MAP.get(parts[1].lower(), parts[1].lower())
                    await ws.send(json.dumps({'type':'set','session_id': session_id,'mode': m}))
                elif cmd == 'p' and len(parts)>1:
                    p = P_MAP.get(parts[1].lower(), parts[1].lower())
                    await ws.send(json.dumps({'type':'set','session_id': session_id,'persona': p}))
                elif cmd == 'auto' and len(parts)>1:
                    v = parts[1].lower() in ('on','true','1','yes')
                    await ws.send(json.dumps({'type':'set','session_id': session_id,'auto_mode': v,'auto_persona': v,'auto_topic': v}))
                elif cmd == 'pin' and len(parts)>1:
                    await ws.send(json.dumps({'type':'pin','session_id': session_id,'card_id': parts[1]}))
                elif cmd == 't':
                    await ws.send(json.dumps({'type':'talktrack','session_id': session_id}))

        asyncio.create_task(keyboard())

        try:
            while True:
                data = json.loads(await ws.recv())
                t = data.get('type')
                if t == 'guidance':
                    print('
--- CSA Card ---')
                    print('id:', data.get('card_id'), 'route:', data.get('mode'), 'topic:', data.get('topic'), 'style:', data.get('conversation_mode'), f"({data.get('mode_source')})")
                    if data.get('_style_switch'):
                        sw = data.get('_style_switch')
                        print('AUTO SWITCH ->', sw.get('topic'), sw.get('mode'), sw.get('persona'), sw.get('confidence'), 'cues:', ', '.join((sw.get('cues') or [])[:6]))
                    print('Insight:', data.get('key_insight'))
                    print('Ask:', data.get('suggested_question'))
                    print('Hint:', data.get('solution_hint'))
                elif t == 'history':
                    print('
--- Card History ---')
                    for c in data.get('cards', []):
                        print(f"[{c.get('card_id')}] ({c.get('topic')}/{c.get('conversation_mode')}) {c.get('key_insight')}")
                elif t == 'pin_ok':
                    print('Pinned:', (data.get('pinned') or {}).get('card_id'))
                elif t == 'talktrack':
                    print('
--- Talk Track ---')
                    for line in data.get('talk_track', []):
                        print('-', line)
                    print('One-liner:', data.get('one_liner'))
                elif t == 'set_ok':
                    print('Set:', data.get('mode'), data.get('persona'), data.get('topic'), 'auto:', data.get('auto_mode'), data.get('auto_persona'), data.get('auto_topic'))
        finally:
            recognizer.stop_continuous_recognition()

if __name__ == '__main__':
    asyncio.run(main())

# NOTE: This client can print the _card payload if present.
