# CSA Listener — Topic-specific card formats

Adds a `_card` object to each guidance response so a UI can render different card layouts per topic.

- Still returns standard fields: key_insight / suggested_question / solution_hint / critical_gap
- Adds `_card.schema`, `_card.title`, and `_card.sections`

Grounded in the discovery-category approach used in <File>CSA Customer Copilot Prompts</File>.citeturn23search570
