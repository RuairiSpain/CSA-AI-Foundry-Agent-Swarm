# CSA Listener — Topic-specific cards

This version adds:
- `_card` structured payload per topic
- stable schemas for UI rendering
- does not remove existing fields (key_insight, suggested_question, solution_hint)

The question category structure aligns with the pillar-based discovery categories in <File>CSA Customer Copilot Prompts</File>.citeturn23search570
