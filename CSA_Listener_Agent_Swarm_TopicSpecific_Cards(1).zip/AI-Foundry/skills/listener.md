# CSA Listener — Topic-specific card formats

Adds `_card` payload to each guidance card with a stable schema per topic.

- `_card.schema`: csa.card.<topic>.v1
- `_card.title`: human title
- `_card.sections`: topic-specific fields

Examples:
- security_compliance: risk / controls / ask / next_step
- architecture_networking: constraint / options / tradeoff / ask
- requirements_discovery: goal / pain / constraints / ask

This builds on the question categories used in <File>CSA Customer Copilot Prompts</File>.citeturn23search570
