# Post-meeting Teams transcript -> CSA Listener ingest
# 1) Fetch transcript content with Microsoft Graph
# 2) Parse VTT
# 3) Feed into listener via WebSocket as final utterances

import os
import json
import asyncio

import websockets

from Copilot_VSCode.teams.graph import GraphAuth, list_transcripts, download_transcript_vtt
from Copilot_VSCode.teams.vtt import parse_vtt

LISTENER_WS = os.getenv('LISTENER_WS','ws://127.0.0.1:8001/listener/ws')
ONLINE_MEETING_ID = os.getenv('TEAMS_ONLINE_MEETING_ID','')
TRANSCRIPT_ID = os.getenv('TEAMS_TRANSCRIPT_ID','')
USER_PATH = os.getenv('GRAPH_USER_PATH','/me')  # '/me' (delegated) or '/users/{id}' (app-only with policy)

async def main():
    if not ONLINE_MEETING_ID:
        raise SystemExit('Set TEAMS_ONLINE_MEETING_ID')

    auth = GraphAuth.from_env()
    token = auth.token()

    if not TRANSCRIPT_ID:
        transcripts = list_transcripts(token, ONLINE_MEETING_ID, user_path=USER_PATH)
        if not transcripts:
            raise SystemExit('No transcripts found for meeting. Ensure transcription was enabled and meeting has ended.')
        TRANSCRIPT_ID_LOCAL = transcripts[0]['id']
    else:
        TRANSCRIPT_ID_LOCAL = TRANSCRIPT_ID

    vtt = download_transcript_vtt(token, ONLINE_MEETING_ID, TRANSCRIPT_ID_LOCAL, user_path=USER_PATH)
    cues = parse_vtt(vtt)

    async with websockets.connect(LISTENER_WS) as ws:
        # create listener session
        await ws.send(json.dumps({}))
        msg = json.loads(await ws.recv())
        session_id = msg.get('session_id')
        print('Listener session:', session_id)

        for cue in cues:
            payload = {
                'session_id': session_id,
                'speaker': 'meeting',
                'text': cue.text,
                'is_final': True,
            }
            await ws.send(json.dumps(payload))
            # receive guidance
            resp = json.loads(await ws.recv())
            if resp.get('type') == 'guidance':
                print('[card]', resp.get('topic'), '-', (resp.get('key_insight') or '')[:80])

        # Generate a talk-track for last card
        await ws.send(json.dumps({'type':'talktrack','session_id': session_id}))
        t = json.loads(await ws.recv())
        if t.get('type') == 'talktrack':
            print('
Talk track:')
            for line in t.get('talk_track', []):
                print('-', line)

if __name__ == '__main__':
    asyncio.run(main())
