# CSA Listener — Teams meeting transcript integration

This build adds a post-meeting integration path:
- Fetch meeting transcripts via Microsoft Graph
- Download transcript content as VTT
- Parse cues and stream them into the Listener over WebSocket

Use this when you want meeting intelligence without building a real-time media bot.
