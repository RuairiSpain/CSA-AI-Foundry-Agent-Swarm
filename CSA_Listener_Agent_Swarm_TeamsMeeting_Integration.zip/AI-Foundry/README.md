# CSA Listener — Teams meeting integration (post-meeting transcripts)

This project integrates the CSA Listener with Microsoft Teams meetings using **post-meeting transcripts** fetched via **Microsoft Graph APIs**.

## Why post-meeting transcripts (recommended)
Microsoft explicitly supports fetching meeting transcripts *after the meeting ends* using Graph APIs. These meeting transcript APIs are described as metered and post-meeting.See Microsoft Learn for the overview of fetching meeting transcripts and recordings.
## Real-time media bots (advanced, usually not for AI agents)
Microsoft Graph cloud communications and real-time media bots can access raw audio frames in calls/meetings, but:
- Cloud communications APIs include restrictions around recording/persisting media content.
- Teams real-time media documentation notes real-time media bots are for specialised scenarios and are **not recommended for AI agent scenarios**.

So for “CSA listener / agent assistant” use-cases, post-meeting transcript ingestion is the pragmatic path.

## What’s included
- Listener server: WebSocket `/listener/ws` for ingesting text and emitting cards
- Teams transcript ingestion client: `clients/teams_transcript_ingest.py`
  - Lists transcripts for an onlineMeeting
  - Downloads transcript content in VTT
  - Parses VTT and sends each cue into the listener session

## Configure
Set these environment variables:

### Listener + Foundry
- `FOUNDRY_PROJECT_ENDPOINT` (optional)
- `PRIMARY_MODEL`
- `LISTENER_TALKTRACK_LLM=true` (LLM-generated talk-tracks)

### Azure Speech (optional for local mic)
- `SPEECH_KEY`
- `SPEECH_REGION`

### Microsoft Graph (Teams transcripts)
- `AZURE_TENANT_ID`
- `AZURE_CLIENT_ID`
- `AZURE_CLIENT_SECRET`
- `TEAMS_ONLINE_MEETING_ID`
- `TEAMS_TRANSCRIPT_ID` (optional; if omitted, uses the first transcript)
- `GRAPH_USER_PATH` (default `/me`)

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m uvicorn AI_Foundry.server.app:app --host 127.0.0.1 --port 8001

# then ingest a Teams transcript into a new listener session
python clients/teams_transcript_ingest.py
```
