from __future__ import annotations
import os, json, time, uuid
from typing import Any, Dict, List, Tuple
from .models import FoundryModelClient
from .prompts import (MODE_GUIDANCE,PERSONA_GUIDANCE,INDUSTRY_GUIDANCE,LISTENER_FAST_SYSTEM,TALKTRACK_SYSTEM)

TOPIC_CUES={
 'security_compliance':['security','compliance','gdpr','hipaa','pci','audit','pii','encryption','key vault','defender','purview'],
 'governance_risk':['governance','risk','approval','guardrail','responsible ai'],
 'cost_finops':['cost','budget','finops','spend','pricing','tco','roi'],
 'architecture_networking':['vnet','private endpoint','private link','dns','expressroute','firewall','apim','network'],
 'operations_observability':['observability','monitor','app insights','log analytics','kql','alerts','slo','incident','rto','rpo'],
 'data_ai':['rag','retrieval','vector','embeddings','search','fabric','evaluation','grounding'],
 'delivery_next_steps':['next step','workshop','vbd','pilot','poc','timeline','milestone','scope','action item'],
 'requirements_discovery':['use case','requirements','success criteria','pain point','goal','users','workflow'],
}
TOPIC_TO_MODE={'security_compliance':'executive','governance_risk':'executive','cost_finops':'executive','delivery_next_steps':'executive','architecture_networking':'technical','operations_observability':'technical','data_ai':'technical','requirements_discovery':'consultative'}
CARD_TITLES={'security_compliance':'Security & Compliance','governance_risk':'Governance & Risk','cost_finops':'Cost & FinOps','architecture_networking':'Architecture & Networking','operations_observability':'Operations & Observability','data_ai':'Data & AI','delivery_next_steps':'Delivery Next Steps','requirements_discovery':'Requirements Discovery'}

class ListenerEngine:
    def __init__(self):
        self.primary_model=os.getenv('PRIMARY_MODEL','gpt-5-mini')
        self.project_endpoint=os.getenv('FOUNDRY_PROJECT_ENDPOINT','')
        self.auto_lock_seconds=float(os.getenv('LISTENER_AUTO_LOCK_SECONDS','20'))
        self.deep_on_final=os.getenv('LISTENER_DEEP_ON_FINAL','true').lower()=='true'
        self.use_llm_talktrack=os.getenv('LISTENER_TALKTRACK_LLM','true').lower()=='true'

    def _client(self)->FoundryModelClient:
        return FoundryModelClient(project_endpoint=self.project_endpoint, model=self.primary_model)

    def _window(self, state:Dict[str,Any], n:int=25)->str:
        turns=state.get('transcript',[])[-n:]
        return '
'.join([f"{t['speaker']}: {t['text']}" for t in turns if t.get('text')])

    def _det_topic(self, window_lower:str, facts_lower:str):
        best=('requirements_discovery',0,[])
        for topic,cues in TOPIC_CUES.items():
            hits=[c for c in cues if c in window_lower or c in facts_lower]
            if len(hits)>best[1]: best=(topic,len(hits),hits)
        topic,score,hits=best
        conf='high' if score>=3 else 'medium' if score==2 else 'low'
        if score==0: topic='requirements_discovery'; hits=[]
        return topic, conf, hits

    def _maybe_auto_style(self, state:Dict[str,Any])->Dict[str,Any]:
        now=time.time()
        if (now-float(state.get('last_style_change_ts',0.0) or 0.0))<self.auto_lock_seconds:
            return {'changed':False}
        window=self._window(state); wl=window.lower(); fl=json.dumps(state.get('facts',{}),ensure_ascii=False).lower()
        topic, conf, tcues=self._det_topic(wl,fl)
        mode=TOPIC_TO_MODE.get(topic,'consultative')
        changed=False
        if state.get('auto_topic',True) and topic!=state.get('topic') and state.get('topic_source')!='manual':
            state['topic']=topic; state['topic_confidence']=conf; state['topic_source']='auto'; changed=True
        if state.get('auto_mode',True) and mode!=state.get('mode') and state.get('mode_source')!='manual':
            state['mode']=mode; state['mode_source']='auto'; changed=True
        if changed: state['last_style_change_ts']=now
        return {'changed':changed,'topic':state.get('topic'),'mode':state.get('mode'),'confidence':conf,'cues':tcues[:6]}

    def process_chunk(self, state:Dict[str,Any], chunk:Dict[str,Any])->Dict[str,Any]:
        now=time.time(); state.setdefault('transcript',[]).append({'ts':now,'speaker':chunk.get('speaker','unknown'),'text':chunk.get('text',''),'final':bool(chunk.get('is_final',False))})
        style_change=self._maybe_auto_style(state)
        # Minimal guidance generation (placeholder without hallucination): reflect what we heard and ask for clarifications.
        text=(chunk.get('text') or '').strip()
        guidance={
            'card_id': str(uuid.uuid4()),
            'ts': now,
            'mode': 'fast',
            'topic': state.get('topic','requirements_discovery'),
            'conversation_mode': state.get('mode','consultative'),
            'persona': state.get('persona','unknown'),
            'industry': state.get('industry','general'),
            'key_insight': (text[:180] + '…') if len(text)>180 else text,
            'suggested_question': 'What outcome are you aiming for, and what constraints matter most?',
            'solution_hint': 'If you share the current state and constraints, we can map an Azure AI Foundry + security/network approach.',
            'critical_gap': 'Need current state, success criteria, and constraints.',
            'extracted': state.get('facts',{}),
        }
        guidance['_card'] = _apply_card_format(guidance, state)
        if style_change.get('changed'):
            guidance['_style_switch']=style_change
        state.setdefault('cards',[]).append(guidance)
        state['last_guidance']=guidance
        return {'state':state,'guidance':guidance}

    def talk_track(self, state:Dict[str,Any], card:Dict[str,Any], mode:str|None=None, persona:str|None=None)->Dict[str,Any]:
        if mode: state['mode']=mode; state['mode_source']='manual'
        if persona: state['persona']=persona; state['persona_source']='manual'

        if self.use_llm_talktrack:
            client=self._client()
            header=f"Mode: {state.get('mode')}
Topic: {state.get('topic')}
Persona: {state.get('persona')}
"
            payload={'card':card}
            raw=client.ask(TALKTRACK_SYSTEM, header + "
Card:
" + json.dumps(payload,ensure_ascii=False) + "
Return STRICT JSON.")
            out=_safe_json(raw)
            if out and isinstance(out.get('talk_track'), list):
                return out

        # deterministic fallback
        ask=card.get('suggested_question','')
        hint=card.get('solution_hint','')
        ins=card.get('key_insight','')
        lines=[f"Based on what you’ve said, {ins or 'here’s what I’m hearing.'}", f"Could you clarify: {ask or 'what success looks like?'}", f"One direction we can explore is: {hint or 'an Azure approach that matches constraints.'}", "Does that align with your priorities?"]
        return {'talk_track':lines,'one_liner':ask}


def _apply_card_format(guidance:Dict[str,Any], state:Dict[str,Any])->Dict[str,Any]:
    topic=state.get('topic','requirements_discovery')
    title=CARD_TITLES.get(topic,'Requirements Discovery')
    card={'schema':f"csa.card.{topic}.v1",'title':title,'topic':topic,'sections':{}}
    card['sections']={'ask':guidance.get('suggested_question',''),'next_step':guidance.get('solution_hint','')}
    return card


def _safe_json(text:str):
    try:
        t=text.strip()
        if t.startswith('```'):
            t=t.split('
',1)[-1]
            if t.endswith('```'): t=t.rsplit('```',1)[0]
        return json.loads(t)
    except Exception:
        return None
