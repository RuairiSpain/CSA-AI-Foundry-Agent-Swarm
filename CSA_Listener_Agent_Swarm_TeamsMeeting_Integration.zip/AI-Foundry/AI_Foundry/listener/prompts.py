MODE_GUIDANCE={'consultative':'Tone: curious, open-ended, collaborative.','executive':'Tone: outcome-focused, risk-aware, concise.','technical':'Tone: implementation-aware, precise.'}
PERSONA_GUIDANCE={'director_vp':'Audience: Director/VP.','tech_lead':'Audience: Tech lead.','graduate':'Audience: Implementer/new graduate.','unknown':'Audience: mixed.'}
INDUSTRY_GUIDANCE={'general':'Industry: general enterprise.','healthcare':'Industry: healthcare.','finance':'Industry: finance.','retail':'Industry: retail.','manufacturing':'Industry: manufacturing.','energy':'Industry: energy.','public_sector':'Industry: public sector.','education':'Industry: education.','telco':'Industry: telco.'}
LISTENER_FAST_SYSTEM=(
"You are a real-time CSA Listener. Produce ONE guidance card. Return STRICT JSON with keys: key_insight, suggested_question, solution_hint, critical_gap, extracted." )
TOPIC_STYLE_CLASSIFIER_SYSTEM=(
"Return STRICT JSON: {topic:[security_compliance,governance_risk,cost_finops,architecture_networking,operations_observability,data_ai,delivery_next_steps,requirements_discovery], mode: consultative|executive|technical, persona: director_vp|tech_lead|graduate|unknown, confidence: low|medium|high, cues:[...]}" )
INDUSTRY_CLASSIFIER_SYSTEM=(
"Return STRICT JSON: {industry:[general,healthcare,finance,retail,manufacturing,energy,public_sector,education,telco], confidence: low|medium|high, signals:[...]}" )
INDUSTRY_ADVISOR_SYSTEM=(
"Return STRICT JSON: {industry_focus:[...], industry_questions:[...], industry_risks:[...], industry_services:[...]}" )
LISTENER_EXTRACT_SYSTEM="Return STRICT JSON keys: customer_goal, pain_points[], constraints[], current_state[]."
DISCOVERY_COACH_SYSTEM="Return STRICT JSON: {questions:[...]}"
SOLUTION_ARCH_SYSTEM="Return STRICT JSON: {hypotheses:[...]}"
OPPORTUNITY_SYSTEM="Return STRICT JSON: {opportunities:[...]}"
GAP_SYSTEM="Return STRICT JSON: {critical_gap:string, why_it_matters:string, question:string}"
WHISPER_SYSTEM="Return STRICT JSON keys: key_insight, suggested_question, solution_hint, critical_gap, extracted."
TALKTRACK_SYSTEM="Return STRICT JSON: {talk_track:[...], one_liner:string}."
