from __future__ import annotations
import time
from typing import Any, Dict, List, Optional
VALID_MODES = {"consultative","executive","technical"}
VALID_PERSONAS = {"director_vp","tech_lead","graduate","unknown"}

class SessionStore:
    def __init__(self):
        self._sessions: Dict[str, Dict[str, Any]] = {}

    def create(self, session_id: str) -> None:
        now=time.time()
        self._sessions[session_id]={
            'created':now,'updated':now,'transcript':[],
            'facts':{'customer_goal':None,'pain_points':[],'constraints':[],'current_state':[],'open_questions':[]},
            'mode':'consultative','persona':'unknown','industry':'general','industry_confidence':'low',
            'topic':'requirements_discovery','topic_confidence':'low',
            'auto_mode':True,'auto_persona':True,'auto_topic':True,
            'mode_source':'default','persona_source':'default','topic_source':'default',
            'last_style_change_ts':0.0,
            'cards':[],'pinned_card_id':None,'last_guidance':{},
        }

    def count(self)->int:
        return len(self._sessions)

    def get(self, session_id:str)->Dict[str,Any]:
        if session_id not in self._sessions:
            self.create(session_id)
        return self._sessions[session_id]

    def set(self, session_id:str, state:Dict[str,Any])->None:
        state['updated']=time.time(); self._sessions[session_id]=state

    def reset(self, session_id:str)->None:
        self.create(session_id)

    def list_cards(self, session_id:str, limit:int=10, before_card_id:Optional[str]=None)->List[Dict[str,Any]]:
        cards=self.get(session_id).get('cards',[])
        if before_card_id:
            idx=next((i for i,c in enumerate(cards) if c.get('card_id')==before_card_id), None)
            if idx is None:
                return cards[-limit:]
            cards=cards[:idx]
        return cards[-limit:]

    def set_mode(self, session_id:str, mode:str, source:str='manual')->str:
        st=self.get(session_id); mode=(mode or '').strip().lower()
        if mode in VALID_MODES:
            st['mode']=mode; st['mode_source']=source; st['updated']=time.time()
        return st['mode']

    def set_persona(self, session_id:str, persona:str, source:str='manual')->str:
        st=self.get(session_id); persona=(persona or '').strip().lower()
        if persona in VALID_PERSONAS:
            st['persona']=persona; st['persona_source']=source; st['updated']=time.time()
        return st['persona']

    def set_auto(self, session_id:str, auto_mode:bool|None=None, auto_persona:bool|None=None, auto_topic:bool|None=None)->Dict[str,Any]:
        st=self.get(session_id)
        if auto_mode is not None: st['auto_mode']=bool(auto_mode)
        if auto_persona is not None: st['auto_persona']=bool(auto_persona)
        if auto_topic is not None: st['auto_topic']=bool(auto_topic)
        st['updated']=time.time()
        return {'auto_mode':st['auto_mode'],'auto_persona':st['auto_persona'],'auto_topic':st['auto_topic']}

    def pin(self, session_id:str, card_id:str)->Dict[str,Any]:
        st=self.get(session_id)
        for c in st.get('cards',[]):
            if c.get('card_id')==card_id:
                st['pinned_card_id']=card_id; st['updated']=time.time(); return c
        return {}

    def get_pinned(self, session_id:str)->Dict[str,Any]:
        st=self.get(session_id); cid=st.get('pinned_card_id')
        if not cid: return {}
        for c in st.get('cards',[]):
            if c.get('card_id')==cid: return c
        return {}
