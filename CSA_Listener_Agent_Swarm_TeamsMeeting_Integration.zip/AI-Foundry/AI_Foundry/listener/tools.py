from __future__ import annotations
import uuid
from typing import Any, Dict
from .state import SessionStore
from .engine import ListenerEngine
STORE=SessionStore(); ENGINE=ListenerEngine()

def listener_start(arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
    session_id=str(uuid.uuid4()); STORE.create(session_id); return {'session_id':session_id}

def listener_ingest(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']
    st=STORE.get(sid)
    out=ENGINE.process_chunk(st,{'text':arguments['text'],'speaker':arguments.get('speaker','unknown'),'is_final':bool(arguments.get('is_final',False)),'force_deep':bool(arguments.get('force_deep',False))})
    STORE.set(sid,out['state']); return out['guidance']

def listener_talktrack(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; st=STORE.get(sid)
    card=st.get('last_guidance') or {}
    out=ENGINE.talk_track(st, card, mode=arguments.get('mode'), persona=arguments.get('persona'))
    STORE.set(sid,st); return {'session_id':sid,'card_id':card.get('card_id'),**out}
