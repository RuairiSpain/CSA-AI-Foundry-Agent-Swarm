from __future__ import annotations
import importlib
import os
from dataclasses import dataclass
from typing import Any, Dict, List
import yaml
from jsonschema import validate, ValidationError

@dataclass
class ToolDef:
    name: str
    title: str
    description: str
    adapter: str
    input_schema: Dict[str, Any]

class ToolRegistry:
    def __init__(self, tools_yaml_path: str):
        with open(tools_yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        self._tools: Dict[str, ToolDef] = {}
        for t in data.get("tools", []):
            td = ToolDef(
                name=t["name"],
                title=t.get("title", t["name"]),
                description=t.get("description", ""),
                adapter=t["adapter"],
                input_schema=t.get("inputSchema", {"type": "object", "properties": {}}),
            )
            self._tools[td.name] = td
        self._resources = data.get("resources", [])
        self._prompts = data.get("prompts", [])

    def list_tools(self) -> List[Dict[str, Any]]:
        return [
            {"name": td.name, "title": td.title, "description": td.description, "inputSchema": td.input_schema}
            for td in self._tools.values()
        ]

    def get_tool(self, name: str) -> ToolDef:
        if name not in self._tools:
            raise KeyError(f"Unknown tool: {name}")
        return self._tools[name]

    def validate_args(self, tool: ToolDef, arguments: Dict[str, Any]) -> None:
        try:
            validate(instance=arguments, schema=tool.input_schema)
        except ValidationError as e:
            raise ValueError(str(e))

    def load_callable(self, adapter_path: str):
        if ":" in adapter_path:
            mod, attr = adapter_path.split(":", 1)
        else:
            mod, attr = adapter_path, None
        module = importlib.import_module(mod)
        if not attr:
            return module
        target = module
        for part in attr.split("."):
            target = getattr(target, part)
        return target

    def list_resources(self) -> List[Dict[str, Any]]:
        return self._resources

    def read_resource(self, uri: str) -> Dict[str, Any]:
        if uri.startswith("file://"):
            path = uri[len("file://") :]
            if not os.path.exists(path):
                raise FileNotFoundError(path)
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            mime = "text/plain"
            if path.endswith(".yaml") or path.endswith(".yml"):
                mime = "text/yaml"
            if path.endswith(".md"):
                mime = "text/markdown"
            return {"uri": uri, "mimeType": mime, "text": text}
        raise FileNotFoundError(uri)

    def list_prompts(self) -> List[Dict[str, Any]]:
        return self._prompts

    def get_prompt(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        for p in self._prompts:
            if p.get("name") == name:
                template_path = p.get("templateFile")
                if not template_path:
                    break
                with open(template_path, "r", encoding="utf-8") as f:
                    template = f.read()
                rendered = template.format(**arguments)
                return {"description": p.get("description", ""), "messages": [{"role": "user", "content": {"type": "text", "text": rendered}}]}
        raise KeyError(f"Unknown prompt: {name}")
