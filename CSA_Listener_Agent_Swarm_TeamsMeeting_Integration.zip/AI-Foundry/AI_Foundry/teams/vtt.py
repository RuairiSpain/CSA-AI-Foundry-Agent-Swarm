from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class VttCue:
    start: str
    end: str
    text: str

TIME_RE = re.compile(r"^(\d\d:\d\d:\d\d\.\d\d\d)\s+-->\s+(\d\d:\d\d:\d\d\.\d\d\d)")


def parse_vtt(vtt: str) -> List[VttCue]:
    lines = [l.rstrip('
') for l in (vtt or '').splitlines()]
    cues: List[VttCue] = []
    i = 0
    # Skip WEBVTT header
    while i < len(lines) and lines[i].strip() == '':
        i += 1
    if i < len(lines) and lines[i].strip().upper().startswith('WEBVTT'):
        i += 1
    while i < len(lines):
        # skip blank / cue number
        if lines[i].strip() == '' or lines[i].strip().isdigit():
            i += 1
            continue
        m = TIME_RE.match(lines[i].strip())
        if not m:
            i += 1
            continue
        start, end = m.group(1), m.group(2)
        i += 1
        text_lines = []
        while i < len(lines) and lines[i].strip() != '':
            text_lines.append(lines[i].strip())
            i += 1
        text = ' '.join(text_lines).strip()
        if text:
            cues.append(VttCue(start=start, end=end, text=text))
        i += 1
    return cues
