from __future__ import annotations

import os
import requests
from dataclasses import dataclass
from typing import Optional, List, Dict

from azure.identity import ClientSecretCredential

GRAPH_SCOPE = "https://graph.microsoft.com/.default"

@dataclass
class GraphAuth:
    tenant_id: str
    client_id: str
    client_secret: str

    @classmethod
    def from_env(cls) -> 'GraphAuth':
        return cls(
            tenant_id=os.getenv('AZURE_TENANT_ID',''),
            client_id=os.getenv('AZURE_CLIENT_ID',''),
            client_secret=os.getenv('AZURE_CLIENT_SECRET',''),
        )

    def token(self) -> str:
        cred = ClientSecretCredential(self.tenant_id, self.client_id, self.client_secret)
        return cred.get_token(GRAPH_SCOPE).token


def _headers(token: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {token}", "Accept": "application/json"}


def list_transcripts(token: str, online_meeting_id: str, user_path: str = "/me") -> List[Dict]:
    # Microsoft Graph transcripts are exposed per-onlineMeeting. See Graph meeting transcript APIs.
    url = f"https://graph.microsoft.com/v1.0{user_path}/onlineMeetings/{online_meeting_id}/transcripts"
    r = requests.get(url, headers=_headers(token), timeout=30)
    r.raise_for_status()
    return r.json().get('value', [])


def download_transcript_vtt(token: str, online_meeting_id: str, transcript_id: str, user_path: str = "/me") -> str:
    # Download transcript content in VTT format.
    url = f"https://graph.microsoft.com/v1.0{user_path}/onlineMeetings/{online_meeting_id}/transcripts/{transcript_id}/content?$format=text/vtt"
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=30)
    r.raise_for_status()
    return r.text
