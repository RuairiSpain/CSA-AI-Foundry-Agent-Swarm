# CSA Listener — Auto-mode switching

## Auto-mode switcher
The listener can automatically switch:
- conversation mode: consultative / executive / technical
- persona: director_vp / tech_lead / graduate

## How it decides
- Fast deterministic keyword cues (low latency)
- Optional LLM classifier refinement (higher precision)
- Lockout window prevents rapid flipping between modes
- Manual selections are respected (auto will not override manual)
