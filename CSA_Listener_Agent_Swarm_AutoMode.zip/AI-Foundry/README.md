# CSA Listener — Auto-mode switcher

This pack adds an auto-mode switcher on top of the adaptive listener:
- switches consultative/executive/technical based on cues
- switches persona based on cues
- supports manual override and auto disable

Environment:
- LISTENER_AUTO_LOCK_SECONDS=20
- LISTENER_AUTO_LLM=true

WebSocket commands:
- {type:'set', auto_mode:true, auto_persona:true}
- {type:'set', mode:'technical'} (manual)
