# CSA Listener — Auto-mode

Adds:
- Auto mode/persona switching based on conversation cues
- Lockout (LISTENER_AUTO_LOCK_SECONDS) to avoid flapping
- Optional LLM refinement (LISTENER_AUTO_LLM)
- Tools to enable/disable auto switching

In cards:
- conversation_mode + mode_source
- persona + persona_source
- optional _style_switch metadata when an auto switch happens
