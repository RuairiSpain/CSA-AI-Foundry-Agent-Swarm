from __future__ import annotations

import os
import json
import time
import uuid
from typing import Any, Dict

from .models import FoundryModelClient
from .prompts import (
    MODE_GUIDANCE,
    PERSONA_GUIDANCE,
    INDUSTRY_GUIDANCE,
    LISTENER_FAST_SYSTEM,
    STYLE_CLASSIFIER_SYSTEM,
    INDUSTRY_CLASSIFIER_SYSTEM,
    INDUSTRY_ADVISOR_SYSTEM,
    LISTENER_EXTRACT_SYSTEM,
    DISCOVERY_COACH_SYSTEM,
    SOLUTION_ARCH_SYSTEM,
    OPPORTUNITY_SYSTEM,
    GAP_SYSTEM,
    WHISPER_SYSTEM,
    TALKTRACK_SYSTEM,
)

# Keyword cues (fast and deterministic)
EXEC_CUES = [
    "budget",
    "roi",
    "business case",
    "timeline",
    "deadline",
    "vp",
    "director",
    "board",
    "strategy",
    "cost",
    "value",
    "procurement",
    "sponsor",
]
TECH_CUES = [
    "vnet",
    "private endpoint",
    "private link",
    "dns",
    "rbac",
    "entra",
    "token",
    "api management",
    "apim",
    "aks",
    "kubernetes",
    "latency",
    "throughput",
    "availability",
    "dr",
    "rto",
    "rpo",
    "terraform",
    "bicep",
    "arm",
    "sdk",
    "observability",
    "app insights",
    "monitor",
    "log analytics",
    "kql",
]
VP_CUES = ["vp", "vice president", "director", "cxo", "cio", "cto", "ciso", "head of"]
LEAD_CUES = ["tech lead", "architect", "engineer", "developer lead", "platform team", "sre"]
GRAD_CUES = ["graduate", "junior", "new to", "first time", "learning"]


class ListenerEngine:
    def __init__(self):
        self.primary_model = os.getenv("PRIMARY_MODEL", "gpt-5-mini")
        self.project_endpoint = os.getenv("FOUNDRY_PROJECT_ENDPOINT", "")
        self.deep_on_final = os.getenv("LISTENER_DEEP_ON_FINAL", "true").lower() == "true"
        self.pause_seconds = float(os.getenv("LISTENER_DEEP_PAUSE_SECONDS", "8"))
        self.auto_lock_seconds = float(os.getenv("LISTENER_AUTO_LOCK_SECONDS", "20"))
        self.auto_llm = os.getenv("LISTENER_AUTO_LLM", "true").lower() == "true"

    def _client(self) -> FoundryModelClient:
        return FoundryModelClient(project_endpoint=self.project_endpoint, model=self.primary_model)

    def _window(self, state: Dict[str, Any], n: int = 25) -> str:
        turns = state.get("transcript", [])[-n:]
        return "
".join([f"{t['speaker']}: {t['text']}" for t in turns if t.get("text")])

    def _context_header(self, state: Dict[str, Any]) -> str:
        mode = state.get("mode", "consultative")
        persona = state.get("persona", "unknown")
        industry = state.get("industry", "general")
        return (
            f"Mode guidance: {MODE_GUIDANCE.get(mode, MODE_GUIDANCE['consultative'])}
"
            f"Persona guidance: {PERSONA_GUIDANCE.get(persona, PERSONA_GUIDANCE['unknown'])}
"
            f"Industry guidance: {INDUSTRY_GUIDANCE.get(industry, INDUSTRY_GUIDANCE['general'])}
"
        )

    def _maybe_auto_style(self, state: Dict[str, Any]) -> Dict[str, Any]:
        # Auto-switch mode/persona using cues, with lockout to avoid flapping.
        now = time.time()
        if not state.get("auto_mode", True) and not state.get("auto_persona", True):
            return {"changed": False}

        # Respect manual selections: auto will not override manual.
        auto_mode_allowed = bool(state.get("auto_mode", True)) and state.get("mode_source") != "manual"
        auto_persona_allowed = bool(state.get("auto_persona", True)) and state.get("persona_source") != "manual"
        if not auto_mode_allowed and not auto_persona_allowed:
            return {"changed": False}

        last_change = float(state.get("last_style_change_ts", 0.0) or 0.0)
        if (now - last_change) < self.auto_lock_seconds:
            return {"changed": False}

        window = self._window(state).lower()

        exec_hits = [k for k in EXEC_CUES if k in window]
        tech_hits = [k for k in TECH_CUES if k in window]

        mode_guess = "consultative"
        confidence = "low"
        cues = []
        if len(exec_hits) > len(tech_hits) and exec_hits:
            mode_guess = "executive"
            cues += exec_hits
            confidence = "medium" if len(exec_hits) >= 2 else "low"
        elif len(tech_hits) > len(exec_hits) and tech_hits:
            mode_guess = "technical"
            cues += tech_hits
            confidence = "medium" if len(tech_hits) >= 2 else "low"

        persona_guess = "unknown"
        vp_hits = [k for k in VP_CUES if k in window]
        lead_hits = [k for k in LEAD_CUES if k in window]
        grad_hits = [k for k in GRAD_CUES if k in window]
        if vp_hits:
            persona_guess = "director_vp"
            cues += vp_hits
        elif lead_hits:
            persona_guess = "tech_lead"
            cues += lead_hits
        elif grad_hits:
            persona_guess = "graduate"
            cues += grad_hits

        # Optional LLM refinement
        if self.auto_llm:
            llm = None
            try:
                raw = self._client().ask(STYLE_CLASSIFIER_SYSTEM, f"Window:
{self._window(state)}
Return STRICT JSON.")
                llm = _safe_json(raw)
            except Exception:
                llm = None
            if isinstance(llm, dict) and llm.get("confidence") in ("medium", "high"):
                if llm.get("mode") in ("consultative", "executive", "technical"):
                    mode_guess = llm["mode"]
                if llm.get("persona") in ("director_vp", "tech_lead", "graduate", "unknown"):
                    persona_guess = llm["persona"]
                confidence = llm.get("confidence", confidence)
                if isinstance(llm.get("cues"), list):
                    cues = llm.get("cues")

        changed = False
        if auto_mode_allowed and mode_guess != state.get("mode"):
            state["mode"] = mode_guess
            state["mode_source"] = "auto"
            changed = True
        if auto_persona_allowed and persona_guess != state.get("persona"):
            state["persona"] = persona_guess
            state["persona_source"] = "auto"
            changed = True
        if changed:
            state["last_style_change_ts"] = now

        return {"changed": changed, "mode": state.get("mode"), "persona": state.get("persona"), "confidence": confidence, "cues": cues}

    def process_chunk(self, state: Dict[str, Any], chunk: Dict[str, Any]) -> Dict[str, Any]:
        now = time.time()
        state.setdefault("transcript", []).append(
            {"ts": now, "speaker": chunk.get("speaker", "unknown"), "text": chunk.get("text", ""), "final": bool(chunk.get("is_final", False))}
        )

        style_change = self._maybe_auto_style(state)

        is_final = bool(chunk.get("is_final", False))
        force_deep = bool(chunk.get("force_deep", False))

        route = "fast"
        if force_deep:
            route = "deep"
        elif is_final and self.deep_on_final:
            route = "deep"
        else:
            last_final_ts = None
            for t in reversed(state["transcript"]):
                if t.get("final"):
                    last_final_ts = t.get("ts")
                    break
            if last_final_ts and (now - last_final_ts) >= self.pause_seconds:
                route = "deep"

        out = self._deep(state) if route == "deep" else self._fast(state)
        if style_change.get("changed"):
            out["guidance"]["_style_switch"] = style_change
        return out

    def _fast(self, state: Dict[str, Any]) -> Dict[str, Any]:
        client = self._client()
        header = self._context_header(state)
        facts = json.dumps(state.get("facts", {}), ensure_ascii=False)
        window = self._window(state)
        raw = client.ask(LISTENER_FAST_SYSTEM, header + f"
Running facts:
{facts}

Window:
{window}
Return STRICT JSON.")
        guidance = _safe_json(raw) or _fallback_guidance(raw)
        extracted = guidance.get("extracted", {}) or {}
        state["facts"] = _merge_facts(state.get("facts", {}), extracted)
        card = _to_card(guidance, state, mode="fast")
        state.setdefault("cards", []).append(card)
        state["last_guidance"] = card
        return {"state": state, "guidance": card}

    def _deep(self, state: Dict[str, Any]) -> Dict[str, Any]:
        client = self._client()
        header = self._context_header(state)
        facts0 = state.get("facts", {})
        window = self._window(state)

        ind_raw = client.ask(INDUSTRY_CLASSIFIER_SYSTEM, header + f"
Window:
{window}
Return STRICT JSON.")
        ind = _safe_json(ind_raw) or {"industry": "general", "confidence": "low", "signals": []}
        state["industry"] = ind.get("industry", "general")
        state["industry_confidence"] = ind.get("confidence", "low")

        header = self._context_header(state)

        ex_raw = client.ask(
            LISTENER_EXTRACT_SYSTEM,
            header + f"
Facts so far:
{json.dumps(facts0, ensure_ascii=False)}

Window:
{window}
Return STRICT JSON.",
        )
        extracted = _safe_json(ex_raw) or {}
        facts = _merge_facts(facts0, extracted)
        state["facts"] = facts

        ia_raw = client.ask(
            INDUSTRY_ADVISOR_SYSTEM,
            header + f"
Facts:
{json.dumps(facts, ensure_ascii=False)}

Window:
{window}
Return STRICT JSON.",
        )
        industry_pack = _safe_json(ia_raw) or {}

        q_raw = client.ask(DISCOVERY_COACH_SYSTEM, header + f"
Facts:
{json.dumps(facts, ensure_ascii=False)}

Window:
{window}")
        questions = (_safe_json(q_raw) or {}).get("questions", [])

        h_raw = client.ask(SOLUTION_ARCH_SYSTEM, header + f"
Facts:
{json.dumps(facts, ensure_ascii=False)}

Window:
{window}")
        hypotheses = (_safe_json(h_raw) or {}).get("hypotheses", [])

        o_raw = client.ask(OPPORTUNITY_SYSTEM, header + f"
Facts:
{json.dumps(facts, ensure_ascii=False)}

Window:
{window}")
        opportunities = (_safe_json(o_raw) or {}).get("opportunities", [])

        g_raw = client.ask(GAP_SYSTEM, header + f"
Facts:
{json.dumps(facts, ensure_ascii=False)}

Window:
{window}")
        gap_obj = _safe_json(g_raw) or {}

        whisper_inputs = {
            "extracted": facts,
            "industry": {"industry": state.get("industry", "general"), "confidence": state.get("industry_confidence", "low"), "insights": industry_pack},
            "questions": questions,
            "hypotheses": hypotheses,
            "opportunities": opportunities,
            "gap": gap_obj,
        }

        w_raw = client.ask(WHISPER_SYSTEM, header + f"
Inputs:
{json.dumps(whisper_inputs, ensure_ascii=False)}
Return STRICT JSON.")
        guidance = _safe_json(w_raw) or _fallback_guidance(w_raw)
        guidance["extracted"] = facts
        guidance["_deep"] = {"industry": whisper_inputs["industry"], "questions": questions, "hypotheses": hypotheses, "opportunities": opportunities, "gap": gap_obj}

        card = _to_card(guidance, state, mode="deep")
        state.setdefault("cards", []).append(card)
        state["last_guidance"] = card
        return {"state": state, "guidance": card}

    def talk_track(self, state: Dict[str, Any], card: Dict[str, Any], mode: str | None = None, persona: str | None = None) -> Dict[str, Any]:
        client = self._client()
        if mode:
            state["mode"] = mode
            state["mode_source"] = "manual"
        if persona:
            state["persona"] = persona
            state["persona_source"] = "manual"
        header = self._context_header(state)
        payload = {"card": card, "mode": state.get("mode"), "persona": state.get("persona"), "industry": state.get("industry")}
        raw = client.ask(TALKTRACK_SYSTEM, header + f"
Card:
{json.dumps(payload, ensure_ascii=False)}
Return STRICT JSON.")
        out = _safe_json(raw)
        if out and isinstance(out.get("talk_track"), list):
            return out
        return {"talk_track": [f"Based on what you've shared, {card.get('key_insight','...')}", f"Could you clarify: {card.get('suggested_question','...')}", f"One direction we can explore is: {card.get('solution_hint','...')}", "Does that align with your priorities?"], "one_liner": card.get("suggested_question", "")}


def _to_card(guidance: Dict[str, Any], state: Dict[str, Any], mode: str) -> Dict[str, Any]:
    return {
        "card_id": str(uuid.uuid4()),
        "ts": time.time(),
        "mode": mode,
        "conversation_mode": state.get("mode", "consultative"),
        "mode_source": state.get("mode_source", "default"),
        "persona": state.get("persona", "unknown"),
        "persona_source": state.get("persona_source", "default"),
        "industry": state.get("industry", "general"),
        "industry_confidence": state.get("industry_confidence", "low"),
        "key_insight": guidance.get("key_insight", ""),
        "suggested_question": guidance.get("suggested_question", ""),
        "solution_hint": guidance.get("solution_hint", ""),
        "critical_gap": guidance.get("critical_gap", ""),
        "extracted": guidance.get("extracted", {}),
        "_deep": guidance.get("_deep"),
    }


def _merge_facts(existing: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(existing or {})
    if new.get("customer_goal"):
        out["customer_goal"] = new.get("customer_goal")
    for k in ["pain_points", "constraints", "current_state", "open_questions"]:
        items = new.get(k)
        if not items:
            continue
        if not isinstance(items, list):
            items = [items]
        out.setdefault(k, [])
        for it in items:
            if it and it not in out[k]:
                out[k].append(it)
    return out


def _safe_json(text: str):
    try:
        t = text.strip()
        if t.startswith("```"):
            t = t.split("
", 1)[-1]
            if t.endswith("```"):
                t = t.rsplit("```", 1)[0]
        return json.loads(t)
    except Exception:
        return None


def _fallback_guidance(raw: str) -> Dict[str, Any]:
    return {
        "key_insight": "Conversation in progress; capture more details.",
        "suggested_question": "Could you describe the current system and what success looks like?",
        "solution_hint": "Clarify requirements and constraints before selecting Foundry services.",
        "critical_gap": "Need clearer requirements.",
        "extracted": {},
        "_raw": raw,
    }
