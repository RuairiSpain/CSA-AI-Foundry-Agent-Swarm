from __future__ import annotations

import uuid
from typing import Any, Dict

from .state import SessionStore
from .engine import ListenerEngine

STORE = SessionStore()
ENGINE = ListenerEngine()


def listener_start(arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
    session_id = str(uuid.uuid4())
    STORE.create(session_id)
    return {"session_id": session_id}


def listener_set_mode(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    mode = arguments.get("mode", "consultative")
    current = STORE.set_mode(session_id, mode, source="manual")
    return {"session_id": session_id, "mode": current}


def listener_set_persona(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    persona = arguments.get("persona", "unknown")
    current = STORE.set_persona(session_id, persona, source="manual")
    return {"session_id": session_id, "persona": current}


def listener_set_auto(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    auto_mode = arguments.get("auto_mode")
    auto_persona = arguments.get("auto_persona")
    return {"session_id": session_id, **STORE.set_auto(session_id, auto_mode=auto_mode, auto_persona=auto_persona)}


def listener_ingest(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    if arguments.get("mode"):
        STORE.set_mode(session_id, arguments["mode"], source="manual")
    if arguments.get("persona"):
        STORE.set_persona(session_id, arguments["persona"], source="manual")

    state = STORE.get(session_id)
    out = ENGINE.process_chunk(state, {
        "text": arguments["text"],
        "speaker": arguments.get("speaker", "unknown"),
        "is_final": bool(arguments.get("is_final", False)),
        "force_deep": bool(arguments.get("force_deep", False)),
    })
    STORE.set(session_id, out["state"])
    return out["guidance"]


def listener_history(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    limit = int(arguments.get("limit", 10))
    before = arguments.get("before_card_id")
    return {"session_id": session_id, "cards": STORE.list_cards(session_id, limit=limit, before_card_id=before)}


def listener_pin(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    card_id = arguments["card_id"]
    return {"session_id": session_id, "pinned": STORE.pin(session_id, card_id)}


def listener_talktrack(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    st = STORE.get(session_id)
    card_id = arguments.get("card_id")
    card = None
    if card_id:
        for c in st.get("cards", []):
            if c.get("card_id") == card_id:
                card = c
                break
    if not card:
        card = STORE.get_pinned(session_id) or st.get("last_guidance") or {}

    out = ENGINE.talk_track(st, card, mode=arguments.get("mode"), persona=arguments.get("persona"))
    STORE.set(session_id, st)
    return {"session_id": session_id, "card_id": card.get("card_id"), **out}


def listener_get_state(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    st = STORE.get(session_id)
    return {
        "session_id": session_id,
        "mode": st.get("mode"),
        "mode_source": st.get("mode_source"),
        "persona": st.get("persona"),
        "persona_source": st.get("persona_source"),
        "industry": st.get("industry"),
        "industry_confidence": st.get("industry_confidence"),
        "auto_mode": st.get("auto_mode"),
        "auto_persona": st.get("auto_persona"),
        "facts": st.get("facts", {}),
        "pinned_card_id": st.get("pinned_card_id"),
        "last_guidance": st.get("last_guidance", {}),
    }


def listener_reset(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    STORE.reset(session_id)
    return {"session_id": session_id, "status": "reset"}
