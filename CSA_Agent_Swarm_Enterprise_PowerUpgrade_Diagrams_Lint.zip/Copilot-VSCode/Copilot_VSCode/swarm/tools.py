from __future__ import annotations

import os
from typing import Any, Dict

from Copilot_VSCode.swarm.models import FoundryModelClient
from Copilot_VSCode.swarm.core import SwarmConfig, Agent, EnterpriseOrchestrator


def _cfg() -> SwarmConfig:
    primary = os.getenv("PRIMARY_MODEL", "gpt-5-mini")
    verifier = os.getenv("VERIFIER_MODEL", "gpt-4.1")
    return SwarmConfig(primary_model=primary, verifier_model=verifier)


def _client(model: str) -> FoundryModelClient:
    endpoint = os.getenv("FOUNDRY_PROJECT_ENDPOINT", "")
    return FoundryModelClient(project_endpoint=endpoint, model=model)


def swarm_run(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    task = arguments["task"]
    scenario = arguments.get("scenario", "ai_factory_blueprint")

    primary = _client(cfg.primary_model)
    verifier = _client(cfg.verifier_model)

    specialists = [
        Agent("factory_architect", "Design the AI Factory blueprint (Models, Knowledge & Tools, Customization, Orchestration, Observability, Trust)."),
        Agent("security_network_architect", "Design mission-critical network security and secure API exposure (VNets, Private Link, APIM/WAF)."),
        Agent("diagnostics_debugger", "Debug customer problems: Azure config issues and low-quality agent outputs."),
        Agent("reliability_resilience", "Define HA/DR and operational readiness."),
        Agent("finops_cost", "Define cost controls and routing guardrails."),
        Agent("data_governance", "Define governance and safe grounding."),
        Agent("devsecops_platform", "Define CI/CD and policy-as-code."),
        Agent("threat_model_redteam", "Define threat model and red team plan."),
    ]

    principal_reviewer = Agent(
        "principal_csa_csam_reviewer",
        "You are a Principal CSA + CSAM reviewer. Critique gaps, simplify, and craft a presentation strategy for execs and builders.",
    )

    diagrammer = Agent(
        "diagrammer",
        "Create THREE Mermaid diagrams using fenced ```mermaid blocks: (1) Network & security, (2) Dataflow, (3) Control plane/ops. "
        "Use trust boundaries. Keep each diagram <= 25 lines.",
    )

    diagram_linter = Agent(
        "diagram_lint_verifier",
        "You are a Mermaid diagram linter. Validate that the output contains exactly three fenced ```mermaid blocks. "
        "For each block, check: <=25 lines, readable node names, clear trust boundaries, no broken syntax, no overly long labels. "
        "Also warn if the target might be Azure DevOps wiki (which may not support standard fenced ```mermaid) and provide the alternate ':::' style wrapper. "
        "Return: (A) Issues list, (B) Corrected diagrams if needed (otherwise repeat the original diagrams).",
    )

    report_writer = Agent(
        "professional_report_writer",
        "Produce: (1) 1-page exec brief, (2) architecture, (3) implementation plan. "
        "Insert the corrected diagrams from Context.diagram_lint (or Context.diagrams if no corrections) verbatim with one-line captions.",
    )

    orch = EnterpriseOrchestrator(cfg, primary=primary, verifier=verifier)
    return orch.run(task=task, scenario=scenario, specialists=specialists, principal_reviewer=principal_reviewer, diagrammer=diagrammer, diagram_linter=diagram_linter, report_writer=report_writer)


def diagram_lint(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    verifier = _client(cfg.verifier_model)
    diagrams = arguments["diagrams"]
    system = (
        "You are a Mermaid diagram linter. Return Issues + Corrected diagrams. "
        "If platform is Azure DevOps wiki, suggest ::: mermaid syntax."
    )
    prompt = f"Diagrams:\n{diagrams}\nReturn: (A) Issues, (B) Corrected diagrams." 
    return {"lint": verifier.ask(system, prompt)}


def diagram_generate(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    primary = _client(cfg.primary_model)
    diagram_type = arguments.get("diagram_type", "network")
    description = arguments["description"]
    system = "You generate Mermaid diagrams. Output ONLY a fenced ```mermaid block plus a short title line above it." 
    prompt = f"Diagram type: {diagram_type}\nDescription: {description}\nReturn one Mermaid diagram." 
    return {"diagram": primary.ask(system, prompt)}
