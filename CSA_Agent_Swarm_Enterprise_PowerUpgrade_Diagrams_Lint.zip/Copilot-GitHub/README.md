# Copilot-GitHub — Enterprise CSA Agent Swarm (Diagrams + Lint)
