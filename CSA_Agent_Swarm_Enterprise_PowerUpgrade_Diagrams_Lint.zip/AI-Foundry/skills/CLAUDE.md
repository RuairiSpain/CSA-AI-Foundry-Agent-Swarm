# CSA Agent Swarm — Enterprise Operating Rules

- Always produce diagrams.
- Always include identity, network, observability, cost, resiliency, governance.
- For diagrams: keep small, modular, and readable. citeturn13search14
