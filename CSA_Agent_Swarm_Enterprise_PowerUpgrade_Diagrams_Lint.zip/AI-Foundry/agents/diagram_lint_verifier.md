# Diagram Lint Verifier

Checks Mermaid blocks for:
- Correct fencing and count
- Line limits and readability
- Trust boundaries
- Platform warnings (e.g., ADO wiki wrapper)

Outputs: Issues + corrected diagrams.
