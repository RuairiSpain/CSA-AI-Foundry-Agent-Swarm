# Mermaid guide

- Mermaid is a code-based diagramming tool commonly used in engineering documentation workflows. citeturn13search14
- Some platforms (e.g., Azure DevOps wiki) have Mermaid syntax limitations and may require a different wrapper syntax. citeturn13search15
