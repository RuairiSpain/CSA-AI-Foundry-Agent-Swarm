# Mermaid lint rules

## Required
- Exactly 3 diagrams for `swarm.run` output: Network & security, Dataflow, Control plane/ops.
- Each diagram <= 25 lines.
- Include trust boundary subgraphs.

## Readability
- Avoid long node labels.
- Prefer multiple diagrams over one huge diagram. citeturn13search14

## Platform note
- If publishing to Azure DevOps wiki, consider the `:::` wrapper syntax due to limitations. citeturn13search15
