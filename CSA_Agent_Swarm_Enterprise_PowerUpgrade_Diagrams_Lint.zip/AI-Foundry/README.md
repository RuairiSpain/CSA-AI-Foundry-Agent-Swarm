# AI-Foundry — Enterprise CSA Agent Swarm (Diagrams + Lint)

New capability: `diagram.lint` verifier stage that checks Mermaid outputs and warns about platform limitations. citeturn13search15

Run:
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m uvicorn AI_Foundry.server.app:app --host 127.0.0.1 --port 8001
```
