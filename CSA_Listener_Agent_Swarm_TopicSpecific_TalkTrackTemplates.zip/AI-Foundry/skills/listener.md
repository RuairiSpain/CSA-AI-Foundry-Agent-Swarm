# CSA Listener — Topic-specific talk-track templates

This build adds deterministic **topic-specific talk-track templates** that mirror the `_card.sections` structure.

It is grounded in the CSA discovery-category approach in **CSA Customer Copilot Prompts** (security/compliance, cost optimisation, monitoring/logging, data management, privacy/RAI, etc.). citeturn23search570

## Behaviour
- Default: uses templates (fast, stable)
- Optional: set `LISTENER_TALKTRACK_LLM=true` to use model-generated talk tracks

## Output
- `talk_track`: 4–7 short lines you can say verbatim
- `one_liner`: the key question
