# CSA Listener mic client (topic-specific talk tracks)
# Commands:
#   h                -> history
#   auto on|off       -> toggle auto mode/persona/topic
#   pin <card_id>     -> pin a card
#   t                -> talk track for pinned/last

import os
import json
import asyncio
import azure.cognitiveservices.speech as speechsdk
import websockets

SERVER_WS = os.getenv('LISTENER_WS','ws://127.0.0.1:8001/listener/ws')
SPEECH_KEY = os.getenv('SPEECH_KEY')
SPEECH_REGION = os.getenv('SPEECH_REGION')
LANG = os.getenv('SPEECH_LANG','en-US')

async def main():
    if not SPEECH_KEY or not SPEECH_REGION:
        raise SystemExit('Set SPEECH_KEY and SPEECH_REGION')

    async with websockets.connect(SERVER_WS) as ws:
        await ws.send(json.dumps({}))
        msg = json.loads(await ws.recv())
        session_id = msg.get('session_id')
        print('Session:', session_id)

        speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
        speech_config.speech_recognition_language = LANG
        audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
        recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)

        def on_recognizing(evt):
            t = evt.result.text
            if t:
                asyncio.create_task(ws.send(json.dumps({'session_id': session_id,'text': t,'speaker':'customer','is_final': False})))

        def on_recognized(evt):
            t = evt.result.text
            if t:
                asyncio.create_task(ws.send(json.dumps({'session_id': session_id,'text': t,'speaker':'customer','is_final': True})))

        recognizer.recognizing.connect(on_recognizing)
        recognizer.recognized.connect(on_recognized)
        recognizer.start_continuous_recognition()

        async def keyboard():
            while True:
                s = await asyncio.get_event_loop().run_in_executor(None, input)
                parts = s.strip().split()
                if not parts:
                    continue
                cmd = parts[0].lower()
                if cmd == 'h':
                    await ws.send(json.dumps({'type':'history','session_id': session_id,'limit': 8}))
                elif cmd == 'auto' and len(parts) > 1:
                    v = parts[1].lower() in ('on','true','1','yes')
                    await ws.send(json.dumps({'type':'set','session_id': session_id,'auto_mode': v,'auto_persona': v,'auto_topic': v}))
                elif cmd == 'pin' and len(parts) > 1:
                    await ws.send(json.dumps({'type':'pin','session_id': session_id,'card_id': parts[1]}))
                elif cmd == 't':
                    await ws.send(json.dumps({'type':'talktrack','session_id': session_id}))

        asyncio.create_task(keyboard())

        try:
            while True:
                data = json.loads(await ws.recv())
                t = data.get('type')
                if t == 'guidance':
                    print('
--- CSA Card ---')
                    print('id:', data.get('card_id'), 'topic:', data.get('topic'), 'mode:', data.get('conversation_mode'))
                    print('Insight:', data.get('key_insight'))
                    print('Ask:', data.get('suggested_question'))
                elif t == 'talktrack':
                    print('
--- Talk Track ---')
                    for line in data.get('talk_track', []):
                        print('-', line)
                elif t == 'history':
                    print('
--- History ---')
                    for c in data.get('cards', []):
                        print(f"[{c.get('card_id')}] ({c.get('topic')}) {c.get('key_insight')}")
        finally:
            recognizer.stop_continuous_recognition()

if __name__ == '__main__':
    asyncio.run(main())
