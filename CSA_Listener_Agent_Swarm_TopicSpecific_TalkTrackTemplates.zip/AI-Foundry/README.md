# CSA Listener — Topic-specific cards + talk tracks

This pack includes:
- Topic-aware auto-routing (topic → mode)
- Topic-specific `_card` payloads for UI rendering
- Topic-specific talk-track templates derived from `_card.sections`

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m uvicorn AI_Foundry.server.app:app --host 127.0.0.1 --port 8001
```
