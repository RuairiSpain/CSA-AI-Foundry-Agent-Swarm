from __future__ import annotations
import os, json, time, uuid
from typing import Any, Dict, List, Tuple
from .models import FoundryModelClient
from .prompts import (MODE_GUIDANCE,PERSONA_GUIDANCE,INDUSTRY_GUIDANCE,LISTENER_FAST_SYSTEM,TOPIC_STYLE_CLASSIFIER_SYSTEM,INDUSTRY_CLASSIFIER_SYSTEM,INDUSTRY_ADVISOR_SYSTEM,LISTENER_EXTRACT_SYSTEM,DISCOVERY_COACH_SYSTEM,SOLUTION_ARCH_SYSTEM,OPPORTUNITY_SYSTEM,GAP_SYSTEM,WHISPER_SYSTEM,TALKTRACK_SYSTEM)

TOPIC_CUES={
 'security_compliance':['security','compliance','gdpr','hipaa','pci','audit','pii','encryption','key vault','defender','purview'],
 'governance_risk':['governance','risk','approval','guardrail','responsible ai'],
 'cost_finops':['cost','budget','finops','spend','pricing','tco','roi'],
 'architecture_networking':['vnet','private endpoint','private link','dns','expressroute','firewall','apim','network'],
 'operations_observability':['observability','monitor','app insights','log analytics','kql','alerts','slo','incident','rto','rpo'],
 'data_ai':['rag','retrieval','vector','embeddings','search','fabric','evaluation','grounding'],
 'delivery_next_steps':['next step','workshop','vbd','pilot','poc','timeline','milestone','scope','action item'],
 'requirements_discovery':['use case','requirements','success criteria','pain point','goal','users','workflow'],
}
TOPIC_TO_MODE={'security_compliance':'executive','governance_risk':'executive','cost_finops':'executive','delivery_next_steps':'executive','architecture_networking':'technical','operations_observability':'technical','data_ai':'technical','requirements_discovery':'consultative'}
VP_CUES=['vp','vice president','director','cxo','cio','cto','ciso','head of']
LEAD_CUES=['tech lead','architect','engineer','platform team','sre']
GRAD_CUES=['graduate','junior','new to','learning']
CARD_TITLES={'security_compliance':'Security & Compliance','governance_risk':'Governance & Risk','cost_finops':'Cost & FinOps','architecture_networking':'Architecture & Networking','operations_observability':'Operations & Observability','data_ai':'Data & AI','delivery_next_steps':'Delivery Next Steps','requirements_discovery':'Requirements Discovery'}

class ListenerEngine:
    def __init__(self):
        self.primary_model=os.getenv('PRIMARY_MODEL','gpt-5-mini')
        self.project_endpoint=os.getenv('FOUNDRY_PROJECT_ENDPOINT','')
        self.deep_on_final=os.getenv('LISTENER_DEEP_ON_FINAL','true').lower()=='true'
        self.pause_seconds=float(os.getenv('LISTENER_DEEP_PAUSE_SECONDS','8'))
        self.auto_lock_seconds=float(os.getenv('LISTENER_AUTO_LOCK_SECONDS','20'))
        self.auto_llm=os.getenv('LISTENER_AUTO_LLM','true').lower()=='true'
    def _client(self)->FoundryModelClient:
        return FoundryModelClient(project_endpoint=self.project_endpoint, model=self.primary_model)
    def _window(self, state:Dict[str,Any], n:int=25)->str:
        turns=state.get('transcript',[])[-n:]
        return '
'.join([f"{t['speaker']}: {t['text']}" for t in turns if t.get('text')])
    def _facts_text(self, state:Dict[str,Any])->str:
        return json.dumps(state.get('facts',{}), ensure_ascii=False)
    def _context_header(self, state:Dict[str,Any])->str:
        mode=state.get('mode','consultative'); persona=state.get('persona','unknown'); industry=state.get('industry','general'); topic=state.get('topic','requirements_discovery')
        return f"Topic: {topic}
Mode guidance: {MODE_GUIDANCE.get(mode,MODE_GUIDANCE['consultative'])}
Persona guidance: {PERSONA_GUIDANCE.get(persona,PERSONA_GUIDANCE['unknown'])}
Industry guidance: {INDUSTRY_GUIDANCE.get(industry,INDUSTRY_GUIDANCE['general'])}
"
    def _det_topic(self, window_lower:str, facts_lower:str):
        best=('requirements_discovery',0,[])
        for topic,cues in TOPIC_CUES.items():
            hits=[c for c in cues if c in window_lower or c in facts_lower]
            if len(hits)>best[1]: best=(topic,len(hits),hits)
        topic,score,hits=best
        conf='high' if score>=3 else 'medium' if score==2 else 'low'
        if score==0: topic='requirements_discovery'; hits=[]
        return topic, conf, hits
    def _det_persona(self, window_lower:str):
        if any(c in window_lower for c in VP_CUES): return 'director_vp', [c for c in VP_CUES if c in window_lower][:4]
        if any(c in window_lower for c in LEAD_CUES): return 'tech_lead', [c for c in LEAD_CUES if c in window_lower][:4]
        if any(c in window_lower for c in GRAD_CUES): return 'graduate', [c for c in GRAD_CUES if c in window_lower][:4]
        return 'unknown', []
    def _maybe_auto_style(self, state:Dict[str,Any])->Dict[str,Any]:
        now=time.time()
        auto_mode_allowed=bool(state.get('auto_mode',True)) and state.get('mode_source')!='manual'
        auto_persona_allowed=bool(state.get('auto_persona',True)) and state.get('persona_source')!='manual'
        auto_topic_allowed=bool(state.get('auto_topic',True)) and state.get('topic_source')!='manual'
        if not auto_mode_allowed and not auto_persona_allowed and not auto_topic_allowed: return {'changed':False}
        if (now-float(state.get('last_style_change_ts',0.0) or 0.0))<self.auto_lock_seconds: return {'changed':False}
        window=self._window(state); wl=window.lower(); fl=self._facts_text(state).lower()
        topic, conf, tcues=self._det_topic(wl,fl)
        persona, pcues=self._det_persona(wl)
        mode=TOPIC_TO_MODE.get(topic,'consultative')
        cues=(tcues+pcues)[:8]
        changed=False
        if auto_topic_allowed and topic!=state.get('topic'):
            state['topic']=topic; state['topic_confidence']=conf; state['topic_source']='auto'; changed=True
        if auto_mode_allowed and mode!=state.get('mode'):
            state['mode']=mode; state['mode_source']='auto'; changed=True
        if auto_persona_allowed and persona!=state.get('persona'):
            state['persona']=persona; state['persona_source']='auto'; changed=True
        if changed: state['last_style_change_ts']=now
        return {'changed':changed,'topic':state.get('topic'),'mode':state.get('mode'),'persona':state.get('persona'),'confidence':conf,'cues':cues}
    def process_chunk(self, state:Dict[str,Any], chunk:Dict[str,Any])->Dict[str,Any]:
        now=time.time(); state.setdefault('transcript',[]).append({'ts':now,'speaker':chunk.get('speaker','unknown'),'text':chunk.get('text',''),'final':bool(chunk.get('is_final',False))})
        style_change=self._maybe_auto_style(state)
        is_final=bool(chunk.get('is_final',False)); force_deep=bool(chunk.get('force_deep',False))
        route='deep' if (force_deep or (is_final and self.deep_on_final)) else 'fast'
        out=self._deep(state) if route=='deep' else self._fast(state)
        out['guidance']=_apply_card_format(out['guidance'], state)
        if style_change.get('changed'): out['guidance']['_style_switch']=style_change
        return out
    def _fast(self, state:Dict[str,Any])->Dict[str,Any]:
        client=self._client(); header=self._context_header(state); facts=json.dumps(state.get('facts',{}),ensure_ascii=False); window=self._window(state)
        raw=client.ask(LISTENER_FAST_SYSTEM, header+f"
Running facts:
{facts}

Window:
{window}
Return STRICT JSON.")
        guidance=_safe_json(raw) or _fallback_guidance(raw)
        extracted=guidance.get('extracted',{}) or {}
        state['facts']=_merge_facts(state.get('facts',{}), extracted)
        card=_to_card(guidance,state,mode='fast')
        state.setdefault('cards',[]).append(card); state['last_guidance']=card
        return {'state':state,'guidance':card}
    def _deep(self, state:Dict[str,Any])->Dict[str,Any]:
        # minimal deep: reuse fast output
        return self._fast(state)
    def talk_track(self, state:Dict[str,Any], card:Dict[str,Any], mode:str|None=None, persona:str|None=None)->Dict[str,Any]:
        if mode: state['mode']=mode; state['mode_source']='manual'
        if persona: state['persona']=persona; state['persona_source']='manual'
        topic=(card.get('topic') or state.get('topic') or 'requirements_discovery')
        sections=((card.get('_card') or {}).get('sections') or {}) if isinstance(card.get('_card'),dict) else {}
        def short(x,limit=140):
            x=(x or '').strip(); return (x[:limit-1].rstrip()+'…') if len(x)>limit else x
        def list_to_str(v,max_items=2):
            if isinstance(v,list):
                items=[str(i).strip() for i in v if str(i).strip()]; return '; '.join(items[:max_items])
            return str(v).strip() if v is not None else ''
        ask=card.get('suggested_question','')
        hint=card.get('solution_hint','')
        insight=card.get('key_insight','')
        lines=[]
        def add(s):
            if s and s.strip(): lines.append(s.strip())
        if topic=='security_compliance':
            add(f"Risk check: {short(list_to_str(sections.get('risk')) or insight)}")
            add(f"Current controls: {short(list_to_str(sections.get('controls')))}")
            add(sections.get('ask') or ask)
            add(f"Next step: {sections.get('next_step') or hint}")
        elif topic=='architecture_networking':
            add(f"Constraint: {short(list_to_str(sections.get('constraint')) or insight)}")
            opt=list_to_str(sections.get('options'),2)
            if opt: add(f"Options: {opt}")
            tr=short(list_to_str(sections.get('tradeoff')))
            if tr: add(f"Trade-off: {tr}")
            add(sections.get('ask') or ask)
        elif topic=='cost_finops':
            add(f"Cost driver: {short(list_to_str(sections.get('cost_driver')) or insight)}")
            add(f"Guardrail: {short(list_to_str(sections.get('guardrail')))}")
            add(sections.get('ask') or ask)
            add(f"Next step: {sections.get('next_step') or hint}")
        elif topic=='operations_observability':
            add(f"Operational signal: {short(list_to_str(sections.get('signal')) or insight)}")
            slo=short(list_to_str(sections.get('slo')))
            if slo: add(f"Target SLO/constraint: {slo}")
            instr=list_to_str(sections.get('instrumentation'),2)
            if instr: add(f"Instrumentation ideas: {instr}")
            add(sections.get('ask') or ask)
        elif topic=='data_ai':
            add(f"Data sources: {list_to_str(sections.get('data_sources'),3) or insight}")
            r=list_to_str(sections.get('retrieval'),2)
            if r: add(f"Retrieval/RAG: {r}")
            ev=short(list_to_str(sections.get('evaluation')))
            if ev: add(f"Evaluation gap: {ev}")
            add(sections.get('ask') or ask)
        elif topic=='delivery_next_steps':
            add(f"Decision: {short(list_to_str(sections.get('decision')) or insight)}")
            if sections.get('owner'): add(f"Owner: {short(list_to_str(sections.get('owner')))}")
            if sections.get('date'): add(f"Target date: {short(list_to_str(sections.get('date')))}")
            add(f"Next step: {sections.get('next_step') or hint}")
        else:
            add(f"Goal: {short(list_to_str(sections.get('goal')) or insight)}")
            p=short(list_to_str(sections.get('pain')))
            if p: add(f"Pain: {p}")
            c=short(list_to_str(sections.get('constraints'),2))
            if c: add(f"Constraints: {c}")
            add(sections.get('ask') or ask)
        if len(lines)<3:
            lines=[f"Based on what you've shared, {insight or 'here’s what I’m hearing.'}", f"Could you clarify: {ask or 'what success looks like?'}", f"One direction we can explore is: {hint or 'an Azure/Foundry option that matches constraints.'}", "Does that align with your priorities?"]
        return {'talk_track': lines[:7], 'one_liner': ask or (lines[-1] if lines else '')}

def _apply_card_format(guidance:Dict[str,Any], state:Dict[str,Any])->Dict[str,Any]:
    topic=state.get('topic','requirements_discovery')
    title=CARD_TITLES.get(topic,'Requirements Discovery')
    extracted=guidance.get('extracted') or {}
    def first(lst):
        return lst[0] if isinstance(lst,list) and lst else ''
    card={'schema':f"csa.card.{topic}.v1",'title':title,'topic':topic,'sections':{}}
    if topic=='security_compliance':
        card['sections']={'risk':first(extracted.get('constraints')) or guidance.get('critical_gap',''),'controls':first(extracted.get('current_state')),'ask':guidance.get('suggested_question',''),'next_step':guidance.get('solution_hint','')}
    elif topic=='cost_finops':
        card['sections']={'cost_driver':first(extracted.get('pain_points')),'guardrail':first(extracted.get('constraints')),'ask':guidance.get('suggested_question',''),'next_step':guidance.get('solution_hint','')}
    elif topic=='architecture_networking':
        card['sections']={'constraint':first(extracted.get('constraints')),'options':[],'tradeoff':'','ask':guidance.get('suggested_question','')}
    elif topic=='operations_observability':
        card['sections']={'signal':first(extracted.get('pain_points')),'slo':first(extracted.get('constraints')),'instrumentation':[],'ask':guidance.get('suggested_question','')}
    elif topic=='data_ai':
        card['sections']={'data_sources':extracted.get('current_state') or [],'retrieval':[],'evaluation':guidance.get('critical_gap',''),'ask':guidance.get('suggested_question','')}
    elif topic=='delivery_next_steps':
        card['sections']={'decision':guidance.get('key_insight',''),'owner':'','date':'','next_step':guidance.get('solution_hint','')}
    else:
        card['sections']={'goal':(extracted.get('customer_goal') or ''),'pain':first(extracted.get('pain_points')),'constraints':extracted.get('constraints') or [],'ask':guidance.get('suggested_question','')}
    guidance['_card']=card
    return guidance

def _to_card(guidance:Dict[str,Any], state:Dict[str,Any], mode:str)->Dict[str,Any]:
    d={'card_id':str(uuid.uuid4()),'ts':time.time(),'mode':mode,'topic':state.get('topic','requirements_discovery'),'conversation_mode':state.get('mode','consultative'),'persona':state.get('persona','unknown'),'industry':state.get('industry','general'),
       'key_insight':guidance.get('key_insight',''),'suggested_question':guidance.get('suggested_question',''),'solution_hint':guidance.get('solution_hint',''),'critical_gap':guidance.get('critical_gap',''),'extracted':guidance.get('extracted',{}), '_card':guidance.get('_card')}
    return d

def _merge_facts(existing:Dict[str,Any], new:Dict[str,Any])->Dict[str,Any]:
    out=dict(existing or {})
    if new.get('customer_goal'): out['customer_goal']=new.get('customer_goal')
    for k in ['pain_points','constraints','current_state','open_questions']:
        items=new.get(k)
        if not items: continue
        if not isinstance(items,list): items=[items]
        out.setdefault(k,[])
        for it in items:
            if it and it not in out[k]: out[k].append(it)
    return out

def _safe_json(text:str):
    try:
        t=text.strip()
        if t.startswith('```'):
            t=t.split('
',1)[-1]
            if t.endswith('```'): t=t.rsplit('```',1)[0]
        return json.loads(t)
    except Exception:
        return None

def _fallback_guidance(raw:str)->Dict[str,Any]:
    return {'key_insight':'Conversation in progress; capture more details.','suggested_question':'Could you describe the current system and what success looks like?','solution_hint':'Clarify requirements and constraints before selecting Foundry services.','critical_gap':'Need clearer requirements.','extracted':{},'_raw':raw}
