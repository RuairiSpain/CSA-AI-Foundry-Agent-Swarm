from __future__ import annotations
import uuid
from typing import Any, Dict
from .state import SessionStore
from .engine import ListenerEngine
STORE=SessionStore(); ENGINE=ListenerEngine()

def listener_start(arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
    session_id=str(uuid.uuid4()); STORE.create(session_id); return {'session_id':session_id}

def listener_set_mode(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; m=arguments.get('mode','consultative'); return {'session_id':sid,'mode':STORE.set_mode(sid,m,source='manual')}

def listener_set_persona(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; p=arguments.get('persona','unknown'); return {'session_id':sid,'persona':STORE.set_persona(sid,p,source='manual')}

def listener_set_auto(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; out=STORE.set_auto(sid,auto_mode=arguments.get('auto_mode'),auto_persona=arguments.get('auto_persona'),auto_topic=arguments.get('auto_topic')); return {'session_id':sid,**out}

def listener_ingest(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']
    if arguments.get('mode'): STORE.set_mode(sid, arguments['mode'], source='manual')
    if arguments.get('persona'): STORE.set_persona(sid, arguments['persona'], source='manual')
    st=STORE.get(sid)
    out=ENGINE.process_chunk(st,{'text':arguments['text'],'speaker':arguments.get('speaker','unknown'),'is_final':bool(arguments.get('is_final',False)),'force_deep':bool(arguments.get('force_deep',False))})
    STORE.set(sid,out['state']); return out['guidance']

def listener_history(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; limit=int(arguments.get('limit',10)); before=arguments.get('before_card_id'); return {'session_id':sid,'cards':STORE.list_cards(sid,limit=limit,before_card_id=before)}

def listener_pin(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; return {'session_id':sid,'pinned':STORE.pin(sid, arguments['card_id'])}

def listener_talktrack(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; st=STORE.get(sid)
    card_id=arguments.get('card_id'); card=None
    if card_id:
        for c in st.get('cards',[]):
            if c.get('card_id')==card_id: card=c; break
    if not card:
        card=STORE.get_pinned(sid) or st.get('last_guidance') or {}
    out=ENGINE.talk_track(st, card, mode=arguments.get('mode'), persona=arguments.get('persona'))
    STORE.set(sid,st); return {'session_id':sid,'card_id':card.get('card_id'),**out}

def listener_get_state(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; st=STORE.get(sid)
    return {'session_id':sid,'topic':st.get('topic'),'mode':st.get('mode'),'persona':st.get('persona'),'industry':st.get('industry'),'auto_mode':st.get('auto_mode'),'auto_persona':st.get('auto_persona'),'auto_topic':st.get('auto_topic'),'facts':st.get('facts',{}),'pinned_card_id':st.get('pinned_card_id'),'last_guidance':st.get('last_guidance',{})}

def listener_reset(arguments: Dict[str, Any]) -> Dict[str, Any]:
    sid=arguments['session_id']; STORE.reset(sid); return {'session_id':sid,'status':'reset'}
