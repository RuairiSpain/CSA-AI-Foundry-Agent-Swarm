from __future__ import annotations
import os, json, uuid
from typing import Any
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from AI_Foundry.server.tool_registry import ToolRegistry
from AI_Foundry.server.jsonrpc import JsonRpcError, make_error, make_result, get_id, get_method, get_params
from AI_Foundry.listener.state import SessionStore
from AI_Foundry.listener.engine import ListenerEngine
app=FastAPI(title=os.getenv('APP_TITLE','CSA Listener MCP'), version='1.1.0')
TOOLS_PATH=os.getenv('TOOLS_YAML','config/tools.yaml')
registry=ToolRegistry(TOOLS_PATH)
STORE=SessionStore(); ENGINE=ListenerEngine()
@app.get('/health')
def health():
    return {'status':'ok','tools':len(registry.list_tools()),'listener_sessions':STORE.count()}
@app.post('/mcp')
async def mcp(request: Request):
    payload=await request.json(); id_=get_id(payload)
    try:
        method=get_method(payload); params=get_params(payload)
        if method=='initialize':
            proto=(params or {}).get('protocolVersion','2024-11-05')
            return make_result(id_, {'protocolVersion':proto,'capabilities':{'tools':{'listChanged':False},'resources':{'subscribe':False,'listChanged':False},'prompts':{'listChanged':False}},'serverInfo':{'name':'csa-listener','version':app.version}})
        if method=='tools/list':
            return make_result(id_, {'tools':registry.list_tools(),'nextCursor':None})
        if method=='tools/call':
            if not params: raise JsonRpcError(-32602,'Invalid params',{'reason':'Missing params'})
            name=params.get('name'); arguments=params.get('arguments',{})
            if not name: raise JsonRpcError(-32602,'Invalid params',{'reason':'Missing tool name'})
            tool=registry.get_tool(name); registry.validate_args(tool, arguments)
            adapter=registry.load_callable(tool.adapter)
            output=adapter(arguments)
            return make_result(id_, {'content':[{'type':'text','text':_as_text(output)}],'isError':False})
        if method=='resources/list':
            return make_result(id_, {'resources':registry.list_resources(),'nextCursor':None})
        if method=='resources/read':
            if not params or 'uri' not in params: raise JsonRpcError(-32602,'Invalid params',{'reason':'Missing uri'})
            return make_result(id_, {'contents':[registry.read_resource(params['uri'])]})
        if method=='prompts/list':
            return make_result(id_, {'prompts':registry.list_prompts(),'nextCursor':None})
        if method=='prompts/get':
            if not params or 'name' not in params: raise JsonRpcError(-32602,'Invalid params',{'reason':'Missing name'})
            return make_result(id_, registry.get_prompt(params['name'], (params or {}).get('arguments',{})))
        raise JsonRpcError(-32601,'Method not found',{'method':method})
    except JsonRpcError as e:
        return make_error(id_, e)
@app.websocket('/listener/ws')
async def listener_ws(ws: WebSocket):
    await ws.accept(); session_id=None
    try:
        while True:
            msg=await ws.receive_text(); payload=json.loads(msg) if msg else {}
            if not session_id and not payload.get('session_id'):
                session_id=str(uuid.uuid4()); STORE.create(session_id)
                await ws.send_text(json.dumps({'type':'session_created','session_id':session_id}))
                continue
            session_id=payload.get('session_id') or session_id
            if not session_id: continue
            t=payload.get('type')
            if t=='set':
                if payload.get('mode'): STORE.set_mode(session_id,payload['mode'],source='manual')
                if payload.get('persona'): STORE.set_persona(session_id,payload['persona'],source='manual')
                if 'auto_mode' in payload or 'auto_persona' in payload or 'auto_topic' in payload:
                    STORE.set_auto(session_id, auto_mode=payload.get('auto_mode'), auto_persona=payload.get('auto_persona'), auto_topic=payload.get('auto_topic'))
                st=STORE.get(session_id)
                await ws.send_text(json.dumps({'type':'set_ok','session_id':session_id,'mode':st.get('mode'),'persona':st.get('persona'),'topic':st.get('topic'),'auto_mode':st.get('auto_mode'),'auto_persona':st.get('auto_persona'),'auto_topic':st.get('auto_topic')},ensure_ascii=False))
                continue
            if t=='history':
                cards=STORE.list_cards(session_id, limit=int(payload.get('limit',10)), before_card_id=payload.get('before_card_id'))
                await ws.send_text(json.dumps({'type':'history','session_id':session_id,'cards':cards},ensure_ascii=False))
                continue
            if t=='pin':
                card=STORE.pin(session_id, payload.get('card_id',''))
                await ws.send_text(json.dumps({'type':'pin_ok','session_id':session_id,'pinned':card},ensure_ascii=False))
                continue
            if t=='talktrack':
                st=STORE.get(session_id)
                card_id=payload.get('card_id'); card=None
                if card_id:
                    for c in st.get('cards',[]):
                        if c.get('card_id')==card_id: card=c; break
                if not card: card=STORE.get_pinned(session_id) or st.get('last_guidance') or {}
                out=ENGINE.talk_track(st, card, mode=payload.get('mode'), persona=payload.get('persona'))
                STORE.set(session_id, st)
                await ws.send_text(json.dumps({'type':'talktrack','session_id':session_id,'card_id':card.get('card_id'),**out},ensure_ascii=False))
                continue
            if t=='reset':
                STORE.reset(session_id); await ws.send_text(json.dumps({'type':'reset_ok','session_id':session_id}))
                continue
            text=payload.get('text','')
            if not text:
                await ws.send_text(json.dumps({'type':'noop','reason':'missing text'})); continue
            out=ENGINE.process_chunk(STORE.get(session_id), {'speaker':payload.get('speaker','unknown'),'text':text,'is_final':bool(payload.get('is_final',False)),'force_deep':bool(payload.get('force_deep',False))})
            STORE.set(session_id,out['state'])
            await ws.send_text(json.dumps({'type':'guidance','session_id':session_id,**out['guidance']},ensure_ascii=False))
    except WebSocketDisconnect:
        pass

def _as_text(obj: Any) -> str:
    import json
    return obj if isinstance(obj,str) else json.dumps(obj, ensure_ascii=False, indent=2)
