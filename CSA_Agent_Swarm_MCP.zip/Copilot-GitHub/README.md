# Copilot-GitHub — CSA Agent Swarm

Focus: GitHub Copilot workflows (PRs, reviews, repo hygiene) + MCP.

Run the MCP server:
```bash
python -m uvicorn server.app:app --host 127.0.0.1 --port 8003
```

Use scenario: `copilot_github_pr_swarm`
