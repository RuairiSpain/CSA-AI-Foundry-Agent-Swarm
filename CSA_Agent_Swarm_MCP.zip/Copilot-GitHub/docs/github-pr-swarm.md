# GitHub Copilot PR swarm

Scenario: `copilot_github_pr_swarm`
