# Planner Agent Skill

- Output: numbered plan, max 10 steps
- Each step: goal, inputs, outputs
