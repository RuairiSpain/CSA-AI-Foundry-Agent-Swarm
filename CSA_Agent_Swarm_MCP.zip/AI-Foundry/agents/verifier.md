# Verifier Agent Skill

- Find gaps, mistakes, and verbosity
- Return: issues + improved concise version
