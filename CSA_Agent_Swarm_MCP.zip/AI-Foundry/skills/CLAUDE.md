# CSA Agent Swarm — Operating Rules

- Be **accurate** and explicit about what is known vs assumed.
- Prefer **actionable** steps with clear outputs.
- Use **Azure AI Foundry** as the control plane when the scenario involves governance, evaluation, tracing, or multi-model routing.
- For Copilot integration, treat Copilot as the **UX layer** and your MCP server as the **tool/back-end**.
- Never include secrets in outputs.
