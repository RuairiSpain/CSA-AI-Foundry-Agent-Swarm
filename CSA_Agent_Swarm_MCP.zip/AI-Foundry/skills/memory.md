# Session Memory

Store only:
- Scenario name
- Decisions made (model choice, tools enabled)
- Outputs produced (plans, drafts)
- Validation notes from the verifier agent

Do not store:
- Credentials, tokens, API keys
- Customer confidential content
