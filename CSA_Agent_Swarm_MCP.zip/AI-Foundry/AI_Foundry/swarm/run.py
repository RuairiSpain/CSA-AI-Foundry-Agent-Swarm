from __future__ import annotations

import os
from typing import Any, Dict

from .swarm import CSASwarm, SwarmConfig
from .models import FoundryModelClient


def _cfg() -> SwarmConfig:
    primary = os.getenv("PRIMARY_MODEL", "gpt-5-mini")
    verifier = os.getenv("VERIFIER_MODEL", "gpt-4.1")
    return SwarmConfig(primary_model=primary, verifier_model=verifier)


def _client(model: str) -> FoundryModelClient:
    endpoint = os.getenv("FOUNDRY_PROJECT_ENDPOINT", "")
    return FoundryModelClient(project_endpoint=endpoint, model=model)


def run_swarm(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    task = arguments["task"]
    scenario = arguments["scenario"]

    swarm = CSASwarm(cfg, primary=_client(cfg.primary_model), verifier=_client(cfg.verifier_model))

    if scenario == "foundry_feature_tour":
        swarm.add_specialist("foundry", "Explain and demo Azure AI Foundry features: models, agents, tools, evals, tracing, publishing.")
        swarm.add_specialist("mcp", "Generate MCP tool schemas and example JSON-RPC calls for tools/list and tools/call.")
    elif scenario == "copilot_vscode_workshop":
        swarm.add_specialist("vscode", "Create a Copilot for VS Code workshop plan: MCP setup, agent mode, tool usage, debugging checklist.")
        swarm.add_specialist("repo", "Generate repo structure suggestions for a workshop.")
    elif scenario == "copilot_github_pr_swarm":
        swarm.add_specialist("github", "Create a PR-ready checklist and automation plan: tests, linting, security, docs.")
        swarm.add_specialist("review", "Create a concise PR description and reviewer notes.")
    else:
        swarm.add_specialist("general", "Produce a CSA-grade answer: structured, actionable, and grounded.")

    return swarm.run(task=task, scenario=scenario)


def foundry_ask(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    client = _client(cfg.primary_model)
    prompt = arguments["prompt"]
    return {"model": cfg.primary_model, "response": client.ask("You are a helpful CSA assistant.", prompt)}
