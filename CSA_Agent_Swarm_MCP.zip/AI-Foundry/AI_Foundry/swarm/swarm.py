from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from .models import FoundryModelClient


@dataclass
class SwarmConfig:
    primary_model: str
    verifier_model: str


class PlannerAgent:
    name = "planner"
    system = "Create a tight execution plan with numbered steps and explicit deliverables."

    def run(self, client: FoundryModelClient, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        plan = client.ask(self.system, f"Task: {task}\nReturn: plan as numbered steps, max 10.")
        return {"plan": plan}


class SpecialistAgent:
    def __init__(self, name: str, system: str):
        self.name = name
        self.system = system

    def run(self, client: FoundryModelClient, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        answer = client.ask(self.system, f"Task: {task}\nContext: {context}\nReturn: markdown output.")
        return {"output": answer}


class VerifierAgent:
    name = "verifier"
    system = (
        "You are a rigorous verifier. Check for gaps, mistakes, missing steps, and verbosity. "
        "Return: (1) issues list, (2) improved concise version."
    )

    def run(self, client: FoundryModelClient, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        draft = context.get("draft", "")
        review = client.ask(self.system, f"Task: {task}\nDraft: {draft}\nReturn issues + improved version.")
        return {"review": review}


class CSASwarm:
    def __init__(self, cfg: SwarmConfig, primary: FoundryModelClient, verifier: FoundryModelClient):
        self.cfg = cfg
        self.primary = primary
        self.verifier = verifier
        self.planner = PlannerAgent()
        self.specialists: List[SpecialistAgent] = []
        self.verifier_agent = VerifierAgent()

    def add_specialist(self, name: str, system: str):
        self.specialists.append(SpecialistAgent(name, system))

    def run(self, task: str, scenario: str) -> Dict[str, Any]:
        ctx: Dict[str, Any] = {"scenario": scenario}
        plan = self.planner.run(self.primary, task, ctx)
        ctx.update(plan)

        outputs: Dict[str, Dict[str, Any]] = {}
        for sp in self.specialists:
            outputs[sp.name] = sp.run(self.primary, task, ctx)

        draft = "\n\n".join([f"## {k}\n{v.get('output','')}" for k, v in outputs.items()])
        ctx["draft"] = draft

        verification = self.verifier_agent.run(self.verifier, task, ctx)
        return {"scenario": scenario, "plan": plan, "draft": draft, "verification": verification}
