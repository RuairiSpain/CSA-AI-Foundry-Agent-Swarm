# AI-Foundry — CSA Agent Swarm

Focus: Azure AI Foundry features (models, agents, tools, evaluation, tracing, publishing).

Run the MCP server:
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m uvicorn server.app:app --host 127.0.0.1 --port 8001
```

Run scenario:
- scenario: `foundry_feature_tour`
- primary model: `PRIMARY_MODEL` (default `gpt-5-mini`)
- verifier model: `VERIFIER_MODEL` (default `gpt-4.1`)

