# Foundry feature map (CSA checklist)

- Model choice & deployments
- Hosted agents & tools
- Evaluation
- Tracing/observability
- Publishing patterns
