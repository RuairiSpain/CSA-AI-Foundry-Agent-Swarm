# VS Code Copilot + MCP workshop

- Configure `.vscode/mcp.json`
- Use `tools/list` then `tools/call`
- Run verifier loop for concision
