# Copilot-VSCode — CSA Agent Swarm

Focus: GitHub Copilot in VS Code (agent mode) + MCP integration.

Run the MCP server:
```bash
python -m uvicorn server.app:app --host 127.0.0.1 --port 8002
```

Use scenario: `copilot_vscode_workshop`
