from __future__ import annotations

import os
import secrets
import requests
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

from azure.identity import ClientSecretCredential

GRAPH_SCOPE = "https://graph.microsoft.com/.default"

@dataclass
class GraphAuth:
    tenant_id: str
    client_id: str
    client_secret: str

    @classmethod
    def from_env(cls) -> 'GraphAuth':
        return cls(
            tenant_id=os.getenv('AZURE_TENANT_ID',''),
            client_id=os.getenv('AZURE_CLIENT_ID',''),
            client_secret=os.getenv('AZURE_CLIENT_SECRET',''),
        )

    def token(self) -> str:
        cred = ClientSecretCredential(self.tenant_id, self.client_id, self.client_secret)
        return cred.get_token(GRAPH_SCOPE).token


def _headers(token: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {token}", "Accept": "application/json", "Content-Type": "application/json"}


def download_transcript_vtt(token: str, online_meeting_id: str, transcript_id: str, user_path: str = "/me") -> str:
    url = f"https://graph.microsoft.com/v1.0{user_path}/onlineMeetings/{online_meeting_id}/transcripts/{transcript_id}/content?$format=text/vtt"
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=30)
    r.raise_for_status()
    return r.text


def create_transcript_subscription(token: str, online_meeting_id: str, notification_url: str, lifecycle_url: Optional[str]=None, client_state: Optional[str]=None) -> Dict:
    exp = datetime.now(timezone.utc) + timedelta(hours=1)
    payload = {
        "changeType": "created",
        "resource": f"/communications/onlineMeetings/{online_meeting_id}/transcripts",
        "notificationUrl": notification_url,
        "expirationDateTime": exp.isoformat(),
        "clientState": client_state or secrets.token_hex(16),
    }
    if lifecycle_url:
        payload["lifecycleNotificationUrl"] = lifecycle_url
    url = "https://graph.microsoft.com/v1.0/subscriptions"
    r = requests.post(url, headers=_headers(token), json=payload, timeout=30)
    r.raise_for_status()
    return r.json()


def renew_subscription(token: str, subscription_id: str, hours: int = 1) -> Dict:
    exp = datetime.now(timezone.utc) + timedelta(hours=hours)
    url = f"https://graph.microsoft.com/v1.0/subscriptions/{subscription_id}"
    r = requests.patch(url, headers=_headers(token), json={"expirationDateTime": exp.isoformat()}, timeout=30)
    r.raise_for_status()
    return r.json()


def delete_subscription(token: str, subscription_id: str) -> None:
    url = f"https://graph.microsoft.com/v1.0/subscriptions/{subscription_id}"
    r = requests.delete(url, headers=_headers(token), timeout=30)
    r.raise_for_status()
