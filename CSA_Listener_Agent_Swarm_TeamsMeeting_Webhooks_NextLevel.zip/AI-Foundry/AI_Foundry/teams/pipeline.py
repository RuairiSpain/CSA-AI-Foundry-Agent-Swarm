from __future__ import annotations

import os
import json
import websockets

from .graph import GraphAuth, download_transcript_vtt
from .vtt import parse_vtt

LISTENER_WS = os.getenv('LISTENER_WS','ws://127.0.0.1:8001/listener/ws')
USER_PATH = os.getenv('GRAPH_USER_PATH','/me')

async def ingest_transcript_to_listener(online_meeting_id: str, transcript_id: str) -> str:
    auth = GraphAuth.from_env()
    token = auth.token()
    vtt = download_transcript_vtt(token, online_meeting_id, transcript_id, user_path=USER_PATH)
    cues = parse_vtt(vtt)

    async with websockets.connect(LISTENER_WS) as ws:
        await ws.send(json.dumps({}))
        msg = json.loads(await ws.recv())
        session_id = msg.get('session_id')

        for cue in cues:
            await ws.send(json.dumps({'session_id': session_id, 'speaker': 'meeting', 'text': cue.text, 'is_final': True}))
            await ws.recv()

        await ws.send(json.dumps({'type':'talktrack','session_id': session_id}))
        await ws.recv()
        return session_id
