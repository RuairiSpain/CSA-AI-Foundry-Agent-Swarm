from __future__ import annotations

import os
import json
import hmac
import hashlib
import asyncio
from typing import Dict

from fastapi import APIRouter, Request, Response

from .pipeline import ingest_transcript_to_listener

router = APIRouter()
CLIENT_STATE_SECRET = os.getenv('GRAPH_CLIENT_STATE','')

def _expected_client_state(subscription_id: str) -> str:
    if not CLIENT_STATE_SECRET:
        return ''
    return hmac.new(CLIENT_STATE_SECRET.encode('utf-8'), subscription_id.encode('utf-8'), hashlib.sha256).hexdigest()

def _is_valid_client_state(subscription_id: str, client_state: str) -> bool:
    exp = _expected_client_state(subscription_id)
    if not exp:
        return True
    return hmac.compare_digest(exp, (client_state or ''))

@router.post('/graph/notifications')
async def graph_notifications(request: Request):
    vt = request.query_params.get('validationToken')
    if vt:
        return Response(content=vt, media_type='text/plain')

    payload = await request.json()
    notifications = payload.get('value', []) if isinstance(payload, dict) else []

    for n in notifications:
        sub_id = n.get('subscriptionId')
        if not sub_id:
            continue
        if not _is_valid_client_state(sub_id, n.get('clientState','')):
            continue

        resource = n.get('resource','')
        parts = [p for p in resource.split('/') if p]
        if 'onlineMeetings' in parts and 'transcripts' in parts:
            om_idx = parts.index('onlineMeetings')
            tr_idx = parts.index('transcripts')
            online_meeting_id = parts[om_idx+1] if om_idx+1 < len(parts) else ''
            transcript_id = parts[tr_idx+1] if tr_idx+1 < len(parts) else ''
            if online_meeting_id and transcript_id:
                asyncio.create_task(ingest_transcript_to_listener(online_meeting_id, transcript_id))

    return Response(status_code=202)
