TALKTRACK_SYSTEM = "Return STRICT JSON: {talk_track:[...], one_liner:string}."
