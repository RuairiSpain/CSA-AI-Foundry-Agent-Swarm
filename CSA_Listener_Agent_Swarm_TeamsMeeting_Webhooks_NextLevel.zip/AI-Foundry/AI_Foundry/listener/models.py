from __future__ import annotations

try:
    from azure.identity import DefaultAzureCredential
    from azure.ai.projects import AIProjectClient
except Exception:  # pragma: no cover
    DefaultAzureCredential = None
    AIProjectClient = None

class FoundryModelClient:
    def __init__(self, project_endpoint: str, model: str):
        self.project_endpoint = project_endpoint
        self.model = model

    def ask(self, system: str, prompt: str) -> str:
        if AIProjectClient is None or DefaultAzureCredential is None or not self.project_endpoint:
            return f"[Foundry not configured] Would call model '{self.model}' with system+prompt."
        project = AIProjectClient(endpoint=self.project_endpoint, credential=DefaultAzureCredential())
        with project.get_openai_client() as openai_client:
            resp = openai_client.responses.create(
                model=self.model,
                input=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
            )
            return getattr(resp, "output_text", str(resp))
