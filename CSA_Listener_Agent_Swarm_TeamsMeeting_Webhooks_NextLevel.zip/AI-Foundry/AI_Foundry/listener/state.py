from __future__ import annotations
import time
from typing import Any, Dict, List

class SessionStore:
    def __init__(self):
        self._sessions: Dict[str, Dict[str, Any]] = {}

    def create(self, session_id: str) -> None:
        now=time.time()
        self._sessions[session_id]={
            'created':now,'updated':now,'transcript':[],
            'facts':{},
            'mode':'consultative','persona':'unknown','industry':'general',
            'topic':'requirements_discovery','topic_confidence':'low',
            'auto_mode':True,'auto_persona':True,'auto_topic':True,
            'mode_source':'default','persona_source':'default','topic_source':'default',
            'last_style_change_ts':0.0,
            'cards':[],'pinned_card_id':None,'last_guidance':{},
        }

    def count(self)->int:
        return len(self._sessions)

    def get(self, session_id:str)->Dict[str,Any]:
        if session_id not in self._sessions:
            self.create(session_id)
        return self._sessions[session_id]

    def set(self, session_id:str, state:Dict[str,Any])->None:
        state['updated']=time.time(); self._sessions[session_id]=state

    def list_cards(self, session_id:str, limit:int=10)->List[Dict[str,Any]]:
        return self.get(session_id).get('cards',[])[-limit:]
