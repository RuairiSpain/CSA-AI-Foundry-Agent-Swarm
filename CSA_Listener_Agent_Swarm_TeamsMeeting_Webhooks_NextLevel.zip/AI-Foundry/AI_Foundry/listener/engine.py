from __future__ import annotations
import os, json, time, uuid
from typing import Any, Dict
from .models import FoundryModelClient
from .prompts import TALKTRACK_SYSTEM

class ListenerEngine:
    def __init__(self):
        self.primary_model=os.getenv('PRIMARY_MODEL','gpt-5-mini')
        self.project_endpoint=os.getenv('FOUNDRY_PROJECT_ENDPOINT','')
        self.use_llm_talktrack=os.getenv('LISTENER_TALKTRACK_LLM','true').lower()=='true'

    def _client(self)->FoundryModelClient:
        return FoundryModelClient(project_endpoint=self.project_endpoint, model=self.primary_model)

    def process_chunk(self, state:Dict[str,Any], chunk:Dict[str,Any])->Dict[str,Any]:
        now=time.time()
        state.setdefault('transcript',[]).append({'ts':now,'speaker':chunk.get('speaker','unknown'),'text':chunk.get('text',''),'final':bool(chunk.get('is_final',False))})
        text=(chunk.get('text') or '').strip()
        card={
            'card_id': str(uuid.uuid4()),
            'ts': now,
            'topic': state.get('topic','requirements_discovery'),
            'conversation_mode': state.get('mode','consultative'),
            'key_insight': (text[:180] + '…') if len(text)>180 else text,
            'suggested_question': 'What outcome are you aiming for, and what constraints matter most?',
            'solution_hint': 'Map the scenario to Azure AI Foundry + security/network/ops constraints.',
        }
        state.setdefault('cards',[]).append(card)
        state['last_guidance']=card
        return {'state':state,'guidance':card}

    def talk_track(self, state:Dict[str,Any], card:Dict[str,Any])->Dict[str,Any]:
        if self.use_llm_talktrack:
            raw=self._client().ask(TALKTRACK_SYSTEM, json.dumps({'card':card},ensure_ascii=False))
            try:
                out=json.loads(raw)
                if isinstance(out.get('talk_track'), list):
                    return out
            except Exception:
                pass
        ask=card.get('suggested_question','')
        hint=card.get('solution_hint','')
        ins=card.get('key_insight','')
        return {'talk_track':[f"Based on what you said, {ins}", f"Could you clarify: {ask}", f"One direction: {hint}", "Does that align?"], 'one_liner': ask}
