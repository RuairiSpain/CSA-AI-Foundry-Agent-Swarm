# Next level: Teams meeting integration with Graph webhooks (change notifications)

This build adds a webhook receiver that supports the Graph **validationToken handshake** and accepts **change notifications**.

## Key endpoints
- `POST /graph/notifications`
  - If `validationToken` query param is present, returns it as plain text (Graph subscription validation)
  - Otherwise processes notifications and triggers transcript ingestion

## Clients
- `clients/teams_transcript_subscribe.py` — create/renew/delete transcript subscriptions

## Env vars
See `.env.example`.
