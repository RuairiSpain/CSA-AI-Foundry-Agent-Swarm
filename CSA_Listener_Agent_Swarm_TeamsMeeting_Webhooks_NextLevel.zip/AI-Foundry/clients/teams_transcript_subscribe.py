# Create/renew/delete a Graph subscription for Teams meeting transcripts.
#
# Graph will call your HTTPS webhook endpoint; the server implements the validationToken handshake.

import os
import json

from AI_Foundry.teams.graph import GraphAuth, create_transcript_subscription, renew_subscription, delete_subscription

ONLINE_MEETING_ID = os.getenv('TEAMS_ONLINE_MEETING_ID','')
NOTIFICATION_URL = os.getenv('GRAPH_NOTIFICATION_URL','')
LIFECYCLE_URL = os.getenv('GRAPH_LIFECYCLE_URL','') or None

if __name__ == '__main__':
    if not ONLINE_MEETING_ID:
        raise SystemExit('Set TEAMS_ONLINE_MEETING_ID')
    auth = GraphAuth.from_env()
    token = auth.token()

    import sys
    cmd = (sys.argv[1] if len(sys.argv)>1 else 'create').lower()

    if cmd == 'create':
        if not NOTIFICATION_URL:
            raise SystemExit('Set GRAPH_NOTIFICATION_URL to your public HTTPS endpoint, e.g. https://<host>/graph/notifications')
        sub = create_transcript_subscription(token, ONLINE_MEETING_ID, NOTIFICATION_URL, lifecycle_url=LIFECYCLE_URL)
        print(json.dumps(sub, indent=2))
    elif cmd == 'renew':
        sid = os.getenv('GRAPH_SUBSCRIPTION_ID','')
        if not sid:
            raise SystemExit('Set GRAPH_SUBSCRIPTION_ID')
        sub = renew_subscription(token, sid)
        print(json.dumps(sub, indent=2))
    elif cmd == 'delete':
        sid = os.getenv('GRAPH_SUBSCRIPTION_ID','')
        if not sid:
            raise SystemExit('Set GRAPH_SUBSCRIPTION_ID')
        delete_subscription(token, sid)
        print('deleted')
    else:
        raise SystemExit('Usage: python clients/teams_transcript_subscribe.py [create|renew|delete]')
