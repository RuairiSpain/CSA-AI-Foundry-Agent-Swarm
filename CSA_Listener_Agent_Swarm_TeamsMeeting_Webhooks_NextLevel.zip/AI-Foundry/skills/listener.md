# CSA Listener — Next level Teams integration

Webhook-based ingestion: subscribe, receive notifications, and ingest transcripts automatically.
