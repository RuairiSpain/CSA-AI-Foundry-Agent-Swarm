from __future__ import annotations
import os, json, uuid
from typing import Any
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect

from Copilot_VSCode.server.tool_registry import ToolRegistry
from Copilot_VSCode.server.jsonrpc import JsonRpcError, make_error, make_result, get_id, get_method, get_params
from Copilot_VSCode.listener.state import SessionStore
from Copilot_VSCode.listener.engine import ListenerEngine
from Copilot_VSCode.teams.webhook import router as graph_webhook_router

app = FastAPI(title=os.getenv('APP_TITLE','CSA Listener MCP + Teams Webhooks'), version='1.3.0')

TOOLS_PATH = os.getenv('TOOLS_YAML','config/tools.yaml')
registry = ToolRegistry(TOOLS_PATH)
STORE = SessionStore()
ENGINE = ListenerEngine()

app.include_router(graph_webhook_router)

@app.get('/health')
def health():
    return {'status':'ok','tools':len(registry.list_tools()),'listener_sessions':STORE.count()}

@app.websocket('/listener/ws')
async def listener_ws(ws: WebSocket):
    await ws.accept(); session_id=None
    try:
        while True:
            msg=await ws.receive_text(); payload=json.loads(msg) if msg else {}
            if not session_id and not payload.get('session_id'):
                session_id=str(uuid.uuid4()); STORE.create(session_id)
                await ws.send_text(json.dumps({'type':'session_created','session_id':session_id}))
                continue
            session_id=payload.get('session_id') or session_id
            if not session_id: continue
            if payload.get('type') == 'talktrack':
                st=STORE.get(session_id)
                card=st.get('last_guidance') or {}
                out=ENGINE.talk_track(st, card)
                STORE.set(session_id, st)
                await ws.send_text(json.dumps({'type':'talktrack','session_id':session_id,**out},ensure_ascii=False))
                continue
            text=payload.get('text','')
            if not text:
                await ws.send_text(json.dumps({'type':'noop','reason':'missing text'})); continue
            out=ENGINE.process_chunk(STORE.get(session_id), {'speaker':payload.get('speaker','unknown'),'text':text,'is_final':bool(payload.get('is_final',False))})
            STORE.set(session_id,out['state'])
            await ws.send_text(json.dumps({'type':'guidance','session_id':session_id,**out['guidance']},ensure_ascii=False))
    except WebSocketDisconnect:
        pass
