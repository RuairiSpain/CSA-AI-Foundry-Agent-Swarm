from __future__ import annotations

import os
import json
import uuid
from typing import Any, Dict

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect

from AI_Foundry.server.tool_registry import ToolRegistry
from AI_Foundry.server.jsonrpc import JsonRpcError, make_error, make_result, get_id, get_method, get_params

from AI_Foundry.listener.state import SessionStore
from AI_Foundry.listener.engine import ListenerEngine

app = FastAPI(title=os.getenv("APP_TITLE", "CSA Agent Swarm MCP"), version="0.6.0")

TOOLS_PATH = os.getenv("TOOLS_YAML", "config/tools.yaml")
registry = ToolRegistry(TOOLS_PATH)

# Listener runtime
STORE = SessionStore()
ENGINE = ListenerEngine()


@app.get("/health")
def health():
    return {"status": "ok", "tools": len(registry.list_tools()), "listener_sessions": STORE.count()}


@app.post("/mcp")
async def mcp(request: Request):
    payload = await request.json()
    id_ = get_id(payload)

    try:
        method = get_method(payload)
        params = get_params(payload)

        if method == "initialize":
            proto = (params or {}).get("protocolVersion", "2024-11-05")
            return make_result(
                id_,
                {
                    "protocolVersion": proto,
                    "capabilities": {
                        "tools": {"listChanged": False},
                        "resources": {"subscribe": False, "listChanged": False},
                        "prompts": {"listChanged": False},
                    },
                    "serverInfo": {"name": "csa-agent-swarm", "version": app.version},
                },
            )

        if method == "tools/list":
            return make_result(id_, {"tools": registry.list_tools(), "nextCursor": None})

        if method == "tools/call":
            if not params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing params"})
            name = params.get("name")
            arguments = params.get("arguments", {})
            if not name:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing tool name"})

            tool = registry.get_tool(name)
            registry.validate_args(tool, arguments)
            adapter = registry.load_callable(tool.adapter)

            try:
                output = adapter(arguments)
                return make_result(
                    id_,
                    {"content": [{"type": "text", "text": _as_text(output)}], "isError": False},
                )
            except Exception as e:
                return make_result(
                    id_,
                    {"content": [{"type": "text", "text": f"Tool error: {e}"}], "isError": True},
                )

        if method == "resources/list":
            return make_result(id_, {"resources": registry.list_resources(), "nextCursor": None})

        if method == "resources/read":
            if not params or "uri" not in params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing uri"})
            uri = params["uri"]
            content = registry.read_resource(uri)
            return make_result(id_, {"contents": [content]})

        if method == "prompts/list":
            return make_result(id_, {"prompts": registry.list_prompts(), "nextCursor": None})

        if method == "prompts/get":
            if not params or "name" not in params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing name"})
            name = params["name"]
            arguments = (params or {}).get("arguments", {})
            return make_result(id_, registry.get_prompt(name, arguments))

        raise JsonRpcError(-32601, "Method not found", {"method": method})

    except JsonRpcError as e:
        return make_error(id_, e)


@app.websocket("/listener/ws")
async def listener_ws(ws: WebSocket):
    """WebSocket interface for streaming transcript chunks.

    Client sends JSON messages:
      {"session_id": "..."}  (optional; server creates if missing)
      {"session_id": "...", "text": "...", "speaker": "customer|csa|unknown", "is_final": false}

    Server responds with guidance JSON after each chunk.
    """
    await ws.accept()
    session_id = None
    try:
        while True:
            msg = await ws.receive_text()
            payload = json.loads(msg)
            session_id = payload.get("session_id") or session_id
            if not session_id:
                session_id = str(uuid.uuid4())
                STORE.create(session_id)
                await ws.send_text(json.dumps({"type": "session_created", "session_id": session_id}))
                continue

            if payload.get("type") == "reset":
                STORE.reset(session_id)
                await ws.send_text(json.dumps({"type": "reset_ok", "session_id": session_id}))
                continue

            text = payload.get("text", "")
            if not text:
                await ws.send_text(json.dumps({"type": "noop", "reason": "missing text"}))
                continue

            chunk = {
                "text": text,
                "speaker": payload.get("speaker", "unknown"),
                "is_final": bool(payload.get("is_final", False)),
            }

            state = STORE.get(session_id)
            out = ENGINE.process_chunk(state, chunk)
            STORE.set(session_id, out.get("state", state))

            await ws.send_text(json.dumps({"type": "guidance", "session_id": session_id, **out.get("guidance", {})}, ensure_ascii=False))

    except WebSocketDisconnect:
        if session_id:
            STORE.touch(session_id)


def _as_text(obj: Any) -> str:
    if isinstance(obj, str):
        return obj
    return json.dumps(obj, ensure_ascii=False, indent=2)
