from __future__ import annotations

import uuid
from typing import Any, Dict

from .state import SessionStore
from .engine import ListenerEngine

STORE = SessionStore()
ENGINE = ListenerEngine()


def listener_start(arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
    session_id = str(uuid.uuid4())
    STORE.create(session_id)
    return {"session_id": session_id}


def listener_ingest(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    text = arguments["text"]
    speaker = arguments.get("speaker", "unknown")
    is_final = bool(arguments.get("is_final", False))

    state = STORE.get(session_id)
    out = ENGINE.process_chunk(state, {"text": text, "speaker": speaker, "is_final": is_final})
    STORE.set(session_id, out["state"])
    return out["guidance"]


def listener_get_state(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    state = STORE.get(session_id)
    return {"session_id": session_id, "facts": state.get("facts", {}), "last_guidance": state.get("last_guidance", {})}


def listener_export(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    state = STORE.get(session_id)
    return {
        "session_id": session_id,
        "facts": state.get("facts", {}),
        "transcript": state.get("transcript", []),
    }


def listener_reset(arguments: Dict[str, Any]) -> Dict[str, Any]:
    session_id = arguments["session_id"]
    STORE.reset(session_id)
    return {"session_id": session_id, "status": "reset"}
