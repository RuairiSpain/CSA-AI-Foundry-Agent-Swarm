from __future__ import annotations

import time
from typing import Any, Dict


class SessionStore:
    def __init__(self):
        self._sessions: Dict[str, Dict[str, Any]] = {}

    def create(self, session_id: str) -> None:
        self._sessions[session_id] = {
            "created": time.time(),
            "updated": time.time(),
            "transcript": [],
            "facts": {
                "customer_goal": None,
                "pain_points": [],
                "constraints": [],
                "current_state": [],
                "open_questions": [],
            },
            "last_guidance": {},
        }

    def count(self) -> int:
        return len(self._sessions)

    def get(self, session_id: str) -> Dict[str, Any]:
        if session_id not in self._sessions:
            self.create(session_id)
        return self._sessions[session_id]

    def set(self, session_id: str, state: Dict[str, Any]) -> None:
        self._sessions[session_id] = state
        self._sessions[session_id]["updated"] = time.time()

    def reset(self, session_id: str) -> None:
        self.create(session_id)

    def touch(self, session_id: str) -> None:
        if session_id in self._sessions:
            self._sessions[session_id]["updated"] = time.time()
