from __future__ import annotations

import os
import json
from typing import Any, Dict

from .models import FoundryModelClient


LISTENER_SYSTEM = """
You are a real-time CSA Listener for Azure solution discovery.

You receive the latest transcript chunk plus running context.

Your job is to help a human CSA in the meeting with minimal distraction.

Return STRICT JSON with keys:
- key_insight: string (1-2 sentences)
- suggested_question: string (one open-ended question)
- solution_hint: string (one short Azure/Foundry direction)
- critical_gap: string (empty if none)
- extracted: object with keys: customer_goal, pain_points(list), constraints(list), current_state(list)

Rules:
- Do not hallucinate. If unclear, set fields conservatively.
- Keep language concise and speak in present tense.
- Prefer enterprise-safe guidance.
"""


class ListenerEngine:
    def __init__(self):
        self.primary_model = os.getenv("PRIMARY_MODEL", "gpt-5-mini")
        self.verifier_model = os.getenv("VERIFIER_MODEL", "gpt-4.1")
        self.project_endpoint = os.getenv("FOUNDRY_PROJECT_ENDPOINT", "")

    def _client(self, model: str) -> FoundryModelClient:
        return FoundryModelClient(project_endpoint=self.project_endpoint, model=model)

    def process_chunk(self, state: Dict[str, Any], chunk: Dict[str, Any]) -> Dict[str, Any]:
        # Update transcript
        text = chunk.get("text", "")
        speaker = chunk.get("speaker", "unknown")
        state.setdefault("transcript", []).append({"speaker": speaker, "text": text, "final": bool(chunk.get("is_final", False))})

        # Build compact context
        last_turns = state["transcript"][-20:]
        context_text = "\n".join([f"{t['speaker']}: {t['text']}" for t in last_turns])

        facts = state.get("facts", {})
        facts_text = json.dumps(facts, ensure_ascii=False)

        prompt = (
            "Running facts (may be incomplete):\n" + facts_text + "\n\n" +
            "Latest conversation window:\n" + context_text + "\n\n" +
            "Return STRICT JSON only."
        )

        primary = self._client(self.primary_model)
        raw = primary.ask(LISTENER_SYSTEM, prompt)

        guidance = _safe_json(raw)
        if not guidance:
            guidance = {
                "key_insight": "Conversation in progress; capture more details.",
                "suggested_question": "Could you describe the current system and what success looks like?",
                "solution_hint": "Identify workload, data sources, and constraints before selecting Foundry services.",
                "critical_gap": "Need clearer requirements.",
                "extracted": {},
                "_raw": raw,
            }

        # Merge extracted facts
        extracted = guidance.get("extracted", {}) or {}
        state["facts"] = _merge_facts(state.get("facts", {}), extracted)
        state["last_guidance"] = guidance

        return {"state": state, "guidance": guidance}


def _merge_facts(existing: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(existing or {})
    for k in ["customer_goal"]:
        if new.get(k):
            out[k] = new.get(k)
    for k in ["pain_points", "constraints", "current_state", "open_questions"]:
        if new.get(k):
            out.setdefault(k, [])
            for item in new.get(k) if isinstance(new.get(k), list) else [new.get(k)]:
                if item and item not in out[k]:
                    out[k].append(item)
    return out


def _safe_json(text: str):
    try:
        # Strip code fences if any
        t = text.strip()
        if t.startswith("```"):
            t = t.split("\n", 1)[-1]
            if t.endswith("```"):
                t = t.rsplit("```", 1)[0]
        return json.loads(t)
    except Exception:
        return None
