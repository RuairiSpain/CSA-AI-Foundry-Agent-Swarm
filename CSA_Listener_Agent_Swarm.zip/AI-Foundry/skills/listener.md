# CSA Listener (Live Call Assist)

## Purpose
Provide live guidance to a human CSA during customer conversations by ingesting transcript chunks and producing:
- Key insight (what just changed)
- Next best open question
- Possible solution direction
- Critical gap to clarify

## Input
- Streaming transcript chunks (speaker-tagged when possible)

## Output
- Concise guidance card for CSA
- Running structured context (facts + constraints)

## Privacy note
- Treat all transcripts as customer confidential.
- Support temporary transcript mode where no data is persisted beyond the session when required.
