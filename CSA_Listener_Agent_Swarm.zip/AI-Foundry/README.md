# CSA Listener Agent Pack (MCP + WebSocket)

This adds a live-call assistant to the CSA swarm.

## Two integration paths

### 1) WebSocket (lowest friction for real-time)
- Connect to: `ws://<host>:<port>/listener/ws`
- Send transcript chunks as JSON
- Receive guidance cards after each chunk

### 2) MCP tools (if you can only call tools)
- `listener.start`
- `listener.ingest`
- `listener.state`
- `listener.export`

## Why this matters
Teams Copilot can operate during the meeting using a temporary transcript that is deleted after the meeting ends, which is useful for privacy-sensitive calls. citeturn17search270

This pack enables a similar “in-the-moment” CSA assistance experience, but is channel-agnostic (Teams / phone / in-person), assuming you can provide audio→text or text chunks.

## Notes
- Real-time speech-to-text is supported by Azure Speech with intermediate results. citeturn15search55
- Speech SDK can ingest custom audio input streams if you later wire telephony audio feeds. citeturn15search49
