"""CSA Listener client (microphone) using Azure Speech SDK.

This streams recognised text to the server websocket endpoint /listener/ws.

Prereqs:
- Set SPEECH_KEY and SPEECH_REGION for Azure Speech.
- Start server: uvicorn <pkg>.server.app:app --port 8001

Note: This captures microphone only. For "system audio" (speaker output) capture, you typically need OS-level loopback capture.
"""

import os
import json
import asyncio

import azure.cognitiveservices.speech as speechsdk
import websockets

SERVER_WS = os.getenv("LISTENER_WS", "ws://127.0.0.1:8001/listener/ws")
SPEECH_KEY = os.getenv("SPEECH_KEY")
SPEECH_REGION = os.getenv("SPEECH_REGION")
LANG = os.getenv("SPEECH_LANG", "en-US")


async def main():
    if not SPEECH_KEY or not SPEECH_REGION:
        raise SystemExit("Set SPEECH_KEY and SPEECH_REGION")

    async with websockets.connect(SERVER_WS) as ws:
        # Create session
        await ws.send(json.dumps({}))
        msg = json.loads(await ws.recv())
        session_id = msg.get("session_id")
        print("Session:", session_id)

        speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
        speech_config.speech_recognition_language = LANG
        audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
        recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)

        # Callback hooks
        def on_recognizing(evt):
            text = evt.result.text
            if text:
                asyncio.create_task(ws.send(json.dumps({"session_id": session_id, "text": text, "speaker": "customer", "is_final": False})))

        def on_recognized(evt):
            text = evt.result.text
            if text:
                asyncio.create_task(ws.send(json.dumps({"session_id": session_id, "text": text, "speaker": "customer", "is_final": True})))

        recognizer.recognizing.connect(on_recognizing)
        recognizer.recognized.connect(on_recognized)

        recognizer.start_continuous_recognition()
        print("Listening... Ctrl+C to stop")

        try:
            while True:
                # Read server guidance messages
                data = json.loads(await ws.recv())
                if data.get("type") == "guidance":
                    print("\n--- CSA Guidance ---")
                    print("Insight:", data.get("key_insight"))
                    print("Ask:", data.get("suggested_question"))
                    print("Hint:", data.get("solution_hint"))
                    if data.get("critical_gap"):
                        print("Gap:", data.get("critical_gap"))
        finally:
            recognizer.stop_continuous_recognition()


if __name__ == "__main__":
    asyncio.run(main())
