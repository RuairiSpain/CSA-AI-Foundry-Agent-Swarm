# Session Memory

Store:
- Customer constraints (region/data boundary, industry/regulatory, identity model, network posture)
- Decisions (model routing, tools enabled, key trade-offs)
- Output artifacts (diagram, brief, checklist)

Do not store:
- Secrets, tokens, credentials
- Customer confidential data (unless explicitly approved and handled per policy)
