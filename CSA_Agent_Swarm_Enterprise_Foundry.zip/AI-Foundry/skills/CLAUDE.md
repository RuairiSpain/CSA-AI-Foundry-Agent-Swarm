# CSA Agent Swarm — Enterprise Operating Rules

## Enterprise bar (non-negotiable)
- Assume **mission-critical** requirements unless stated otherwise.
- Always include: **identity**, **networking**, **observability**, **cost**, **resiliency**, **governance**.
- Prefer **private connectivity** (Private Link, VNet integration) over public exposure.
- Prefer **least privilege** (RBAC/PIM) and managed identities.
- For external APIs, include **WAF**, DDoS considerations, and a clear **authn/authz** model.
- Provide a **deployment + operations** view (CI/CD, runbooks, rollback, monitoring).

## Quality rules
- Be concise, structured, and explicit.
- If information is missing, list the assumptions.
- Provide customer-ready outputs for multiple personas: VP/Director, tech lead, implementer.

## Safety
- Never include secrets.
- Recommend secure defaults.
