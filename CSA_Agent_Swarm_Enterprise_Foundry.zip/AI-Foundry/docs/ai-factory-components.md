# AI Factory / Agent Factory — Enterprise mapping

This repository treats the AI Factory as six pillars:
1) Models
2) Knowledge & Tools
3) Customization
4) Orchestration
5) Observability
6) Trust

## Enterprise cross-cutting extensions (added)
- Security & Network Architecture
- Reliability/Resilience Engineering
- FinOps/Cost Governance
- Data Governance/Compliance
- DevSecOps/Platform Engineering
- Threat Modeling & Red Teaming
- Diagnostics & Debugging
- Principal CSA/CSAM Review
- Professional Report Writing

Use scenario `ai_factory_blueprint` to run all specialists + principal review + verifier + report writer.
