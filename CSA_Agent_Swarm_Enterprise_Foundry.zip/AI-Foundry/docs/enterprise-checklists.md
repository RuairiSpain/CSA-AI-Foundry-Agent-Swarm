# Enterprise checklists (quick)

## Security/network
- VNet design (hub-spoke), Private Endpoints, DNS
- WAF/Firewall/DDoS, egress controls
- API exposure: APIM + private backend, mTLS where needed

## Identity
- Managed Identity, workload identity
- OBO where user context needed
- RBAC/PIM, break-glass, key vault

## Observability
- Tracing (agent + tools), logs, metrics
- Dashboards + alerts
- Runbooks and incident response

## Resilience
- Multi-region, RTO/RPO, failover
- Backups, testing, chaos drills

## Cost
- Model routing, caching, budgets
- Quotas/capacity planning

## Governance
- Data classification/labels
- Audit logging
- Policy-as-code
