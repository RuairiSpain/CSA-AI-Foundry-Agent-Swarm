# AI-Foundry — Enterprise CSA Agent Swarm

This folder focuses on Azure AI Foundry and mission-critical enterprise architecture.

## Run MCP server
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m uvicorn AI_Foundry.server.app:app --host 127.0.0.1 --port 8001
```

## Key scenarios
- `ai_factory_blueprint` (recommended)
- `foundry_feature_tour`

## Default model routing
- PRIMARY_MODEL: gpt-5-mini (strong / mid-priced)
- VERIFIER_MODEL: gpt-4.1 (high-quality verification)

Both configurable in `.env`.
