from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from .models import FoundryModelClient


@dataclass
class SwarmConfig:
    primary_model: str
    verifier_model: str


class Agent:
    def __init__(self, name: str, system: str):
        self.name = name
        self.system = system

    def run(self, client: FoundryModelClient, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        text = client.ask(self.system, f"Task: {task}\nContext: {context}\nReturn: markdown." )
        return {"output": text}


class PlannerAgent(Agent):
    def __init__(self):
        super().__init__(
            name="planner",
            system=(
                "You are the Planner. Produce a short execution plan for mission-critical enterprise solutions. "
                "Return max 10 steps. Each step must include: goal, inputs, outputs, owner (agent role), and checks." 
            ),
        )

    def run(self, client: FoundryModelClient, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        plan = client.ask(self.system, f"Task: {task}\nReturn: numbered plan (max 10).")
        return {"plan": plan}


class VerifierAgent(Agent):
    def __init__(self):
        super().__init__(
            name="verifier",
            system=(
                "You are the Verifier. Be strict. Check for: security gaps, incorrect claims, missing Azure services, "
                "missing enterprise controls (identity/networking/monitoring), and verbosity. "
                "Return two sections: (1) Issues (bullets), (2) Improved concise version." 
            ),
        )

    def run(self, client: FoundryModelClient, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        draft = context.get("draft", "")
        review = client.ask(self.system, f"Task: {task}\nDraft: {draft}\nReturn Issues + Improved concise version.")
        return {"review": review}


class EnterpriseOrchestrator:
    """Runs: plan → specialists → principal review → verifier → report."""

    def __init__(self, cfg: SwarmConfig, primary: FoundryModelClient, verifier: FoundryModelClient):
        self.cfg = cfg
        self.primary = primary
        self.verifier = verifier
        self.planner = PlannerAgent()
        self.verifier_agent = VerifierAgent()

    def run(self, task: str, scenario: str, specialists: List[Agent], principal_reviewer: Agent, report_writer: Agent) -> Dict[str, Any]:
        ctx: Dict[str, Any] = {"scenario": scenario}

        plan = self.planner.run(self.primary, task, ctx)
        ctx.update(plan)

        outputs: Dict[str, Any] = {}
        for sp in specialists:
            outputs[sp.name] = sp.run(self.primary, task, ctx)

        draft = "\n\n".join([f"## {k}\n{v.get('output','')}" for k, v in outputs.items()])
        ctx["draft"] = draft

        principal = principal_reviewer.run(self.primary, task, ctx)
        ctx["principal_review"] = principal.get("output", "")

        verification = self.verifier_agent.run(self.verifier, task, ctx)
        ctx["verified"] = verification.get("review", "")

        report = report_writer.run(self.primary, task, ctx)

        return {
            "scenario": scenario,
            "plan": plan,
            "draft": draft,
            "principal_review": principal,
            "verification": verification,
            "report": report,
        }
