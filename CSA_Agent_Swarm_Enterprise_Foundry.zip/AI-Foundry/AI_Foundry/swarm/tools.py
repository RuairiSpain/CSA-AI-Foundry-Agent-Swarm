from __future__ import annotations

import os
from typing import Any, Dict, List

from AI_Foundry.swarm.models import FoundryModelClient
from AI_Foundry.swarm.core import SwarmConfig, Agent, EnterpriseOrchestrator


def _cfg() -> SwarmConfig:
    primary = os.getenv("PRIMARY_MODEL", "gpt-5-mini")
    verifier = os.getenv("VERIFIER_MODEL", "gpt-4.1")
    return SwarmConfig(primary_model=primary, verifier_model=verifier)


def _client(model: str) -> FoundryModelClient:
    endpoint = os.getenv("FOUNDRY_PROJECT_ENDPOINT", "")
    return FoundryModelClient(project_endpoint=endpoint, model=model)


def swarm_run(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    task = arguments["task"]
    scenario = arguments.get("scenario", "ai_factory_blueprint")

    primary = _client(cfg.primary_model)
    verifier = _client(cfg.verifier_model)

    # --- Specialist agents (enterprise) ---
    base_specialists = [
        Agent("factory_architect", "Design the AI Factory blueprint (Models, Knowledge & Tools, Customization, Orchestration, Observability, Trust). Output: architecture map + responsibilities + integration points."),
        Agent("model_steward", "Define model routing strategy: default mid-priced primary model and best-quality verifier model; fallbacks; deployment types; lifecycle/capacity considerations."),
        Agent("knowledge_toolsmith", "Define knowledge and tools: Foundry tools, Azure AI Search/IQ, Fabric, SharePoint; actions via Functions/Logic Apps; standardise with MCP and OpenAPI tools."),
        Agent("customization_engineer", "Define prompting/instructions, structured outputs, schemas, and when to use fine-tuning/distillation. Include evaluation gates."),
        Agent("orchestration_conductor", "Define multi-agent orchestration: connected agents, toolchains, retries, long-running workflows, and hand-offs."),
        Agent("observability_sre", "Define tracing/logging/evaluation KPIs, dashboards, alerting, and a debugging workflow."),
        Agent("trust_guardian", "Define enterprise trust: identity (MI/OBO), least privilege RBAC, network isolation (VNets/Private Link), data protection, compliance controls."),
        Agent("security_network_architect", "Design mission-critical enterprise network security: hub-spoke VNets, Private Endpoints, Firewall, WAF, APIM exposure patterns, DDoS, threat model, and SFI-aligned hardening."),
        Agent("diagnostics_debugger", "Debug customer problems: Azure configuration issues, identity/network failures, tool-call failures, and low-quality agent outputs. Provide a triage tree + root cause patterns."),
        Agent("finops_cost", "Define cost controls for enterprise agents: model routing, caching, quota/capacity planning, cost guardrails, and chargeback/showback."),
        Agent("reliability_resilience", "Define HA/DR and resiliency: multi-region, failover, RTO/RPO, runbooks, chaos testing, and operational readiness."),
        Agent("data_governance", "Define data governance: classification/labels, access policies, data boundary, retention, auditability, and safe grounding patterns."),
        Agent("devsecops_platform", "Define platform engineering: CI/CD for agents, policy-as-code, IaC, environment promotion, and security scanning."),
        Agent("threat_model_redteam", "Define security testing: threat model, prompt injection risks, red teaming, evaluation datasets, and mitigations."),
    ]

    # Scenario tweaks
    specialists = base_specialists
    if scenario == "copilot_vscode_workshop":
        specialists = [
            Agent("vscode_workshop", "Create a VS Code Copilot workshop for enterprise: MCP config, tool approvals, sandboxing, secure workflows, and debugging patterns."),
            Agent("mcp_integration", "Provide MCP server integration examples for VS Code (.vscode/mcp.json) and explain how tools/list and tools/call are used."),
            Agent("repo_hygiene", "Create repo conventions: instructions files, tool allowlists, security guardrails, and CI basics."),
        ] + base_specialists

    if scenario == "copilot_github_pr_swarm":
        specialists = [
            Agent("github_pr", "Define GitHub Copilot PR workflow for enterprise: policy, approvals, checks, secret scanning, branch protections."),
            Agent("review_playbook", "Write reviewer checklist and how to request Copilot review safely."),
        ] + base_specialists

    principal_reviewer = Agent(
        "principal_csa_csam_reviewer",
        "You are a Principal CSA + CSAM reviewer. Critique the solution like an exec sponsor: identify gaps/risks, simplify, and produce a customer presentation strategy (director/VP, tech leads, grads).",
    )

    report_writer = Agent(
        "professional_report_writer",
        "You are a professional report writer. Produce: (1) 1-page exec brief, (2) architecture section, (3) implementation plan for engineers. Use concise headings and include a simple diagram (Mermaid) where useful.",
    )

    orch = EnterpriseOrchestrator(cfg, primary=primary, verifier=verifier)
    return orch.run(task=task, scenario=scenario, specialists=specialists, principal_reviewer=principal_reviewer, report_writer=report_writer)


def foundry_ask(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    client = _client(cfg.primary_model)
    prompt = arguments["prompt"]
    return {"model": cfg.primary_model, "response": client.ask("You are a helpful CSA assistant.", prompt)}


def debug_triage(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    primary = _client(cfg.primary_model)
    verifier = _client(cfg.verifier_model)
    issue = arguments["issue"]
    ctx = {"type": "debug_triage"}
    draft = primary.ask("You are an Azure troubleshooting expert.", f"Issue: {issue}\nReturn a triage checklist and likely root causes." )
    review = verifier.ask("You are a strict verifier.", f"Review this triage for gaps and add missing enterprise checks:\n{draft}")
    return {"draft": draft, "verification": review}


def security_review(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    verifier = _client(cfg.verifier_model)
    design = arguments["design"]
    review = verifier.ask(
        "You are an enterprise security reviewer.",
        "Review the design for enterprise gaps: identity, networking, data exfiltration, logging, policy, DR, and least privilege. Return a punchlist.",
        )
    # include design in prompt
    review = verifier.ask("You are an enterprise security reviewer.", f"Design:\n{design}\nReturn punchlist + recommended Azure services/policies." )
    return {"review": review}


def report_generate(arguments: Dict[str, Any]) -> Dict[str, Any]:
    cfg = _cfg()
    primary = _client(cfg.primary_model)
    audience = arguments.get("audience", "executive")
    content = arguments["content"]
    system = "You are a professional technical writer. Produce concise, visual, audience-tailored docs." 
    prompt = f"Audience: {audience}\nContent:\n{content}\nReturn a polished report." 
    return {"report": primary.ask(system, prompt)}
