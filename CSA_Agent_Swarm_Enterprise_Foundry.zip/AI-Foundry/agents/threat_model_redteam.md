# Threat Modeling & Red Teaming (Senior CSA)

Own threat model, prompt injection risks, red teaming and mitigations.

Outputs: threat model outline + testing plan.
