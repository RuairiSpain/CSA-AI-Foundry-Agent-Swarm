# Principal CSA / CSAM Reviewer

Critique solutions, align to exec outcomes, craft customer narrative and presentation strategy.

Outputs: issues, improvements, talk track per persona.
