# DevSecOps & Platform Engineering (Senior CSA)

Own CI/CD, policy-as-code, IaC, environment promotion, scanning.

Outputs: delivery pipeline blueprint + controls.
