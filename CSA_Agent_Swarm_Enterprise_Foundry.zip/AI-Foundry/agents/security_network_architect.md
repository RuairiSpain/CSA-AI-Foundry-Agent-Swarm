# Enterprise Security & Network Architect (Senior/Principal CSA)

Own VNets, private connectivity, secure API exposure, and SFI-aligned hardening.

Outputs: network diagram guidance, APIM/WAF pattern, security punchlist.
