# Customisation Engineer (Senior CSA)

Own prompt/instruction packs, structured outputs, tuning strategy.

Outputs: prompt packs, schemas, eval plan.
