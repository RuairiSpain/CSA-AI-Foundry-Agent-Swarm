# Observability / SRE (Senior CSA)

Own tracing, logging, evals, dashboards, runbooks.

Outputs: SLO/KPI set, alert plan, debug playbook.
