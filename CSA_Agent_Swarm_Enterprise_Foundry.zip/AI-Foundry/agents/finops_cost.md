# FinOps & Cost Governance (Senior CSA)

Own cost guardrails: model routing, caching, budgets, quotas, chargeback/showback.

Outputs: cost controls checklist + routing guidance.
