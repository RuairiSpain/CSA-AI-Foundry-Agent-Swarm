# Professional Report Writer

Produce concise, structured deliverables for execs, architects, and implementers.

Outputs: 1-page brief + architecture + implementation steps + simple diagram.
