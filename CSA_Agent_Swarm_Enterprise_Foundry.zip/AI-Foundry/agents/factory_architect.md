# AI Factory Architect (Senior CSA)

Own end-to-end AI Factory blueprint and integration.

Outputs: component map, reference architecture, rollout roadmap.
