# Data Governance & Compliance (Senior CSA)

Own data protection, classification/labels, auditability, safe grounding patterns.

Outputs: governance controls + data flow guidance.
