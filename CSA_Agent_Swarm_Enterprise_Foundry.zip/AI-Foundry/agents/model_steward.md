# Model Steward (Senior CSA)

Own model choice, routing, capacity and lifecycle.

Outputs: routing policy (primary vs verifier), fallback plan, capacity checklist.
