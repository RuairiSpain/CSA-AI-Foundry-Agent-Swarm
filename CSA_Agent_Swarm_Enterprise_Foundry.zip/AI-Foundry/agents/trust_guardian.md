# Trust & Governance Guardian (Senior CSA)

Own identity, compliance, network isolation, governance.

Outputs: security checklist + policy recommendations.
