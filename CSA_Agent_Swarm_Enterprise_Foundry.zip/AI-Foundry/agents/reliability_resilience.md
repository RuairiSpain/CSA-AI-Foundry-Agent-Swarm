# Reliability & Resilience Engineer (Senior CSA)

Own HA/DR, multi-region design, RTO/RPO, operational readiness.

Outputs: resilience plan, failover runbook skeleton.
