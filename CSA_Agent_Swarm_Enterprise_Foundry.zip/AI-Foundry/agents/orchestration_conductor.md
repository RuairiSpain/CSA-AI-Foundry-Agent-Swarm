# Orchestration Conductor (Senior CSA)

Own multi-agent flows, retries, long-running workflows.

Outputs: workflow definitions + error handling patterns.
