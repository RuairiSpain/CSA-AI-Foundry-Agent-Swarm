# Knowledge & Tools Integrator (Senior CSA)

Own grounding + tool catalog (MCP/OpenAPI/Functions/Logic Apps).

Outputs: tool catalog, schemas, data grounding plan.
