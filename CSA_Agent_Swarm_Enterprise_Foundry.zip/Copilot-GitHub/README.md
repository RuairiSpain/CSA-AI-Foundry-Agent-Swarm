# Copilot-GitHub — Enterprise CSA Agent Swarm

Focus: GitHub Copilot workflows (PRs/reviews) + enterprise controls.

Run:
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn Copilot_GitHub.server.app:app --host 127.0.0.1 --port 8003
```

Scenario: `copilot_github_pr_swarm`
