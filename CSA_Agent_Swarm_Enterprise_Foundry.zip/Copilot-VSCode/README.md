# Copilot-VSCode — Enterprise CSA Agent Swarm

Focus: Copilot in VS Code + MCP + enterprise guardrails.

Run:
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn Copilot_VSCode.server.app:app --host 127.0.0.1 --port 8002
```

Scenario: `copilot_vscode_workshop`
