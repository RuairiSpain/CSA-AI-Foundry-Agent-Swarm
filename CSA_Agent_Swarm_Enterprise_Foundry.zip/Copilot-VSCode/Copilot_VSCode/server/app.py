from __future__ import annotations

import os
import json
from typing import Any

from fastapi import FastAPI, Request

from Copilot_VSCode.server.tool_registry import ToolRegistry
from Copilot_VSCode.server.jsonrpc import JsonRpcError, make_error, make_result, get_id, get_method, get_params

app = FastAPI(title=os.getenv("APP_TITLE", "CSA Agent Swarm MCP"), version="0.3.0")

TOOLS_PATH = os.getenv("TOOLS_YAML", "config/tools.yaml")
registry = ToolRegistry(TOOLS_PATH)


@app.get("/health")
def health():
    return {"status": "ok", "tools": len(registry.list_tools())}


@app.post("/mcp")
async def mcp(request: Request):
    payload = await request.json()
    id_ = get_id(payload)

    try:
        method = get_method(payload)
        params = get_params(payload)

        if method == "initialize":
            proto = (params or {}).get("protocolVersion", "2024-11-05")
            return make_result(
                id_,
                {
                    "protocolVersion": proto,
                    "capabilities": {
                        "tools": {"listChanged": False},
                        "resources": {"subscribe": False, "listChanged": False},
                        "prompts": {"listChanged": False},
                    },
                    "serverInfo": {"name": "csa-agent-swarm", "version": app.version},
                },
            )

        if method == "tools/list":
            return make_result(id_, {"tools": registry.list_tools(), "nextCursor": None})

        if method == "tools/call":
            if not params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing params"})
            name = params.get("name")
            arguments = params.get("arguments", {})
            if not name:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing tool name"})

            tool = registry.get_tool(name)
            registry.validate_args(tool, arguments)
            adapter = registry.load_callable(tool.adapter)

            try:
                output = adapter(arguments)
                return make_result(
                    id_,
                    {"content": [{"type": "text", "text": _as_text(output)}], "isError": False},
                )
            except Exception as e:
                return make_result(
                    id_,
                    {"content": [{"type": "text", "text": f"Tool error: {e}"}], "isError": True},
                )

        if method == "resources/list":
            return make_result(id_, {"resources": registry.list_resources(), "nextCursor": None})

        if method == "resources/read":
            if not params or "uri" not in params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing uri"})
            uri = params["uri"]
            content = registry.read_resource(uri)
            return make_result(id_, {"contents": [content]})

        if method == "prompts/list":
            return make_result(id_, {"prompts": registry.list_prompts(), "nextCursor": None})

        if method == "prompts/get":
            if not params or "name" not in params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing name"})
            name = params["name"]
            arguments = (params or {}).get("arguments", {})
            return make_result(id_, registry.get_prompt(name, arguments))

        raise JsonRpcError(-32601, "Method not found", {"method": method})

    except JsonRpcError as e:
        return make_error(id_, e)


def _as_text(obj: Any) -> str:
    if isinstance(obj, str):
        return obj
    return json.dumps(obj, ensure_ascii=False, indent=2)
